// WLAN-Suche des Heltec; unabhängig vom 868-MHz-Zählerempfang.
let wlanSchonGesucht=false,wlanSuchAktiv=false;
function wlanAuswaehlen(){
  const option=$('wlanListe').selectedOptions[0],manuell=option?.value==='manuell';
  $('wlanManuellZeile').classList.toggle('hidden',!manuell);
  $('wlanManuell').required=manuell;
  $('ssid').value=manuell?$('wlanManuell').value:(option?.dataset.ssid||'');
}
function wlanNetzeZeigen(netze){
  const bisher=$('ssid').value,sortiert=new Map();
  for(const n of netze||[])if(typeof n.ssid==='string'&&n.ssid&&(!sortiert.has(n.ssid)||n.rssi>sortiert.get(n.ssid).rssi))sortiert.set(n.ssid,n);
  const liste=$('wlanListe');liste.replaceChildren(new Option('WLAN auswählen',''));
  let nummer=0;
  for(const n of [...sortiert.values()].sort((a,b)=>b.rssi-a.rssi)){
    const o=new Option(n.ssid+' · '+n.rssi+' dBm'+(n.offen?' · offen':''),String(++nummer));o.dataset.ssid=n.ssid;
    // Die Heimnetz-Einrichtung verwendet ein WPA-Passwort.
    o.disabled=!!n.offen;liste.add(o);if(n.ssid===bisher&&!n.offen)o.selected=true;
  }
  liste.add(new Option('Anderes / verborgenes WLAN','manuell'));
  if(bisher&&![...liste.options].some(o=>o.dataset.ssid===bisher&&!o.disabled)){liste.value='manuell';$('wlanManuell').value=bisher;}
  wlanAuswaehlen();
  $('wlanSuchStatus').textContent=sortiert.size?sortiert.size+' WLANs gefunden':'Keine WLANs gefunden';
}
async function wlanSuchen(){
  if(pc||wlanSuchAktiv)return;
  wlanSuchAktiv=true;wlanSchonGesucht=true;$('wlanSuchen').disabled=true;$('wlanSuchStatus').textContent='WLANs werden gesucht …';
  try{
    if(!token)await sitzungLaden();
    const beginn=Date.now();let antwort=await fetch('/api/wlan/suche',{method:'POST',headers:{'X-Hydrus-Token':token},signal:AbortSignal.timeout(8000)});
    while(true){
      if(!antwort.ok)throw Error('WLAN-Suche fehlgeschlagen');const j=await antwort.json();
      if(j.fehler)throw Error(j.fehler);
      if(!j.laeuft){wlanNetzeZeigen(j.netze);break;}
      if(Date.now()-beginn>25000)throw Error('WLAN-Suche abgelaufen');
      await new Promise(r=>setTimeout(r,800));
      antwort=await fetch('/api/wlan/suche',{cache:'no-store',signal:AbortSignal.timeout(8000)});
    }
  }catch(e){$('wlanSuchStatus').textContent=e.message;}
  finally{wlanSuchAktiv=false;$('wlanSuchen').disabled=false;}
}
$('wlanListe').onchange=wlanAuswaehlen;$('wlanManuell').oninput=wlanAuswaehlen;$('wlanSuchen').onclick=wlanSuchen;
document.querySelector('[data-tab="einstellungen"]').addEventListener('click',()=>{if(!wlanSchonGesucht)wlanSuchen();});
