# HYDRUS – Wasser im Blick 2.1.0

Heltec WiFi LoRa 32 V3 mit SX1262, lokale Handy-Webseite und PC-Programm mit PySide6. Der Heltec empfängt und speichert auch ohne laufenden PC. USB und TCP-Port 8765 bleiben verfügbar.

## Installation

ZIP vollständig in einen neuen Ordner entpacken. PC: starten.bat richtet bei Bedarf Python, PySide6 und cryptography ein; beim ersten Start ist Internet nötig. 64-Bit-Windows erforderlich.

Firmware: Arduino IDE mit Espressif 3.3.12, RadioLib 7.7.1 und ArduinoJson 7.4.2. Hydrus_Heltec_V3/Hydrus_Heltec_V3.ino öffnen und alle Header beibehalten. Board Heltec WiFi LoRa 32(V3), 8 MB, PSRAM Disabled, USB CDC On Boot Disabled, CPU 240 MHz. Standardpartitionierung mit zwei App-Partitionen und 1,5 MiB Dateisystem, kein No-OTA-Profil. Mit Datenkabel hochladen. Bei normalem Upload ohne Flash-Löschen bleiben NVS-Einstellungen und Archive erhalten.

Vor einem eigenen Build persönliche Anpassungen in WlanZugang.h übernehmen. Das fertige öffentliche Firmwarepaket verwendet als Accesspoint HYDRUS-Monitor und als Passwort Hydrus-Lokal-2026. Ein individuell im bisherigen Sketch gesetztes Accesspoint-Passwort würde durch diese fertige Firmware ersetzt. Heimnetzpasswort und Zählerschlüssel im Gerätespeicher bleiben erhalten. Keine persönlichen Zählerkennungen oder AES-Schlüssel im öffentlichen Download.

## Heimnetz und Zähler

Mit HYDRUS-Monitor verbinden und http://192.168.4.1 öffnen. Einstellungen → Heimnetz sucht 2,4-GHz-Netze. Netz auswählen, WLAN-Passwort eingeben, speichern. Verborgene Netze können manuell eingetragen werden. Funksuche und WLAN-Einrichtung benötigen keine Browser-Anmeldung. Andere Änderungen verwenden admin und das Accesspoint-Passwort.

Der Accesspoint bleibt unter 192.168.4.1 erreichbar. Im Heimnetz die Adresse aus der Statuszeile oder vom OLED öffnen; alternativ http://heltec-wasser.local, sofern mDNS funktioniert. Keine Internet-Portfreigabe einrichten.

Unter Zähler & Warnungen Kennung, Namen und den Schlüssel aus der Versorger-Mail eintragen. Vorhandene Konfiguration bleibt erhalten. Bei einem ganz neuen Gerät zunächst die eigene Kennung aus dem Funkempfang übernehmen. Leeres Schlüsselfeld behält den gespeicherten Schlüssel; Löschen erfolgt separat. Nach der Erstkonfiguration überschreibt ZaehlerSchluessel.h keine gespeicherten Einstellungen. Schlüssel werden nicht zurückgegeben.

## Speichern und Warnen

Messwertspeicher bei Bedarf einmal unter Einstellungen einrichten. Das Dateisystem wird nicht automatisch formatiert. Der Rohdatenring speichert für konfigurierte Zähler spätestens alle fünf Minuten einen neuen Stand (512 KiB). Dazu kommen Stunden (256 KiB), Tage (128 KiB) und Ereignisse (128 KiB). Alte Dateien rotieren; keine garantierte Aufbewahrungsdauer. Stromausfall kann die letzten ungesicherten Verbrauchssummen verlieren.

Verbrauch ist die Summe plausibler aufeinanderfolgender Zählerstände innerhalb der Empfangsfrist. Intervalle über Stunden-/Tagesgrenzen werden dem jeweiligen Diagramm nicht zugerechnet; fehlende Werte werden nicht erfunden. Positive Summen sind als Mindestmenge mit ≥ markiert. Für datierte Summen wird Internet-Zeitsynchronisation benötigt, Zeitzone Europe/Berlin. Ohne Zeit bleibt bei Ereignissen Startkennung und Laufzeit sichtbar.

Leckverdacht: standardmäßig mindestens 0,1 l/min über 30 Minuten; Empfangsausfall nach zehn Minuten. Beides ist einstellbar. Kein oder unbekannter Durchfluss, Empfangslücken und Neustarts unterbrechen die Prüfung. Ein Verdacht ist kein Lecknachweis und löst keine Absperrung aus. Ohne übertragenen Durchfluss funktioniert diese Prüfung nicht.

## Überwachung

Ereignisse speichern Beginn, Ende und Dauer von Warnungen sowie Neustarts. Empfangsausfall wird beim Leck als Unterbrechung gekennzeichnet. Ein Neustart trennt die Überwachungszeiträume; offene Warnungen vor dem Neustart erhalten kein erfundenes Enddatum. Die Liste zeigt die letzten 300 geladenen Einträge, CSV exportiert alle geladenen. PC benötigt zum Laden die Heltec-IP und Netzwerkzugang, auch bei USB-Liveempfang.

Messwerte vergleichen: eigenen Zähler auswählen, frischen Startwert übernehmen, beispielsweise zehn Liter gezielt entnehmen, Entnahme beendet drücken und das nächste Telegramm abwarten. Menge und optional abgelesenen Endstand eingeben. Der Vergleich zeigt Liter-/Prozentabweichung; Auflösung, Sendeintervall und zusätzliche Entnahmen beeinflussen ihn. Keine automatische Kalibrierung. Der letzte Vergleich bleibt im lokalen Browser/PC gespeichert. Verbindungsabbrüche und erkannte Neustarts brechen einen laufenden Versuch ab.

Handy-Mitteilungen: siehe BENACHRICHTIGUNGEN.md. Versand ist bis zur Einrichtung ausgeschaltet.

## Updates

Download-Ort: https://github.com/Baum1555/hydrus-updates

Die Versionsadressen sind voreingestellt. Heltec prüft täglich nach Verbindung mit Internet, PC beim Start. Installation nur nach Bestätigung. Die aktuelle Version benötigt kein neues Update. Signierte .hup-Dateien lassen sich auch lokal wählen; normale .bin/.zip-Dateien werden dort nicht akzeptiert. OTA schreibt die zweite App-Partition und aktiviert sie nach Prüfung. Kein automatischer Rücksprung bei funktional fehlerhafter, aber korrekt signierter Firmware. PC-Updates kommen in einen neuen benachbarten Ordner.

Es werden öffentliche Zertifikate geprüft; CA-Feld für GitHub leer lassen. Eigene CA bleibt optional. Versions-/Paketdateien müssen direkt über HTTPS mit Content-Length erreichbar sein. Herausgeberanleitung: UPDATES.md.

## Grenzen und Prüfstand

Passiver Wireless-M-Bus T1/C1 auf 868,95 MHz, maximal 255 Funkbytes. Keine allgemeine LoRa-/Protokollerkennung. Der Pegelscan unterbricht den Zählerempfang. Diehl Real Data und unterstützte OMS-Verfahren werden getrennt verarbeitet. Real Data ist nicht MAC-authentifiziert; Werte am Display prüfen. Nicht jedes Zählertelegramm enthält Temperatur, Batterie oder Durchfluss.

Sicherung herunterladen exportiert Konfiguration ohne Geheimnisse sowie Rohdaten und Verbrauchsarchive. Ereignisse separat als CSV exportieren. Kein automatischer Rückimport. Versorger-Mail und private Update-Signaturdatei separat aufbewahren.

Firmware-Build und simulierte Tests sind dokumentiert in PRUEFSTAND.md. Echte Funkdaten, WLAN-Wechsel, Flash-Stromausfälle, Push-Zustellung und OTA müssen auf dem Gerät überprüft werden.
