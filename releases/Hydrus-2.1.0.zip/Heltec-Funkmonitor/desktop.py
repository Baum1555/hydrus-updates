"""Deutsche PySide6-Oberfläche mit lokalem Dashboard und USB/TCP-Empfang."""
import csv
import ipaddress
import json
import re
import sys
from collections import deque
from datetime import datetime
from pathlib import Path

from PySide6.QtCore import QObject, QTimer, QUrl, Signal, Slot, QSettings, QProcess
from PySide6.QtGui import QDesktopServices
from PySide6.QtWidgets import QApplication, QMainWindow, QFileDialog, QMessageBox
from PySide6.QtWebChannel import QWebChannel
from PySide6.QtWebEngineWidgets import QWebEngineView
from PySide6.QtWebEngineCore import QWebEnginePage
from PySide6.QtNetwork import QNetworkAccessManager, QNetworkRequest, QNetworkReply
import serial
from serial.tools import list_ports
from empfangsdaten import paket_lesen
from funkdiagnose import status_lesen
from messwerte import paket_auswerten
from wlanverbindung import WlanVerbindung
from pc_updates import UpdateAufgabe
from updatepaket import VERSION, STANDARD_UPDATE_URL


class Empfang(QObject):
    ereignis = Signal(str)

    def __init__(self, fenster):
        super().__init__(fenster)
        self.fenster = fenster
        self.updateThread = None
        self.updateAngebot = None
        self.updatePfad = None
        self.einstellungen = QSettings("HYDRUS", "Wassermonitor")
        if not self.einstellungen.contains('update_url'):
            self.einstellungen.setValue('update_url', STANDARD_UPDATE_URL)
        self.kanal = None
        self.online = False
        self.puffer = bytearray()
        self.verwerfen = False
        self.folge = 0
        self.pakete = deque(maxlen=5000)
        self.protokoll = deque(maxlen=500)
        self.netz = QNetworkAccessManager(self)
        self.archiv_antworten = {}
        self.timer = QTimer(self)
        self.timer.timeout.connect(self.lesen)
        self.timer.start(50)

    def melden(self, typ, **daten):
        self.ereignis.emit(json.dumps(dict(typ=typ, **daten), ensure_ascii=False))

    @Slot()
    def bereit(self):
        self.melden('update', version=VERSION, url=self.einstellungen.value('update_url',''), text='Kein Update-Server eingerichtet' if not self.einstellungen.value('update_url','') else 'Bereit')
        if self.einstellungen.value('update_url',''): QTimer.singleShot(2000, lambda:self.updatePruefen(self.einstellungen.value('update_url','')))
        self.portsSuchen()
        self.melden('verbindung', online=False, text='Noch nicht verbunden')

    @Slot()
    def portsSuchen(self):
        self.melden('ports', ports=[p.device for p in list_ports.comports()])

    @Slot(str, str, int)
    def verbinden(self, art, adresse, nummer):
        self.trennen()
        try:
            self.kanal = (WlanVerbindung(adresse, nummer) if art == 'WLAN' else
                          serial.Serial(adresse, nummer, timeout=0, write_timeout=0.2))
            self.melden('verbindung', online=False, text='Verbindung wird aufgebaut …')
        except Exception as fehler:
            self.melden('meldung', text=str(fehler))

    @Slot()
    def trennen(self):
        if self.kanal:
            self.kanal.close()
        self.kanal = None
        self.online = False
        self.puffer.clear()
        self.verwerfen = False
        self.melden('verbindung', online=False, text='Verbindung getrennt')

    def lesen(self):
        if not self.kanal:
            return
        try:
            daten = self.kanal.read(8192)
            if not self.online and getattr(self.kanal, 'bereit', True):
                self.online = True
                self.melden('verbindung', online=True, text='Verbunden · ' + str(self.kanal.port))
            # Beschädigte/überlange Zeilen bis zum nächsten Zeilenende vollständig verwerfen.
            for zeichen in daten:
                if zeichen == 10:
                    if not self.verwerfen:
                        self.zeile(self.puffer.decode('utf-8', errors='replace').strip())
                    self.puffer.clear()
                    self.verwerfen = False
                elif not self.verwerfen:
                    self.puffer.append(zeichen)
                    if len(self.puffer) > 10000:
                        self.puffer.clear()
                        self.verwerfen = True
        except (OSError, ValueError) as fehler:
            self.trennen()
            self.melden('meldung', text=str(fehler))

    def zeile(self, text):
        if not text:
            return
        paket = paket_lesen(text)
        if paket:
            paket['felder'], paket['auswertung_text'] = paket_auswerten(paket)
            paket['zeit'] = datetime.now().astimezone().isoformat(timespec='seconds')
            self.pakete.append(paket)
            self.folge += 1
            self.melden('paket', paket=paket, seq=self.folge, alter_ms=0)
            return
        status = status_lesen(text)
        if status and status[0] == 'SCAN':
            self.melden('scan', daten=status[1])
        else:
            self.protokoll.append(text[:2000])
            self.melden('status', text=text[:2000])

    @Slot(str)
    def senden(self, befehl):
        # Nur die vorhandenen passiven Empfangs-/Suchbefehle zulassen.
        if befehl not in ('TC', 'SCAN', 'STOP') and not re.fullmatch(r'FREQ (86[3-9]|870)\d{6}', befehl):
            self.melden('meldung', text='Ungültiger Empfangsbefehl')
            return
        try:
            if not self.kanal or not self.online:
                raise ValueError('Zuerst mit dem Heltec verbinden.')
            self.kanal.write((befehl + '\n').encode('ascii'))
        except (OSError, ValueError) as fehler:
            self.melden('meldung', text=str(fehler))

    @Slot()
    def leeren(self):
        self.pakete.clear()
        self.protokoll.clear()

    def _updateStarten(self, aufgabe):
        if self.updateThread and self.updateThread.isRunning():
            self.melden('meldung', text='Updateprüfung läuft bereits')
            return
        self.updateThread = aufgabe
        aufgabe.ergebnis.connect(self._updateErgebnis)
        aufgabe.start()
        self.melden('update', text='Bitte warten …')

    def _updateErgebnis(self, daten):
        if daten['typ'] == 'angebot': self.updateAngebot = daten['angebot']
        if daten['typ'] == 'installiert': self.updatePfad = daten['pfad']
        self.melden('update', **{k:v for k,v in daten.items() if k != 'typ'})

    @Slot(str)
    def updatePruefen(self, url):
        if not url:
            self.melden('update', text='Kein Update-Server eingerichtet')
            return
        self.einstellungen.setValue('update_url', url)
        self.updateAngebot = None
        self._updateStarten(UpdateAufgabe('pruefen',url=url,parent=self))

    @Slot()
    def updateDatei(self):
        datei, _ = QFileDialog.getOpenFileName(self.fenster,'Signiertes PC-Update auswählen','','HYDRUS-Update (*.hup)')
        if datei: self._updateStarten(UpdateAufgabe('installieren',datei=datei,parent=self))

    @Slot()
    def updateInstallieren(self):
        if self.updateAngebot:
            self._updateStarten(UpdateAufgabe('installieren',angebot=self.updateAngebot,parent=self))

    @Slot()
    def updateStarten(self):
        if not self.updatePfad: return
        # Der neue Starter prüft bei Bedarf auch neue Python-Abhängigkeiten.
        starter = str(Path(self.updatePfad)/'starten.bat')
        import os
        os.startfile(starter)
        self.fenster.close()

    @Slot(str)
    def verlaufLaden(self, adresse):
        self._archivLaden(adresse, 'verlauf')

    @Slot(str)
    def statistikLaden(self, adresse):
        self._archivLaden(adresse, 'statistik')

    @Slot(str)
    def ereignisseLaden(self, adresse):
        self._archivLaden(adresse, 'ereignisse')

    def _archivLaden(self, adresse, typ):
        if typ in self.archiv_antworten:
            return
        try:
            adresse = str(ipaddress.IPv4Address(adresse))
            anfrage = QNetworkRequest(QUrl('http://' + adresse + '/api/' + typ))
            anfrage.setTransferTimeout(30000)
            antwort = self.netz.get(anfrage)
            self.archiv_antworten[typ] = antwort
            puffer = bytearray()
            def lesen():
                puffer.extend(bytes(antwort.readAll()))
                if len(puffer) > 600000:
                    antwort.abort()
            def fertig():
                lesen()
                if antwort.error() != QNetworkReply.NetworkError.NoError:
                    self.melden('meldung', text='Verlauf nicht erreichbar: ' + antwort.errorString())
                else:
                    self.melden(typ, text=puffer.decode('utf-8', errors='replace'))
                self.archiv_antworten.pop(typ, None)
                antwort.deleteLater()
            antwort.readyRead.connect(lesen)
            antwort.finished.connect(fertig)
        except ValueError:
            self.melden('meldung', text='Bitte die Heltec-IP eintragen.')

    @Slot(str)
    def verlaufExportieren(self, text):
        if len(text) > 4000000:
            self.melden('meldung', text='Export zu groß')
            return
        pfad, _ = QFileDialog.getSaveFileName(self.fenster, 'Verlauf speichern', 'hydrus-verlauf.csv', 'CSV (*.csv)')
        if pfad:
            try:
                Path(pfad).write_text(text, encoding='utf-8')
                self.melden('meldung', text='Verlauf gespeichert')
            except OSError as fehler:
                self.melden('meldung', text=str(fehler))

    @Slot(str)
    def webOeffnen(self, adresse):
        try:
            adresse = str(ipaddress.IPv4Address(adresse))
            QDesktopServices.openUrl(QUrl('http://' + adresse + '/'))
        except ValueError:
            self.melden('meldung', text='Bitte die IPv4-Adresse vom Heltec-Display eintragen.')

    @Slot(str)
    def exportieren(self, art):
        pfad, _ = QFileDialog.getSaveFileName(self.fenster, 'Lokal speichern',
                    'hydrus-' + art + ('.json' if art == 'bericht' else '.csv'),
                    'JSON (*.json)' if art == 'bericht' else 'CSV (*.csv)')
        if not pfad:
            return
        try:
            if art == 'bericht':
                Path(pfad).write_text(json.dumps({'pakete': list(self.pakete), 'protokoll': list(self.protokoll)},
                                                ensure_ascii=False, indent=2), encoding='utf-8')
            else:
                daten = list(self.pakete)
                if art == 'messwerte':
                    daten = [dict(zeit=p['zeit'], zaehlerkennung=p['zaehlerkennung'], **f)
                             for p in daten for f in p['felder']]
                else:
                    daten = [{k:v for k,v in p.items() if k != 'felder'} for p in daten]
                namen = list(dict.fromkeys(k for p in daten for k in p))
                with open(pfad, 'w', encoding='utf-8-sig', newline='') as datei:
                    schreiber = csv.DictWriter(datei, fieldnames=namen, delimiter=';')
                    schreiber.writeheader()
                    for p in daten:
                        # Tabellenkalkulationen dürfen Funktexte nicht als Formeln ausführen.
                        schreiber.writerow({k: "'"+v if isinstance(v,str) and v.startswith(('=','+','-','@')) else v
                                            for k,v in p.items()})
            self.melden('meldung', text='Datei gespeichert.')
        except OSError as fehler:
            self.melden('meldung', text=str(fehler))


class LokaleSeite(QWebEnginePage):
    def acceptNavigationRequest(self, url, art, hauptrahmen):
        # Die Brücke zum PC bleibt ausschließlich der lokalen HTML-Datei zugänglich.
        return url.scheme() in ('file', 'qrc', 'about')


def starten():
    app = QApplication(sys.argv)
    app.setApplicationName('HYDRUS · Wassermonitor')
    class Fenster(QMainWindow):
        def closeEvent(self, event):
            if hasattr(self,'empfang') and self.empfang.updateThread and self.empfang.updateThread.isRunning():
                QMessageBox.information(self,'Update','Bitte den laufenden Updatevorgang abwarten.')
                event.ignore()
            else: event.accept()
    fenster = Fenster()
    fenster.setWindowTitle('HYDRUS · Wassermonitor')
    fenster.resize(1280, 900)
    fenster.setMinimumSize(900, 620)
    ansicht = QWebEngineView(fenster)
    seite = LokaleSeite(ansicht)
    ansicht.setPage(seite)
    kanal = QWebChannel(seite)
    empfang = Empfang(fenster)
    fenster.empfang = empfang
    kanal.registerObject('monitor', empfang)
    seite.setWebChannel(kanal)
    url = QUrl.fromLocalFile(str(Path(__file__).with_name('dashboard.html')))
    url.setQuery('pc=1')
    ansicht.setUrl(url)
    fenster.setCentralWidget(ansicht)
    app.aboutToQuit.connect(empfang.trennen)
    fenster.show()
    return app.exec()
