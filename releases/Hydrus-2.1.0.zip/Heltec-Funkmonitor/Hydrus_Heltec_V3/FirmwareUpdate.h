#pragma once
#include <Update.h>
#include <HTTPClient.h>
#include <WiFiClientSecure.h>
#include <mbedtls/pk.h>
#include <mbedtls/sha256.h>
#include <mbedtls/base64.h>
#include <mbedtls/x509_crt.h>
#include "UpdateVertrauen.h"

class FirmwareUpdate {
 public:
  String meldung="Kein Update-Server eingerichtet",angebotVersion;
  bool fertig=false,angebot=false;
  uint32_t neustart=0;
  void starten(){speicher.begin("hydrus-update",false);quelle=speicher.getString("quelle");ca=speicher.getString("ca");if(!quelle.length())quelle="https://raw.githubusercontent.com/Baum1555/hydrus-updates/main/heltec-version.json";if(quelle.length())meldung="Bereit";}
  bool eingerichtet()const{return quelle.length();}
  String server()const{return quelle;}
  bool quelleSetzen(const String &url,const String &zertifikat){
    if(!https(url)||url.length()>512||zertifikat.length()>4096)return false;
    if(zertifikat.length()){mbedtls_x509_crt cert;mbedtls_x509_crt_init(&cert);int err=mbedtls_x509_crt_parse(&cert,(const unsigned char*)zertifikat.c_str(),zertifikat.length()+1);mbedtls_x509_crt_free(&cert);if(err)return false;}
    // Zertifikat zuerst: bei unterbrochener Einrichtung scheitert TLS geschlossen.
    if(speicher.putString("ca",zertifikat)!=zertifikat.length()||speicher.putString("quelle",url)!=url.length())return false;
    ca=zertifikat;quelle=url;meldung="Update-Server gespeichert";angebot=false;return true;
  }
  void pruefen(){
    geprueft=true;letztePruefung=millis();
    angebot=false;angebotVersion="";
    if(!eingerichtet()){meldung="Kein Update-Server eingerichtet";return;}
    WiFiClientSecure netz;if(ca.length())netz.setCACert(ca.c_str());else netz.useBuiltinCACertBundle();netz.setTimeout(8000);HTTPClient h;h.setTimeout(8000);
    if(!h.begin(netz,quelle)||h.GET()!=200){meldung="Versionsdatei nicht erreichbar";h.end();return;}
    if(h.getSize()<1||h.getSize()>10000){meldung="Ungültige Versionsdatei";h.end();return;}
    String text=h.getString();h.end();JsonDocument d;if(deserializeJson(d,text)){meldung="Versionsdatei ungültig";return;}
    uint8_t roh[4096],sig[256];size_t n=0,sn=0;
    const char *r=d["metadaten"]|"",*s=d["signatur"]|"";
    if(mbedtls_base64_decode(roh,sizeof(roh),&n,(const unsigned char*)r,strlen(r))||mbedtls_base64_decode(sig,sizeof(sig),&sn,(const unsigned char*)s,strlen(s))||sn!=256||!metadaten(roh,n,sig)){return;}
    if(!https(downloadUrl)){meldung="Downloadadresse fehlt";return;}
    angebot=true;angebotVersion=version;meldung="Update verfügbar";
  }
  void installieren(){
    if(!angebot){meldung="Zuerst nach Updates suchen";return;}
    const String url=downloadUrl;WiFiClientSecure netz;if(ca.length())netz.setCACert(ca.c_str());else netz.useBuiltinCACertBundle();netz.setTimeout(8000);HTTPClient h;h.setTimeout(8000);
    if(!h.begin(netz,url)||h.GET()!=200){meldung="Download fehlgeschlagen";h.end();return;}
    int laenge=h.getSize();if(laenge<269||laenge>3350000){meldung="Ungültige Downloadgröße";h.end();return;}
    anfang();uint8_t b[1024];int rest=laenge;uint32_t fortschritt=millis();
    while(rest>0&&uint32_t(millis()-fortschritt)<10000){int n=h.getStreamPtr()->available();if(n){n=std::min(n,std::min(rest,1024));int gelesen=h.getStreamPtr()->readBytes(b,n);if(gelesen>0){daten(b,gelesen);rest-=gelesen;fortschritt=millis();if(fehler)break;}}else delay(1);}
    h.end();if(rest){abbrechen("Download unvollständig");return;}ende();
  }
  void anfang(){if(Update.isRunning())Update.abort();fertig=false;fehler=false;kopfLaenge=0;erwarteterKopf=12;empfangen=0;gestartet=false;meldung="Update wird geprüft";}
  void daten(const uint8_t *a,size_t n){
    if(fehler)return;
    while(n && kopfLaenge<erwarteterKopf){kopf[kopfLaenge++]=*a++;--n;
      if(kopfLaenge==12){if(memcmp(kopf,"HYDRUS02",8)){abbrechen("Keine signierte HYDRUS-Datei");return;}uint32_t l=(uint32_t(kopf[8])<<24)|(uint32_t(kopf[9])<<16)|(uint32_t(kopf[10])<<8)|kopf[11];if(l<1||l>4096){abbrechen("Updatekopf ungültig");return;}erwarteterKopf=12+l+256;}
      if(kopfLaenge==erwarteterKopf && erwarteterKopf>12){size_t l=erwarteterKopf-268;if(!metadaten(kopf+12,l,kopf+12+l)){abbrechen(meldung);return;}if(!Update.begin(groesse,U_FLASH)){abbrechen("OTA-Speicher nicht verfügbar");return;}mbedtls_sha256_init(&hash);mbedtls_sha256_starts(&hash,0);gestartet=true;}
    }
    if(n){if(!gestartet||empfangen+n>groesse){abbrechen("Updategröße stimmt nicht");return;}if(Update.write(const_cast<uint8_t*>(a),n)!=n){abbrechen("Firmware konnte nicht geschrieben werden");return;}mbedtls_sha256_update(&hash,a,n);empfangen+=n;}
  }
  void ende(){
    if(fehler)return;if(!gestartet||empfangen!=groesse){abbrechen("Update unvollständig");return;}
    uint8_t summe[32];mbedtls_sha256_finish(&hash,summe);mbedtls_sha256_free(&hash);gestartet=false;
    for(size_t i=0;i<32;++i){char b[3];snprintf(b,sizeof(b),"%02x",summe[i]);if(soll.substring(i*2,i*2+2)!=b){abbrechen("Prüfsumme stimmt nicht");return;}}
    if(!Update.end(false)){abbrechen("Firmware ungültig");return;}
    fertig=true;meldung="Update installiert · Neustart";neustart=millis()+2500;
  }
  void abbrechen(const String &s){if(gestartet){mbedtls_sha256_free(&hash);gestartet=false;}Update.abort();fehler=true;fertig=false;meldung=s;}
  void pflegen(){if(neustart && int32_t(millis()-neustart)>=0)ESP.restart();
    if(eingerichtet() && WiFi.status()==WL_CONNECTED && millis()>60000 && (!geprueft||uint32_t(millis()-letztePruefung)>=86400000) && !Update.isRunning())pruefen();
  }
 private:
  uint32_t letztePruefung=0;bool geprueft=false;
  Preferences speicher;String quelle,ca,downloadUrl,version,soll;uint32_t groesse=0,empfangen=0;
  uint8_t kopf[4364];size_t kopfLaenge=0,erwarteterKopf=12;bool fehler=false,gestartet=false;mbedtls_sha256_context hash;
  static bool https(const String &s){return s.startsWith("https://")&&s.length()>8&&s.indexOf('@')<0&&s.indexOf('\n')<0&&s.indexOf('\r')<0;}
  bool metadaten(const uint8_t *roh,size_t n,const uint8_t *sig){
    uint8_t digest[32];mbedtls_sha256(roh,n,digest,0);mbedtls_pk_context pk;mbedtls_pk_init(&pk);
    bool ok=mbedtls_pk_parse_public_key(&pk,(const unsigned char*)UPDATE_PUBLIC_KEY,strlen(UPDATE_PUBLIC_KEY)+1)==0 &&
      mbedtls_pk_verify(&pk,MBEDTLS_MD_SHA256,digest,32,sig,256)==0;mbedtls_pk_free(&pk);
    if(!ok){meldung="Signatur ungültig";return false;}
    JsonDocument d;if(deserializeJson(d,roh,n)){meldung="Updatekopf ungültig";return false;}
    if(String(d["produkt"]|"")!="heltec-v3"||!d["build"].is<uint32_t>()||d["build"].as<uint32_t>()<=FIRMWARE_BUILD){meldung="Keine neuere passende Firmware";return false;}
    groesse=d["groesse"]|0;soll=d["sha256"]|"";version=d["version"]|"";downloadUrl=d["url"]|"";
    if(!groesse||groesse>3342336||soll.length()!=64){meldung="Updategröße oder Prüfsumme ungültig";return false;}
    for(char c:soll)if(!isxdigit(c)){meldung="Prüfsumme ungültig";return false;}soll.toLowerCase();return true;
  }
};
