#pragma once
#include <WiFiClientSecure.h>
#include <HTTPClient.h>
#include <Preferences.h>
#include <ArduinoJson.h>

// Bewusst aus, bis der Benutzer Server/Thema eingerichtet und aktiviert hat.
// Warteschlange und Konfiguration getrennt; kein Schlüssel wird zurückgegeben.
class HandyMitteilung {
 public:
  String meldung="Ausgeschaltet";
  void starten(){
    nvs.begin("hydrus-push",false);JsonDocument d;
    if(!deserializeJson(d,nvs.getString("config"))){aktiv=d["aktiv"]|false;server=d["server"]|"https://ntfy.sh";thema=d["thema"]|"";schluessel=d["token"]|"";}
    JsonDocument q;if(!deserializeJson(q,nvs.getString("queue")))for(JsonVariant x:q.as<JsonArray>()){if(anzahl==8)break;wartend[anzahl++]=x.as<String>();}
    meldung=aktiv?"Bereit":"Ausgeschaltet";
  }
  bool einstellen(bool an,const String &url,const String &topic,const String &key,bool loeschen){
    if(url.length()>200||!url.startsWith("https://")||url.indexOf('@')>=0||url.indexOf('?')>=0||url.indexOf('#')>=0||url.indexOf('\n')>=0||url.indexOf('\r')>=0)return false;
    if(topic.length()>64||(an&&!topic.length())||key.length()>256)return false;
    for(char c:topic)if(!isalnum((unsigned char)c)&&c!='_'&&c!='-')return false;
    for(char c:key)if(c<=32||c>=127)return false;
    String neuKey=loeschen?String(""):(key.length()?key:schluessel);
    JsonDocument d;d["aktiv"]=an;d["server"]=url;d["thema"]=topic;d["token"]=neuKey;String s;serializeJson(d,s);
    if(nvs.putString("config",s)!=s.length())return false;
    // Ein anderer Empfänger erhält keine alten Nachrichten.
    if(server!=url||thema!=topic||!an){anzahl=0;queueSpeichern();}
    aktiv=an;server=url;thema=topic;schluessel=neuKey;meldung=aktiv?"Bereit":"Ausgeschaltet";return true;
  }
  bool merken(const String &text){
    if(!aktiv)return false;
    if(anzahl==8){meldung="Nachrichtenwarteschlange voll";return false;}
    wartend[anzahl++]=text.substring(0,220);queueSpeichern();return true;
  }
  void pflegen(){
    if(!aktiv||!anzahl||WiFi.status()!=WL_CONNECTED||time(nullptr)<1700000000||uint32_t(millis()-versuch)<60000)return;
    versuch=millis();
    WiFiClientSecure netz;netz.useBuiltinCACertBundle();netz.setHandshakeTimeout(5);HTTPClient h;h.setConnectTimeout(4000);h.setTimeout(4000);
    String url=server;if(!url.endsWith("/"))url+="/";
    if(!h.begin(netz,url)){meldung="Nachrichtendienst nicht erreichbar";return;}
    h.addHeader("Content-Type","application/json");if(schluessel.length())h.addHeader("Authorization","Bearer "+schluessel);
    JsonDocument d;d["topic"]=thema;d["title"]="HYDRUS";d["message"]=wartend[0];d["priority"]=4;String body;serializeJson(d,body);
    int code=h.POST(body);h.end();
    if(code>=200&&code<300){for(int i=1;i<anzahl;++i)wartend[i-1]=wartend[i];--anzahl;queueSpeichern();meldung="Vom Nachrichtendienst angenommen";}
    else meldung="Versand fehlgeschlagen ("+String(code)+") · erneuter Versuch";
  }
  void json(JsonObject d)const{d["aktiv"]=aktiv;d["server"]=server;d["thema"]=thema;d["token_vorhanden"]=bool(schluessel.length());d["wartend"]=anzahl;d["meldung"]=meldung;}
 private:
  Preferences nvs;bool aktiv=false;String server="https://ntfy.sh",thema,schluessel,wartend[8];int anzahl=0;uint32_t versuch=0;
  void queueSpeichern(){JsonDocument d;JsonArray a=d.to<JsonArray>();for(int i=0;i<anzahl;++i)a.add(wartend[i]);String s;serializeJson(d,s);if(nvs.putString("queue",s)!=s.length())meldung="Nachrichten nicht dauerhaft gespeichert";}
};
inline HandyMitteilung Handy;
