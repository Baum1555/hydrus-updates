#pragma once
#include <LittleFS.h>
#include <ArduinoJson.h>
#include <time.h>

// Zwei begrenzte Dateien. Beginn/Ende erhalten eine gemeinsame Kennung.
class EreignisVerlauf {
 public:
  String fehler;
  uint32_t revision=0;
  void (*nachricht)(const String &)=nullptr;
  void starten(){boot=esp_random();}
  void pruefen(JsonArrayConst zustand,bool speicherBereit){
    if(!speicherBereit)return;
    if(!gestartet){gestartet=true;schreiben("","Gerät","neustart","info","",0,"Überwachung neu gestartet");}
    for(JsonObjectConst o:zustand){
      const char *id=o["id"]|"";if(!*id)continue;
      int i=-1;for(int j=0;j<8;++j)if(!strcmp(status[j].id,id)){i=j;break;}
      if(i<0)for(int j=0;j<8;++j)if(!status[j].id[0]){i=j;strlcpy(status[j].id,id,9);break;}
      if(i<0)continue;
      const bool aktiv[]={o["leckverdacht"]|false,o["empfang_fehlt"]|false,o["zaehler_ruecksprung"]|false};
      const char *arten[]={"leck","empfang","ruecksprung"};
      const char *texte[]={"Leckverdacht: anhaltender Durchfluss","Kein Zählerempfang","Zählerstand zurückgesetzt"};
      auto &s=status[i];
      for(int a=0;a<3;++a){
        if(aktiv[a]==s.aktiv[a])continue;
        String name=o["name"]|id;
        if(aktiv[a]){
          s.beginn[a]=millis();s.vorlauf[a]=a==0?(o["leck_seit_s"]|0u):0;
          s.vorgang[a]=String(boot)+"-"+String(++nummer);
          schreiben(id,name,arten[a],"beginn",s.vorgang[a],s.vorlauf[a],texte[a]);
          if(nachricht)nachricht(name+": "+texte[a]);
        }else{
          uint32_t dauer=s.vorlauf[a]+uint32_t(millis()-s.beginn[a])/1000;
          const bool unklar=a==0&&((o["empfang_fehlt"]|false)||(o["durchfluss_unbekannt"]|false)||!(o["leck_aktiv"]|true));
          String text=a==1?"Zählerempfang wieder vorhanden":a==0?(unklar?"Leckprüfung unterbrochen":"Dauerverbrauch beendet"):"Zähler neu bewertet";
          schreiben(id,name,arten[a],unklar?"unterbrochen":"ende",s.vorgang[a],dauer,text);
          if(nachricht && a<2)nachricht(name+": "+text+" ("+String(dauer)+" s)");
        }
        s.aktiv[a]=aktiv[a];
      }
    }
  }
  void senden(WebServer &http){
    http.sendHeader("Cache-Control","no-store");http.setContentLength(CONTENT_LENGTH_UNKNOWN);http.send(200,"application/x-ndjson","");
    for(const char *p:{"/ereignisse-1.jsonl","/ereignisse-0.jsonl"}){
      File f=LittleFS.open(p,"r");if(!f)continue;char b[1024];while(f.available()){size_t n=f.readBytes(b,sizeof(b));if(!n)break;http.sendContent(b,n);}http.sendContent("\n");
    }
    http.sendContent("");
  }
 private:
  struct Status{char id[9]={};bool aktiv[3]={};uint32_t beginn[3]={},vorlauf[3]={};String vorgang[3];}status[8];
  uint32_t boot=0,nummer=0;bool gestartet=false;
  void schreiben(const char *id,const String &name,const char *art,const char *phase,const String &vorgang,uint32_t dauer,const String &text){
    JsonDocument d;time_t zeit=time(nullptr);if(zeit>=1700000000)d["zeit"]=int64_t(zeit);else d["zeit"]=nullptr;
    d["boot"]=boot;d["laufzeit_s"]=millis()/1000;d["id"]=id;d["name"]=name;d["art"]=art;d["phase"]=phase;d["vorgang"]=vorgang;d["dauer_s"]=dauer;d["text"]=text;
    String zeile;serializeJson(d,zeile);zeile="\n"+zeile+"\n";
    const char *p="/ereignisse-0.jsonl",*alt="/ereignisse-1.jsonl";
    File f=LittleFS.open(p,"r");size_t n=f?f.size():0;f.close();
    if(n+zeile.length()>65536){
      if(LittleFS.exists(alt)&&!LittleFS.remove(alt)){fehler="Ereignisarchiv nicht beschreibbar";return;}
      if(!LittleFS.rename(p,alt)){fehler="Ereignisrotation fehlgeschlagen";return;}
    }
    f=LittleFS.open(p,"a");if(!f||f.print(zeile)!=zeile.length()){fehler="Ereignis konnte nicht gespeichert werden";return;}
    f.close();fehler="";++revision;
  }
};
