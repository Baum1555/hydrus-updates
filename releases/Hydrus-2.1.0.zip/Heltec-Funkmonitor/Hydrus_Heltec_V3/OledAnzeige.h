#pragma once
#include <Arduino.h>
#include <Wire.h>
#include "HeltecPins.h"

// Kleine Textanzeige für das eingebaute SSD1306, ohne weitere Bibliothek.
// Ausschließlich die Hauptaufgabe nutzt I2C; die Funkaufgabe wird nicht aufgehalten.
class OledAnzeige {
 public:
  bool starten() {
    pinMode(PIN_OLED_STROM, OUTPUT);
    digitalWrite(PIN_OLED_STROM, LOW);
    pinMode(PIN_OLED_RESET, OUTPUT);
    digitalWrite(PIN_OLED_RESET, LOW);
    delay(20);
    digitalWrite(PIN_OLED_RESET, HIGH);
    delay(20);
    Wire.begin(PIN_OLED_SDA, PIN_OLED_SCL, 400000);
    Wire.setTimeOut(20);
    const uint8_t einrichtung[] = {0xAE, 0xD5, 0x80, 0xA8, 0x3F, 0xD3, 0,
      0x40, 0x8D, 0x14, 0x20, 0x02, 0xA1, 0xC8, 0xDA, 0x12,
      0x81, 0x7F, 0xD9, 0xF1, 0xDB, 0x40, 0xA4, 0xA6, 0xAF};
    bereit = senden(0, einrichtung, sizeof(einrichtung));
    return bereit;
  }

  void leeren() { memset(bild, 0, sizeof(bild)); }

  void zeile(uint8_t nummer, const char *text) {
    if (nummer >= 8) return;
    // 21 Zeichen mit je 5 Pixeln und einer leeren Spalte passen nebeneinander.
    for (size_t stelle = 0; stelle < 21 && text[stelle]; ++stelle) {
      char zeichen = text[stelle];
      if (zeichen >= 'a' && zeichen <= 'z') zeichen -= 'a' - 'A';
      for (uint8_t spalte = 0; spalte < 5; ++spalte)
        bild[nummer * 128 + stelle * 6 + spalte] = pixel(zeichen, spalte);
    }
  }

  bool anzeigen() {
    if (!bereit) return false;
    for (uint8_t seite = 0; seite < 8; ++seite) {
      const uint8_t adresse[] = {static_cast<uint8_t>(0xB0 | seite), 0x00, 0x10};
      if (!senden(0, adresse, sizeof(adresse))) { bereit = false; return false; }
      for (uint8_t spalte = 0; spalte < 128; spalte += 16)
        if (!senden(0x40, bild + seite * 128 + spalte, 16)) { bereit = false; return false; }
    }
    return true;
  }

 private:
  bool bereit = false;
  uint8_t bild[1024] = {};

  bool senden(uint8_t steuerung, const uint8_t *daten, size_t laenge) {
    Wire.beginTransmission(OLED_ADRESSE);
    Wire.write(steuerung);
    Wire.write(daten, laenge);
    return Wire.endTransmission() == 0;
  }

  static uint8_t pixel(char zeichen, uint8_t spalte) {
    // Spaltenweise 5x7-Schrift: Ziffern, Großbuchstaben und Statuszeichen.
    static const uint8_t schrift[][5] = {
      {0x3E,0x51,0x49,0x45,0x3E},{0,0x42,0x7F,0x40,0},
      {0x42,0x61,0x51,0x49,0x46},{0x21,0x41,0x45,0x4B,0x31},
      {0x18,0x14,0x12,0x7F,0x10},{0x27,0x45,0x45,0x45,0x39},
      {0x3C,0x4A,0x49,0x49,0x30},{1,0x71,9,5,3},
      {0x36,0x49,0x49,0x49,0x36},{6,0x49,0x49,0x29,0x1E},
      {0x7E,0x11,0x11,0x11,0x7E},{0x7F,0x49,0x49,0x49,0x36},
      {0x3E,0x41,0x41,0x41,0x22},{0x7F,0x41,0x41,0x22,0x1C},
      {0x7F,0x49,0x49,0x49,0x41},{0x7F,9,9,9,1},
      {0x3E,0x41,0x49,0x49,0x7A},{0x7F,8,8,8,0x7F},
      {0,0x41,0x7F,0x41,0},{0x20,0x40,0x41,0x3F,1},
      {0x7F,8,0x14,0x22,0x41},{0x7F,0x40,0x40,0x40,0x40},
      {0x7F,2,0x0C,2,0x7F},{0x7F,4,8,0x10,0x7F},
      {0x3E,0x41,0x41,0x41,0x3E},{0x7F,9,9,9,6},
      {0x3E,0x41,0x51,0x21,0x5E},{0x7F,9,0x19,0x29,0x46},
      {0x46,0x49,0x49,0x49,0x31},{1,1,0x7F,1,1},
      {0x3F,0x40,0x40,0x40,0x3F},{0x1F,0x20,0x40,0x20,0x1F},
      {0x3F,0x40,0x38,0x40,0x3F},{0x63,0x14,8,0x14,0x63},
      {7,8,0x70,8,7},{0x61,0x51,0x49,0x45,0x43}
    };
    if (zeichen >= '0' && zeichen <= '9') return schrift[zeichen - '0'][spalte];
    if (zeichen >= 'A' && zeichen <= 'Z') return schrift[10 + zeichen - 'A'][spalte];
    if (zeichen == '-') return 8;
    if (zeichen == '.') return spalte == 2 ? 0x60 : 0;
    if (zeichen == ':') return spalte == 2 ? 0x36 : 0;
    if (zeichen == '/') return static_cast<uint8_t>(0x40 >> spalte);
    return 0;
  }
};
