function updateAnzeige(d){
  if(d.version)$('updateVersion').textContent='Version '+d.version;
  $('updateStatus').textContent=d.meldung||d.text||'Bereit';
  if(d.url!==undefined)$('updateUrl').value=d.url;
  if(d.server!==undefined)$('updateUrl').value=d.server;
  if(d.angebot!==undefined)$('updateInstallieren').disabled=!d.angebot;
  if(d.pfad)$('updateNeustart').classList.remove('hidden');
}
async function updateAnfrage(pfad,body){
  if(!token)await entsperren();
  let r=await fetch(pfad,{method:'POST',headers:{'X-Hydrus-Token':token},body,signal:AbortSignal.timeout(180000)});
  if(!r.ok)throw Error(await r.text());
  if((r.headers.get('content-type')||'').includes('json'))updateAnzeige(await r.json());else melden(await r.text());
}
const vorherZeigen=zeigen;
zeigen=function(tab){vorherZeigen(tab);if(tab==='updates'&&!pc)fetch('/api/update',{cache:'no-store'}).then(r=>r.json()).then(updateAnzeige).catch(()=>melden('Heltec nicht erreichbar'));};
$('updatePruefen').onclick=async()=>{try{if(pc){bridge.updatePruefen($('updateUrl').value);return;}await updateAnfrage('/api/update/pruefen',new URLSearchParams());}catch(e){melden(e.message)}};
$('updateInstallieren').onclick=async()=>{if(!confirm('Update installieren?'))return;try{if(pc){bridge.updateInstallieren();return;}await updateAnfrage('/api/update/installieren',new URLSearchParams());}catch(e){melden(e.message)}};
$('updateNeustart').onclick=()=>bridge.updateStarten();
$('updateDateiPc').onclick=()=>bridge.updateDatei();
$('updateDateiForm').onsubmit=async e=>{e.preventDefault();let f=$('updateDatei').files[0];if(!f)return;if(!confirm('Firmware installieren und Heltec neu starten?'))return;let b=new FormData();b.append('datei',f);let button=$('updateDateiSenden');button.disabled=true;$('updateStatus').textContent='Update läuft …';try{await updateAnfrage('/api/update/datei',b);}catch(err){melden(err.message)}finally{button.disabled=false}};
$('updateQuelle').onclick=async()=>{try{if(pc){bridge.updatePruefen($('updateUrl').value);return;}await updateAnfrage('/api/update/quelle',new URLSearchParams({url:$('updateUrl').value,ca:$('updateCa').value}));}catch(e){melden(e.message)}};
if(pc){$('updateDateiForm').classList.add('hidden');$('caGruppe').classList.add('hidden');}else{$('updateDateiPc').classList.add('hidden');}
