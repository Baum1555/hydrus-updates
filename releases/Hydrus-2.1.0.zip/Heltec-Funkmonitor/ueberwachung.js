// Ereignisse vom Gerät; Messvergleich lokal im geöffneten Browser/PC.
const monitoringKnopf=document.createElement('button');monitoringKnopf.dataset.tab='ueberwachung';monitoringKnopf.textContent='◇ Überwachung';
document.querySelector('nav .tabs').append(monitoringKnopf);
const monitoring=document.createElement('section');monitoring.id='ueberwachung';monitoring.className='section';
monitoring.innerHTML=`<div class="card"><div class="row spread"><h2>Ereignisse</h2><div class="row"><button id="ereignisseNeu">Aktualisieren</button><button id="ereignisseExport">CSV exportieren</button></div></div><p id="ereignisseStatus" class="statusline">Noch nicht geladen</p><div class="scroll"><table><thead><tr><th>Zeit</th><th>Zähler</th><th>Ereignis</th><th>Dauer</th></tr></thead><tbody id="ereignisseTabelle"></tbody></table></div></div>
<div class="card below"><h2>Messwerte vergleichen</h2><p class="statusline">Zähler in der Übersicht auswählen. Während der Messung nur eine bekannte Wassermenge entnehmen.</p><div class="row"><button id="vergleichStart">1. Startwert übernehmen</button><button id="vergleichEnde" disabled>2. Entnahme beendet</button><button id="vergleichAbbrechen">Abbrechen</button></div><p id="vergleichStatus" class="statusline">Noch keine Messung</p><form id="vergleichForm" class="form"><label>Entnommene Menge (Liter)<input id="vergleichLiter" type="number" min="0.001" step="any" value="10" required></label><label>Abgelesener Endstand am Zähler (m³, optional)<input id="vergleichDisplay" type="number" min="0" step="any"></label><button>3. Vergleich berechnen</button></form><pre id="vergleichErgebnis" class="hidden"></pre></div>
<div class="card below"><h2>Handy-Mitteilungen</h2><div id="pushPc" class="hidden"><button id="pushWeb">Am Gerät einrichten</button></div><div id="pushWebForm"><button id="pushLaden">Einstellungen laden</button><form id="pushForm" class="form below"><label><span><input id="pushAktiv" type="checkbox"> Aktiv</span></label><label>ntfy-Server<input id="pushServer" type="url" value="https://ntfy.sh" required></label><label>Thema<input id="pushThema" pattern="[A-Za-z0-9_-]+" maxlength="64"></label><label>Zugriffstoken (optional)<input id="pushToken" type="password" autocomplete="new-password" maxlength="256"></label><label><span><input id="pushLoeschen" type="checkbox"> Gespeicherten Token entfernen</span></label><button>Speichern</button></form><button id="pushTest" class="below">Testnachricht senden</button></div><p id="pushStatus" class="statusline">Ausgeschaltet</p></div>`;
document.querySelector('main').append(monitoring);
let ereignisDaten=[],ereignisLaedt=false,ereignisStand=null,vergleich=null,letzterBoot=null;
const vorherMonitoringZeigen=zeigen;
zeigen=function(tab){vorherMonitoringZeigen(tab);if(tab==='ueberwachung'){$('seitentitel').textContent='Überwachung';ereignisseLaden();}};
monitoringKnopf.onclick=()=>zeigen('ueberwachung');
function ereignisseLesen(text){
  ereignisDaten=[];let defekt=0;
  for(const z of text.split('\n')){if(!z.trim())continue;try{const e=JSON.parse(z);if(typeof e.art!=='string'||typeof e.text!=='string')throw Error();ereignisDaten.push(e);}catch(e){defekt++;}}
  $('ereignisseTabelle').replaceChildren();
  for(const e of ereignisDaten.slice(-300).reverse()){
    const zeit=e.zeit?new Date(e.zeit*1000).toLocaleString('de-DE'):'Start '+e.boot+' · '+e.laufzeit_s+' s';
    zeile($('ereignisseTabelle'),[zeit,e.name||e.id||'Gerät',e.text,e.art==='neustart'?'—':e.dauer_s+' s']);
  }
  $('ereignisseStatus').textContent=ereignisDaten.length+' Einträge'+(defekt?' · '+defekt+' beschädigte Zeilen übersprungen':'');
}
async function ereignisseLaden(){
  if(ereignisLaedt)return;ereignisLaedt=true;
  try{if(pc){if(bridge)bridge.ereignisseLaden($('adresse').value);return;}
    const r=await fetch('/api/ereignisse',{cache:'no-store',signal:AbortSignal.timeout(30000)});if(!r.ok)throw Error('Ereignisse nicht erreichbar');ereignisseLesen(await r.text());
  }catch(e){$('ereignisseStatus').textContent=e.message;}finally{ereignisLaedt=false;}
}
const vorherMonitoringEreignis=ereignis;
ereignis=function(raw){let e=typeof raw==='string'?JSON.parse(raw):raw;if(e.typ==='ereignisse'){ereignisseLesen(e.text);return;}vorherMonitoringEreignis(raw);};
$('ereignisseNeu').onclick=ereignisseLaden;
$('ereignisseExport').onclick=()=>{
  const esc=x=>'"'+String(x??'').replaceAll('"','""')+'"';
  const text='Zeit;Startkennung;Laufzeit_s;Kennung;Name;Art;Phase;Vorgang;Dauer_s;Text\r\n'+ereignisDaten.map(e=>[e.zeit?new Date(e.zeit*1000).toISOString():'',e.boot,e.laufzeit_s,e.id,e.name,e.art,e.phase,e.vorgang,e.dauer_s,e.text].map(esc).join(';')).join('\r\n');
  if(pc){bridge.verlaufExportieren(text);return;}let u=URL.createObjectURL(new Blob(['\ufeff'+text],{type:'text/csv;charset=utf-8'})),a=document.createElement('a');a.href=u;a.download='hydrus-ereignisse.csv';a.click();setTimeout(()=>URL.revokeObjectURL(u),1000);
};
function vergleichVerwerfen(text){vergleich=null;$('vergleichEnde').disabled=true;$('vergleichStatus').textContent=text;}
function aktuellerVergleichswert(){
  const o=zaehler.get(wahl),v=feldwert(o?.felder||[],['Volumen']);
  if(!online||!o||!v||Date.now()-o.zeit>120000)throw Error('Aktuellen entschlüsselten Zählerstand abwarten');
  return {id:wahl,stand:Number(v.wert),seq:o.seq,zeit:o.zeit,boot:letzterBoot};
}
$('vergleichStart').onclick=()=>{try{vergleich={start:aktuellerVergleichswert(),wartet:false};$('vergleichEnde').disabled=false;$('vergleichErgebnis').classList.add('hidden');$('vergleichStatus').textContent='Start: '+vergleich.start.stand.toLocaleString('de-DE')+' m³ · jetzt bekannte Menge entnehmen';}catch(e){melden(e.message)}};
$('vergleichEnde').onclick=()=>{try{if(!vergleich)throw Error('Zuerst Startwert übernehmen');const aktuell=aktuellerVergleichswert();if(aktuell.id!==vergleich.start.id)throw Error('Zähler gewechselt');vergleich.wartet=true;vergleich.nachSeq=aktuell.seq;$('vergleichEnde').disabled=true;$('vergleichStatus').textContent='Warte auf das nächste Telegramm nach der Entnahme …';}catch(e){vergleichVerwerfen(e.message)}};
$('vergleichAbbrechen').onclick=()=>vergleichVerwerfen('Messung abgebrochen');
function vergleichBerechnen(start,ende,liter,display=null){
  if(!Number.isFinite(liter)||liter<=0||!Number.isFinite(start.stand)||!Number.isFinite(ende.stand)||ende.stand<start.stand||start.id!==ende.id)throw Error('Messwerte oder Menge ungültig');
  const gemessen=(ende.stand-start.stand)*1000,abweichung=gemessen-liter;
  return {kennung:start.id,start_m3:start.stand,ende_m3:ende.stand,soll_l:liter,gemessen_l:gemessen,abweichung_l:abweichung,abweichung_prozent:100*abweichung/liter,display_abweichung_l:display===null?null:(ende.stand-display)*1000};
}
$('vergleichForm').onsubmit=e=>{e.preventDefault();try{
  if(!vergleich?.ende)throw Error('Zuerst Entnahme beenden und neues Telegramm abwarten');
  const display=$('vergleichDisplay').value===''?null:Number($('vergleichDisplay').value);
  let r=vergleichBerechnen(vergleich.start,vergleich.ende,Number($('vergleichLiter').value),display);
  if(display!==null&&!Number.isFinite(display))throw Error('Displaywert ungültig');
  const f=x=>x.toLocaleString('de-DE',{maximumFractionDigits:3});
  $('vergleichErgebnis').textContent='Zähler '+r.kennung+'\nEntnommen: '+f(r.soll_l)+' l\nPer Funk erfasst: '+f(r.gemessen_l)+' l\nAbweichung: '+f(r.abweichung_l)+' l ('+f(r.abweichung_prozent)+' %)'+(r.display_abweichung_l===null?'':'\nAbweichung zum Display: '+f(r.display_abweichung_l)+' l')+'\nDie Auflösung und das Sendeintervall beeinflussen den Vergleich. Keine automatische Änderung der Messwerte.';
  $('vergleichErgebnis').classList.remove('hidden');localStorage.setItem('hydrus-letzter-vergleich',JSON.stringify({erstellt:new Date().toISOString(),...r,text:$('vergleichErgebnis').textContent}));
}catch(err){melden(err.message)}};
try{const alt=JSON.parse(localStorage.getItem('hydrus-letzter-vergleich'));if(alt?.text){$('vergleichErgebnis').textContent='Letzter Vergleich · '+new Date(alt.erstellt).toLocaleString('de-DE')+'\n'+alt.text;$('vergleichErgebnis').classList.remove('hidden');}}catch(e){}
const vorherMonitoringAufnehmen=aufnehmen;
aufnehmen=function(e){vorherMonitoringAufnehmen(e);if(!vergleich||vergleich.ende)return;
  if(Date.now()-vergleich.start.zeit>1200000){vergleichVerwerfen('Messung abgelaufen – neu beginnen');return;}
  if(e.paket.zaehlerkennung!==vergleich.start.id)return;
  if(e.paket.geraetestatus?.empfang_fehlt||e.paket.geraetestatus?.zaehler_ruecksprung){vergleichVerwerfen('Messung durch Empfangsausfall oder Zählerrücksprung unterbrochen');return;}
  if(vergleich.wartet)try{const end=aktuellerVergleichswert();if(end.seq!==vergleich.nachSeq){vergleich.ende=end;vergleich.wartet=false;$('vergleichStatus').textContent='Endwert: '+end.stand.toLocaleString('de-DE')+' m³ · entnommene Menge eintragen';}}catch(e){vergleichVerwerfen(e.message)}
};
const vorherMonitoringVerbindung=verbindung;
verbindung=function(an,text){vorherMonitoringVerbindung(an,text);if(!an&&vergleich&&!vergleich.ende)vergleichVerwerfen('Verbindung unterbrochen – Messung neu beginnen');};
const vorherMonitoringStatus=komfortStatus;
komfortStatus=function(j){vorherMonitoringStatus(j);
  if(letzterBoot!==null&&j.boot!==letzterBoot&&vergleich&&!vergleich.ende)vergleichVerwerfen('Heltec neu gestartet – Messung neu beginnen');letzterBoot=j.boot;
  if(j.ereignisse_fehler)$('ereignisseStatus').textContent=j.ereignisse_fehler;
  if(j.mitteilung_status)$('pushStatus').textContent=j.mitteilung_status;
  if(j.ereignisse_revision!==ereignisStand&&monitoring.classList.contains('active')){ereignisStand=j.ereignisse_revision;ereignisseLaden();}
};
async function pushAnfrage(pfad,body){if(!token)await entsperren();const r=await fetch(pfad,{method:'POST',headers:{'X-Hydrus-Token':token},body,signal:AbortSignal.timeout(10000)});let t=await r.text();if(!r.ok)throw Error(t);$('pushStatus').textContent=t;}
$('pushLaden').onclick=async()=>{try{let r=await fetch('/api/mitteilung',{cache:'no-store'});if(!r.ok)throw Error('Einstellungen nicht erreichbar');let d=await r.json();$('pushAktiv').checked=d.aktiv;$('pushServer').value=d.server;$('pushThema').value=d.thema;$('pushToken').value='';$('pushStatus').textContent=d.meldung+' · '+d.wartend+' vorgemerkt'+(d.token_vorhanden?' · Token gespeichert':'');}catch(e){melden(e.message)}};
$('pushForm').onsubmit=async e=>{e.preventDefault();try{await pushAnfrage('/api/mitteilung',new URLSearchParams({aktiv:$('pushAktiv').checked?'1':'0',server:$('pushServer').value,thema:$('pushThema').value,token:$('pushToken').value,loeschen:$('pushLoeschen').checked?'1':'0'}));$('pushToken').value='';$('pushLoeschen').checked=false;}catch(err){melden(err.message)}};
$('pushTest').onclick=async()=>{try{await pushAnfrage('/api/mitteilung/test',new URLSearchParams());}catch(e){melden(e.message)}};
if(pc){$('pushWebForm').classList.add('hidden');$('pushPc').classList.remove('hidden');$('pushWeb').onclick=()=>bridge.webOeffnen($('adresse').value);}
