# HYDRUS-Updates herausgeben

Version 2.1.0, Build 2026092403. Download-Repository: https://github.com/Baum1555/hydrus-updates

Der private Herausgeberschlüssel bleibt ausschließlich auf dem Entwicklungs-PC im Arbeitsordner work/update-signatur/privat.pem. Separat sichern und niemals ins Repository oder Installationspaket kopieren. Das ist kein AES-Zählerschlüssel. update-public.pem und UpdateVertrauen.h enthalten nur den öffentlichen Prüfschlüssel.

## Neue Version

1. Versionsnummer und eine größere Buildnummer in UpdateVertrauen.h und updatepaket.py setzen.
2. Arduino-Anwendungs-BIN exportieren, nicht merged.bin oder Bootloader. Keine persönlichen Zählerschlüssel, WLAN-Zugangsdaten oder privaten Signaturschlüssel einbauen. Individuelle WlanZugang.h-Anpassungen nicht veröffentlichen.
3. PC-ZIP mit oberstem Ordner Heltec-Funkmonitor erzeugen. Alle Programmdateien, Bibliotheken und update-public.pem beilegen, keine virtuelle Python-Umgebung oder Nutzerprotokolle.
4. Mit release_erstellen.py beide Pakete signieren. Die eingebauten Versionsnummern müssen mit den Paketangaben übereinstimmen.

Beispiel für die nächste Version:

```text
python release_erstellen.py paket --privat "PFAD/privat.pem" --datei "Hydrus_Heltec_V3.ino.bin" --ausgabe "heltec-2.1.1.hup" --produkt heltec-v3 --version 2.1.1 --build 2026092501 --url "https://raw.githubusercontent.com/Baum1555/hydrus-updates/main/releases/heltec-2.1.1.hup"
```

Für PC entsprechend --produkt pc, ZIP als --datei und pc-2.1.1.hup als Ausgabe/URL. Das Werkzeug erzeugt .hup und .json. Versionierte Pakete unter releases/ hochladen; die erzeugten JSON-Dateien als heltec-version.json und pc-version.json in den Repository-Hauptordner kopieren. Alle Dateien in einem Commit veröffentlichen, sodass kein Manifest auf eine fehlende Datei zeigt. Den vorhandenen privaten Schlüssel weiterverwenden.

GitHub-Raw liefert die Downloads über HTTPS; keine GitHub-Anmeldedaten auf dem Heltec nötig. Beide Programme prüfen Signatur, Produkt, Buildnummer, Länge und SHA-256. Nur höhere Builds werden installiert. Der Update-Server überträgt keine persönlichen Zählerdaten. Öffentliche Firmware verwendet das dokumentierte Standard-Accesspoint-Passwort; für individuelle Firmware selbst kompilieren und signieren.

Ältere 2.0-Firmware verlangt noch ein CA-Zertifikat für Online-Updates. Dort zunächst die signierte 2.1.0-.hup-Datei lokal im Update-Tab installieren oder die INO über USB hochladen. Ab 2.1 werden die eingebauten öffentlichen Stammzertifikate verwendet. Die lokale Datei-Installation funktioniert unabhängig vom Online-Server.
