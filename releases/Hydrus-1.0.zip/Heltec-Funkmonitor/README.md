# HYDRUS Wassermonitor – Version 1.0

Wasserzähler lokal mit Heltec V3 empfangen, Messwerte im Handy-Browser oder Windows-Programm ansehen. Für verschlüsselte Messwerte wird der AES-Schlüssel des Wasserversorgers benötigt.

## Start

PC: Ordner entpacken und `starten.bat` ausführen. Die Einrichtung installiert benötigte Python-Pakete.

Heltec: `Hydrus_Heltec_V3/Hydrus_Heltec_V3.ino` in Arduino öffnen. Alternativ auf einem bereits eingerichteten Gerät die signierte HUP-Datei unter Updates installieren. Vorhandene Daten bleiben bei einem normalen Update erhalten. Die interne Buildnummer ist höher als bei 2.1.15; dadurch wird auch die neue Versionsnummer 1.0 als Update erkannt.

## WLAN

Werkseinstellungen:
- WLAN-Name: **HYDRUS-Monitor**
- WLAN-Passwort: **123456789**
- Webseite: **http://192.168.4.1/**

Der Access Point bleibt auch bei Verbindung mit dem Heimnetz aktiv. Unter Einstellungen → WLAN lassen sich Heimnetz-Zugang, Access-Point-Name und Passwort ändern. Ein leeres Passwortfeld beim Access Point lässt das vorhandene Passwort unverändert. Nach Speichern startet der Heltec neu; anschließend mit dem neuen WLAN-Namen verbinden. Gespeicherte Zugangsdaten bleiben bei Firmware-Updates erhalten.

## Zähler

Im Auslieferungszustand sind keine Zähler, AES-Schlüssel oder Messwerte vorgegeben. Unter Übersicht → Zähler verwalten einen Zähler anlegen. Warnschwellen separat unter Leckwarnung einstellen festlegen.

## PRG-Taste

- Kurz: nächsten Zähler anzeigen.
- Doppelt: zwischen Messwerten und Netzwerkübersicht wechseln.
- Drei Sekunden halten: Access-Point-Adresse anzeigen.
- Zehn Sekunden halten: Rückfrage „Werkseinstellungen? Alles löschen?“ anzeigen. Taste loslassen und nochmals kurz drücken, um zu bestätigen. Ohne Bestätigung wird nach 20 Sekunden abgebrochen. Ein Doppeldruck bricht ebenfalls ab.

Nach Bestätigung werden sämtliche gespeicherten Geräteeinstellungen, Heimnetz- und AP-Zugangsdaten, Zähler/AES-Schlüssel, Warnschwellen, Verbrauchssummen, Messwert- und Ereignisverlauf sowie Benachrichtigungs- und Update-Einstellungen gelöscht. Der Heltec startet mit den obigen WLAN-Werkseinstellungen und leerer Zählerliste neu. Firmware bleibt installiert. Exportierte Dateien auf PC oder Handy werden nicht gelöscht.

Den Reset-Auftrag führt das Gerät beim Neustart vor Funk- und Webdiensten aus. Bei einem Löschfehler zeigt das OLED einen Fehler; Neustart wiederholt einen noch gespeicherten Auftrag. Hardwaretests zu Stromausfall und Flashfehlern stehen aus.

## Dateien

- `Hydrus_Heltec_V3`: Arduino-Sketch und alle dazugehörigen Header.
- `starten.bat`: PC-Programm starten und bei Bedarf einrichten.
- `PRUEFSTAND.md`: durchgeführte Prüfungen und offene Hardwaretests.
