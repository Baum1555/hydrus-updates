#pragma once
#include <Preferences.h>
#include <LittleFS.h>
#include <nvs_flash.h>

// Der Auftrag übersteht Stromausfälle. Ausführung nur beim Booten vor allen Diensten.
class Werksreset {
 public:
  static bool vormerken(){Preferences p;if(!p.begin("hydrus-reset",false))return false;bool ok=p.putBool("offen",true)==1;p.end();return ok;}
  static bool ausstehend(){Preferences p;if(!p.begin("hydrus-reset",true))return false;bool offen=p.getBool("offen",false);p.end();return offen;}
  static bool ausfuehren(){
    // Keine Funk-/Web-/Journalaufgabe darf währenddessen Daten zurückschreiben.
    LittleFS.end();
    if(!LittleFS.format())return false;
    // Erst nach dem Journal alle NVS-Daten löschen, einschließlich Reset-Auftrag.
    // Erfasst WLAN, AP-Zugang, AES-Schlüssel, Zähler, Verbrauch, Push und Update-Einstellungen.
    if(nvs_flash_erase()!=ESP_OK)return false;
    return nvs_flash_init()==ESP_OK;
  }
};
