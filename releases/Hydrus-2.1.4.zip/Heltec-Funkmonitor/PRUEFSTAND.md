# Version 2.1.4

Updateanzeige: Suchanimation, Sperre gegen mehrfache Aktionen, echte Prozentwerte fuer Browser-Upload und PC-Download, unbestimmte Anzeige waehrend Pruefung. Heltec-Onlineinstallation bleibt synchron und zeigt daher eine Laufanimation ohne Prozentwert. Erfolg und Fehler beenden den Wartezustand.

# Version 2.1.3

Beide setCACertBundle-Schnittstellen mit einem und zwei Argumenten getrennt kompiliert und ausgefuehrt. Vollbuild mit ESP32 3.3.12. Kein vollstaendiger Heltec-3.0.3-Build oder TLS-Test auf Hardware.

# Version 2.1.2

HTTPS verwendet ein explizites Mozilla-Zertifikatspaket mit setCACertBundle statt useBuiltinCACertBundle. Vollbuild mit ESP32 3.3.12 bestanden. Die Schnittstelle wurde gegen Espressifs Header fuer 3.0.7 geprueft; kein vollstaendiger Build mit dem unbekannten Boardpaket des Anwenders. HTTPS auf Hardware bleibt zu testen.

# Version 2.1.1

HTTP-Admin-Anmeldung vollstaendig entfernt, einschliesslich Konfiguration, Benachrichtigungen und Firmware-Upload. Sitzungstoken und Update-Signaturpruefung bleiben erhalten.

# Prüfstand 24.09.2026

## Version 2.1.0

Vollständige ESP32-S3-Firmware kompiliert und gelinkt; Anwendungs-BIN mit esptool erstellt. Weiterhin Espressif 3.3.12, RadioLib 7.7.1, ArduinoJson 7.4.2.

Neue native Tests gegen echte C++-Klassen mit simuliertem Dateisystem/NVS/Netz: Ereignisbeginn und -ende, keine doppelten Zustandsmeldungen, Empfangsunterbrechung, Dauer, Neustartmarkierung, Rotation auf zwei begrenzte Dateien; Push ausgeschaltet ohne Versand, HTTPS-Pflicht, Token nicht in Statusantwort, persistente Warteschlange, Offline-Verhalten, Wiederholung bei Serverfehler, erfolgreiche Annahme und acht Nachrichten als Grenze. Es wurden keine echten Push-Nachrichten versandt.

Qt-Test: Ereignistabelle und fehlerhafte JSONL-Zeile, Vergleich von zehn Litern, Abweisung eines anderen Zählers, Abbruch bei Verbindungsverlust und Darstellung auf 430 Pixeln. Bestehende WLAN-Auswahl und Browser-/Python-Dekodervergleiche erneut geprüft. Signaturtests mit falschem Schlüssel, beschädigtem Paket, falschem Produkt/Build und ZIP-Pfadausbruch bestanden.

Öffentliche Pakete enthalten keine persönlichen Zählerkennungen, AES-Schlüssel oder privaten Signaturschlüssel. Vorhandene Zählerkonfiguration im NVS wird beibehalten; ein neues Gerät muss eingerichtet werden. Das öffentliche Firmwarepaket verwendet das Standard-Accesspoint-Passwort aus WlanZugang.h.

Offen bleiben echter Funkbetrieb mit parallelem TLS/Flash, Stromausfalltests auf Hardware, ein realer Messmengenvergleich, ntfy-Zustellung aufs Handy und OTA auf dem Heltec. GitHub-Downloads und Signaturen werden unabhängig davon geprüft. Vorherige Prüfnotizen beschreiben frühere Programmstände.

## Version 2.0.0

Aktueller WLAN-Stand: zusätzliche Adressbox zurückgenommen. Funksuche und WLAN-Konfiguration verwenden automatisch ein Sitzungstoken ohne Basic-Anmeldung; andere geschützte Änderungen behalten ihre Anmeldung. Asynchrone WLAN-Suche mit Auswahl und manueller Ausnahme für verborgene Netze eingebaut. Qt-Test mit simulierten Antworten prüft automatischen Start, Abfrage bis Abschluss, Sortierung, SSID-Duplikate, Auswahl, verstecktes WLAN und mobile Breite. Vollständiger Firmware-Build erfolgreich. Echter WLAN-Scan bei bestehender AP-Verbindung ist noch am Gerät zu prüfen. Der nachfolgende Testbericht zur Adressbox beschreibt den inzwischen zurückgenommenen Zwischenstand.

WLAN-Einrichtung: Heimnetz-Adresse als dauerhaftes Feld mit Kopieren/Öffnen, getrennt vom Accesspoint erklärt. Qt-Test prüft verbundene/getrennte Zustände, 0.0.0.0, 430-Pixel-Seitenbreite sowie das Beibehalten einer neu eingegebenen SSID während der Anmeldung. Das Entsperren überschreibt diese Eingabe nicht mehr. Kopieren bietet für lokale HTTP-Seiten einen Auswahl-Fallback. Echtes Umschalten des Handy-WLANs bleibt ein Hardwaretest.

Arduino-IDE-Korrektur: Stack-Makro hinter die Header verschoben, Funktelegramm.h ausdrücklich eingebunden und meldungEinreihen vorab deklariert. Regressionstest mit einer vor dem Makro eingefügten Arduino-Funktionsdeklaration reproduziert den Fehler der alten Reihenfolge; die korrigierte Fassung besteht. Der direkte Compilerlauf hatte diese zusätzliche Arduino-Aufbereitung zuvor nicht abgedeckt.

Vollständiger Firmware-Build einschließlich Link mit echtem ESP32-S3-Werkzeugpfad erfolgreich: Espressif 3.3.12, RadioLib 7.7.1 und ArduinoJson 7.4.2. Arduino CLI selbst scheitert in dieser Arbeitsumgebung an einer Pfadauflösung; daher wurden alle benötigten Arduino-Core-, Bibliotheks- und Sketch-Quellen direkt mit derselben Toolchain gebaut. Der ältere Hinweis auf eine reine Syntaxprüfung unten ist damit überholt. Kein Flashen angeschlossener Hardware.

Sieben Update-Tests bestanden: Signatur, falsche Signatur, beschädigter Inhalt, falsches Produkt/alte Version, Installation in neuen Ordner, Pfadausbruch im ZIP und HTTPS-Pflicht. Signaturprüfung und Ablehnung wurden auf dem PC getestet; OTA auf dem realen Heltec ist noch offen.

Echte C++-Klassen mit simuliertem Dateisystem/NVS/Uhr geprüft: Schlüsselverwaltung ohne Schlüsselrückgabe, Namen, DIF/VIF-Grundwerte, beschädigte Nutzdaten, Leckdauer, Empfangslücke, rückläufiger Zähler, Tageswechsel und Neustart. Bestehende Speicherprüfungen erneut bestanden.

PySide6-Oberfläche auf Desktop und 430-Pixel-Handybreite gerendert und angesehen. Verbrauchskarten, sieben Tagesbalken, individuelle Empfangsfrist, Dunkelansicht und Seitenbreite geprüft. Neun Browser-/Python-Dekodervergleiche, vier Real-Data-Tests und 27 Tests des bisherigen PC-Testmoduls bestanden. Python-Dateien und PowerShell-Einrichtung syntaktisch geprüft.

Offen: echte Messwerte beim Kumpel, Dauerbetrieb Funk/Flash/HTTP/TLS, OTA einschließlich Stromausfall, frische Windows-Erstinstallation und echtes Handy. Summen sind bewusst Mindestmengen; Leckverdacht ist keine garantierte Schadenerkennung und löst keine Push-Nachricht aus.

## Frühere Prüfungen

PySide6 6.11.2: Fenster, QWebChannel, Paketdarstellung gestartet; Desktop 1280x900 und Handy 430x920 visuell geprüft. Synthetische Daten nur im externen Test, keine Demo-Funktion. Beide JavaScript-Teile syntaktisch geprüft. Neun Browser-/Python-Dekodervergleiche erfolgreich. Qt-Empfangsbrücke mit Paket, Scan, ungültigem Befehl und Leeren geprüft. Bestehende Tests: 4 Real-Data-, 5 PC-, 15 WLAN-Tests erfolgreich. Arduino-Gesamtsketch mit echtem ESP32-S3-Compiler auf Syntax geprüft, Espressif 3.3.12 / RadioLib 7.7.1. PowerShell-Einrichtung syntaktisch geprüft.

Nicht durchgeführt: vollständiger Firmware-Link/Flash, Heimnetzwechsel auf echter Hardware, paralleler Funk/HTTP-Empfang, Messwertvergleich beim Kumpel und Erstinstallation auf leerem Laptop. Qt wurde in der Testumgebung installiert. Funk läuft separat; langsame HTTP-Clients können dennoch die Ausgabe verzögern. Verworfene Queue-Einträge erscheinen im Empfangsstatus.


Erweiterung Flash-Verlauf: echte C++-Speicherklasse mit simuliertem Dateisystem getestet: keine automatische Formatierung, explizite Erstinitialisierung, Kennungsfilter, Fünf-Minuten-Intervall, Neustart, Rotation bei acht Segmenten, abgebrochene letzte Zeile und Schreibfehler. Verlauf-Tabelle und Diagramm in Qt mit zwei gültigen und einem beschädigten Datensatz geprüft. Physischer Flash-Verschleiß, Dateisystem bei echtem Stromausfall und Parallelbetrieb mit Funk sind damit nicht hardwaregetestet.
