/*
  HYDRUS-VersuchsempfÃ¤nger: Heltec WiFi LoRa 32 V3 / V3.2, 868-MHz-AusfÃ¼hrung.
  Arduino-Board: Heltec WiFi LoRa 32(V3), 8 MB Flash, kein PSRAM.
  Bibliothek: RadioLib 7.4.0 oder 7.7.1. USB mit 115200 Baud plus eigener WLAN-Accesspoint.

  Der eingebaute SX1262 arbeitet in FSK, nicht in LoRa oder Meshtastic.
  Passive T-/C-Uplink-Auswertung auf 868,95 MHz; keine 868-MHz-Sendefunktion.
  Der normale Paketmodus nimmt 255 Bytes nach dem Synchronwort auf.
  KÃ¼rzere Telegramme werden anhand ihres Kopfes abgeschnitten und CRC-geprÃ¼ft;
  lÃ¤ngere werden gemeldet und verworfen. Keine zugesicherte HYDRUS-KompatibilitÃ¤t
  ohne echten Empfangstest! S-Modus und proprietÃ¤re Diehl-Formate fehlen.

  WLAN-Zugang: WlanZugang.h; AES-SchlÃ¼ssel optional: ZaehlerSchluessel.h.
  Pinbelegung: HeltecPins.h. OLED zeigt ZÃ¤hler, Durchfluss und IP; PRG wechselt den ZÃ¤hler.
*/
#include <Arduino.h>
#include <SPI.h>
#include <RadioLib.h>
#include <atomic>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "freertos/queue.h"
#include "HeltecPins.h"
#include "Funktelegramm.h"
#include "SxRahmen.h"
#include "OmsEntschluesselung.h"
#include "FunkSuche.h"
#include "DatenVerbindung.h"
#include "OledAnzeige.h"
#include "OledMonitor.h"
#include "Werksreset.h"
#include "Wiederherstellung.h"

// Arduino erzeugt Funktionsdeklarationen vor der ersten Implementierung.
// Das Stack-Makro daher erst nach allen Typdefinitionen verwenden.
void meldungEinreihen(const Empfangsmeldung &meldung);
SET_LOOP_TASK_STACK_SIZE(16384);

#if !defined(CONFIG_IDF_TARGET_ESP32S3)
#error "Bitte Heltec WiFi LoRa 32(V3) mit ESP32-S3 auswaehlen."
#endif

DatenAusgabe Ausgabe;
OledAnzeige Anzeige;
OledMonitor Oled;
Wiederherstellung Rettung;
bool oledBereit = false;
uint32_t anzeigeFrequenz = 0;
int16_t anzeigeRssi = -127;
char letzteKennung[9] = "--------";
bool anzeigeSuche = false;
bool laufenderFunkfehler = false;
SX1262 Funk = new Module(PIN_AUSWAHL, PIN_MELDUNG, PIN_RESET, PIN_BUSY, SPI);
QueueHandle_t paketwarteschlange = nullptr;
QueueHandle_t befehlswarteschlange = nullptr;
TaskHandle_t empfangsaufgabe = nullptr;
std::atomic<uint32_t> verloreneMeldungen{0};
std::atomic<uint32_t> synchronisationen{0};
bool empfaengerBereit = false;
// Nach setup greift ausschlieÃŸlich die Empfangsaufgabe auf den SX1262 zu.
uint32_t aktuelleFrequenz = FunkSuche::STANDARD_HZ;
int16_t letzterFunkfehler = 0;

bool funkPruefen(int16_t ergebnis) {
  letzterFunkfehler = ergebnis;
  return ergebnis == RADIOLIB_ERR_NONE;
}

bool funkEinrichten() {
  SPI.begin(PIN_TAKT, PIN_LESEN, PIN_SENDEN, PIN_AUSWAHL);
  // Die Parameterform funktioniert auch ohne ConfigFSK_t in Ã¤lteren RadioLib-Versionen.
  // MHz, kbit/s, Hub kHz, Bandbreite kHz, TX-Leistung, PrÃ¤ambelbits, TCXO Volt, LDO.
  // Der erforderliche TX-Parameter startet keine Aussendung; wir verwenden nur Empfang.
  if (!funkPruefen(Funk.beginFSK(868.95f, 100.0f, 50.0f, 234.3f,
                                10, 16, TCXO_SPANNUNG, false))) return false;
  uint8_t synchronwort[] = {0x54, 0x3D};
  return funkPruefen(Funk.setDio2AsRfSwitch(true)) &&
         funkPruefen(Funk.setSyncWord(synchronwort, sizeof(synchronwort))) &&
         funkPruefen(Funk.setCRC(0)) && // Wireless-M-Bus prÃ¼ft mehrere eigene CRC-BlÃ¶cke.
         funkPruefen(Funk.setEncoding(RADIOLIB_ENCODING_NRZ)) &&
         funkPruefen(Funk.fixedPacketLengthMode(SxRahmen::AUFNAHME_BYTES)) &&
         funkPruefen(Funk.setRxBoostedGainMode(true));
}

void meldungEinreihen(const Empfangsmeldung &meldung) {
  if (xQueueSend(paketwarteschlange, &meldung, 0) != pdTRUE) ++verloreneMeldungen;
}

void funkFehlerMelden() {
  Empfangsmeldung meldung{};
  meldung.art = Ergebnisart::SPI_FEHLER;
  meldung.mittelwert = letzterFunkfehler; // Fehlercode unverÃ¤ndert an Hauptaufgabe geben.
  meldungEinreihen(meldung);
}

bool frequenzSetzen(uint32_t frequenz) {
  if (frequenz == aktuelleFrequenz) return true;
  aktuelleFrequenz = 0;
  if (!funkPruefen(Funk.standby()) ||
      !funkPruefen(Funk.setFrequency(frequenz / 1000000.0f))) return false;
  aktuelleFrequenz = frequenz;
  return true;
}

bool empfangStarten(bool dauerempfang) {
  // Einzelempfang schÃ¼tzt den fertigen Puffer bis zum Auslesen vor Ãœberschreiben.
  // FÃ¼r den reinen Pegelscan bleibt der Chip dauerhaft im Empfang.
  const uint32_t ereignisse = (1UL << RADIOLIB_IRQ_RX_DONE) |
                             (1UL << RADIOLIB_IRQ_SYNC_WORD_VALID) |
                             (1UL << RADIOLIB_IRQ_TIMEOUT);
  return funkPruefen(Funk.startReceive(dauerempfang ? RADIOLIB_SX126X_RX_TIMEOUT_INF : 0,
                                     ereignisse, ereignisse));
}

void empfangsSchleife(void *) {
  bool suche = false;
  uint32_t zielFrequenz = FunkSuche::STANDARD_HZ;
  size_t suchpunkt = 0;
  uint8_t durchgang = 1;
  uint32_t letzteStatuszeit = 0;
  for (;;) {
    FunkSuche::Auftrag auftrag;
    while (xQueueReceive(befehlswarteschlange, &auftrag, 0) == pdTRUE) {
      suche = auftrag.art == FunkSuche::Art::SCAN;
      zielFrequenz = auftrag.frequenz;
      suchpunkt = 0;
      durchgang = 1;
    }
    const uint32_t ziel = suche ? FunkSuche::frequenz(suchpunkt) : zielFrequenz;
    if (!frequenzSetzen(ziel) || !empfangStarten(suche)) {
      funkFehlerMelden();
      vTaskDelay(pdMS_TO_TICKS(1000));
      continue;
    }
    if (suche) {
      // 71 Einstellungen, vier DurchgÃ¤nge. RSSI allein erkennt keinen ZÃ¤hler.
      vTaskDelay(pdMS_TO_TICKS(10));
      Empfangsmeldung punkt{};
      punkt.art = Ergebnisart::SUCHPUNKT;
      punkt.frequenz = aktuelleFrequenz;
      punkt.durchgang = durchgang;
      punkt.signalstaerke = -200;
      int summe = 0;
      for (uint8_t probe = 0; probe < 10; ++probe) {
        const int wert = static_cast<int>(Funk.getRSSI(false));
        summe += wert;
        if (wert > punkt.signalstaerke) punkt.signalstaerke = wert;
        vTaskDelay(pdMS_TO_TICKS(10) ? pdMS_TO_TICKS(10) : 1);
      }
      punkt.mittelwert = summe / 10;
      meldungEinreihen(punkt);
      if (++suchpunkt == FunkSuche::PUNKTE) {
        suchpunkt = 0;
        if (++durchgang > FunkSuche::DURCHGAENGE) suche = false;
      }
      continue;
    }

    bool synchron = false;
    uint32_t paketbeginn = 0;
    int16_t paketRssi = -127;
    for (;;) {
      if (uxQueueMessagesWaiting(befehlswarteschlange)) break;
      const uint32_t ereignis = Funk.getIrqFlags();
      if (ereignis & RADIOLIB_SX126X_IRQ_SYNC_WORD_VALID) {
        if (!synchron) {
          synchron = true;
          paketbeginn = millis();
          paketRssi = static_cast<int16_t>(Funk.getRSSI(false));
          ++synchronisationen;
        }
        if (!funkPruefen(Funk.clearIrqFlags(RADIOLIB_SX126X_IRQ_SYNC_WORD_VALID))) {
          funkFehlerMelden();
          break;
        }
      }
      if (ereignis & RADIOLIB_SX126X_IRQ_RX_DONE) {
        uint8_t aufnahme[SxRahmen::AUFNAHME_BYTES] = {};
        Empfangsmeldung meldung{};
        meldung.frequenz = aktuelleFrequenz;
        meldung.signalstaerke = paketRssi;
        const size_t anzahl = Funk.getPacketLength();
        if (!funkPruefen(Funk.readData(aufnahme, sizeof(aufnahme)))) {
          funkFehlerMelden();
          break;
        }
        meldung.art = SxRahmen::auswerten(aufnahme, anzahl <= sizeof(aufnahme) ? anzahl : sizeof(aufnahme), meldung.telegramm);
        meldungEinreihen(meldung);
        break;
      }
      if ((ereignis & RADIOLIB_SX126X_IRQ_TIMEOUT) ||
          (synchron && static_cast<uint32_t>(millis() - paketbeginn) > 100)) {
        Empfangsmeldung meldung{};
        meldung.art = Ergebnisart::ZEITUEBERSCHREITUNG;
        meldungEinreihen(meldung);
        break;
      }
      if (!synchron && static_cast<uint32_t>(millis() - letzteStatuszeit) >= 1000) {
        letzteStatuszeit = millis();
        Empfangsmeldung meldung{};
        meldung.art = Ergebnisart::FUNKSTATUS;
        meldung.frequenz = aktuelleFrequenz;
        meldung.signalstaerke = static_cast<int16_t>(Funk.getRSSI(false));
        meldungEinreihen(meldung);
      }
      vTaskDelay(1); // WLAN und Systemaufgaben mÃ¼ssen ebenfalls laufen kÃ¶nnen.
    }
  }
}

#include "Paketausgabe.h"

void displayAktualisieren(uint32_t pakete) {
  (void)pakete;
  if(!Oled.pflegen(Anzeige,Ausgabe.portal.adresse(),!empfaengerBereit||laufenderFunkfehler,anzeigeSuche,
      WiFi.status()==WL_CONNECTED,WiFi.softAPIP().toString(),Ausgabe.portal.accesspointName()) && oledBereit){
    oledBereit=false;
    Ausgabe.println("HINWEIS OLED nicht erreichbar. Funk, USB und WLAN laufen weiter.");
  }
}

void setup() {
  Serial.begin(115200);
  delay(300);
  oledBereit = Anzeige.starten();
  if(Werksreset::ausstehend()){
    Anzeige.leeren();Anzeige.zeile(0,"WERKSRESET");Anzeige.zeile(3,"DATEN LOESCHEN");Anzeige.anzeigen();
    if(!Werksreset::ausfuehren()){
      Anzeige.leeren();Anzeige.zeile(0,"RESET FEHLGESCHLAGEN");Anzeige.zeile(3,"WLAN-REPARATUR");Anzeige.zeile(5,"192.168.4.1");Anzeige.anzeigen();
      Serial.printf("FEHLER Werksreset: %s. Wiederherstellung: http://192.168.4.1/\n",Werksreset::fehler());
      if(!Rettung.starten(Werksreset::fehler()))Serial.println("FEHLER Reparatur-WLAN nicht gestartet. Firmware ueber USB laden.");
      return;
    }
  }
  Oled.starten();
  Ausgabe.starten();
  if (!oledBereit) Ausgabe.println("HINWEIS OLED nicht erreichbar. Funk, USB und WLAN werden trotzdem eingerichtet.");
  Ausgabe.println("STATUS Heltec V3 + SX1262; FSK T/C; WLAN und USB lokal; Versuchsfassung.");
  if (!funkEinrichten()) {
    Ausgabe.printf("FEHLER SX1262-Einrichtung gescheitert; RadioLib-Code=%d. Heltec V3 und Boardauswahl pruefen.\n", letzterFunkfehler);
    return;
  }
  paketwarteschlange = xQueueCreate(8, sizeof(Empfangsmeldung));
  befehlswarteschlange = xQueueCreate(4, sizeof(FunkSuche::Auftrag));
  if (!paketwarteschlange || !befehlswarteschlange ||
      xTaskCreatePinnedToCore(empfangsSchleife, "Funkempfang", 8192, nullptr, 5, &empfangsaufgabe, 0) != pdPASS) {
    Ausgabe.println("FEHLER Empfangsaufgabe konnte nicht eingerichtet werden.");
    return;
  }
  empfaengerBereit = true;
  Ausgabe.portal.befehl = [](const String &text) -> bool {
    FunkSuche::Auftrag auftrag{};
    return empfaengerBereit && FunkSuche::befehlLesen(text.c_str(), auftrag) &&
           xQueueSend(befehlswarteschlange, &auftrag, 0) == pdTRUE;
  };
  Ausgabe.println("STATUS SX1262 eingerichtet: 868,95 MHz; FSK 100 kbit/s; Bandbreite 234,3 kHz; maximal 255 Funkbytes.");
}

void loop() {
  if(Rettung.aktiv){Rettung.pflegen();delay(2);return;}
  static BefehlsPuffer usbPuffer;
  static uint32_t letzteStatuszeit = 0;
  static uint32_t pakete = 0;
  static uint32_t fehler[9] = {};
  Ausgabe.pflegen();
  displayAktualisieren(pakete);
  if(Oled.resetBereit){
    if(Werksreset::vormerken()) {ESP.restart();while(true)delay(100);}
    Anzeige.leeren();Anzeige.zeile(0,"RESET FEHLGESCHLAGEN");Anzeige.anzeigen();
    Ausgabe.println("FEHLER Reset-Auftrag konnte nicht gespeichert werden. Kein Reset ausgefuehrt.");
    Oled.resetAbbrechen();
    return;
  }
  befehleLesen(Serial, usbPuffer);
  befehleLesen(Ausgabe.netzclient, Ausgabe.netzbefehl);
  if (!empfaengerBereit) {
    if (static_cast<uint32_t>(millis() - letzteStatuszeit) > 2000) {
      letzteStatuszeit = millis();
      Ausgabe.println("FEHLER SX1262 nicht bereit. Startprotokoll ueber USB pruefen und RESET druecken.");
    }
    delay(5);
    return;
  }
  Empfangsmeldung meldung{};
  if (xQueueReceive(paketwarteschlange, &meldung, pdMS_TO_TICKS(10)) == pdTRUE) {
    if (meldung.art == Ergebnisart::PAKET) {
      ++pakete;
      laufenderFunkfehler = false;
      anzeigeSuche = false;
      anzeigeFrequenz = meldung.frequenz;
      anzeigeRssi = meldung.signalstaerke;
      const auto adresskopf = ZaehlerAdresse::lesen(meldung.telegramm.daten, meldung.telegramm.laenge);
      memcpy(letzteKennung, adresskopf.kennung, sizeof(letzteKennung));
      paketAusgeben(meldung);
    } else if (meldung.art == Ergebnisart::SUCHPUNKT) {
      laufenderFunkfehler = false;
      anzeigeSuche = true;
      anzeigeFrequenz = meldung.frequenz;
      anzeigeRssi = meldung.signalstaerke;
      Ausgabe.printf("SCAN {\"frequenz_hz\":%lu,\"maximum_dbm\":%d,\"mittel_dbm\":%d,\"durchgang\":%u}\n",
        static_cast<unsigned long>(meldung.frequenz), meldung.signalstaerke, meldung.mittelwert, meldung.durchgang);
    } else if (meldung.art == Ergebnisart::FUNKSTATUS) {
      laufenderFunkfehler = false;
      anzeigeSuche = false;
      anzeigeFrequenz = meldung.frequenz;
      anzeigeRssi = meldung.signalstaerke;
      Ausgabe.printf("FUNKSTATUS {\"frequenz_hz\":%lu,\"rssi\":%d,\"profil\":\"TC\",\"funkchip\":\"SX1262\",\"max_funkbytes\":255}\n",
        static_cast<unsigned long>(meldung.frequenz), meldung.signalstaerke);
    } else {
      ++fehler[static_cast<uint8_t>(meldung.art)];
      if (meldung.art == Ergebnisart::SPI_FEHLER) {
        laufenderFunkfehler = true;
        Ausgabe.printf("FUNKFEHLER SX1262-Kommunikation fehlgeschlagen; RadioLib-Code=%d.\n", meldung.mittelwert);
      }
      if (meldung.art == Ergebnisart::ZU_LANG)
        Ausgabe.println("HINWEIS Telegrammkopf erwartet mehr als 255 Funkbytes. Diese SX1262-Fassung kann es nicht vollstaendig aufnehmen.");
    }
  }
  if (static_cast<uint32_t>(millis() - letzteStatuszeit) >= 10000) {
    letzteStatuszeit = millis();
    Ausgabe.printf("STATUS SX1262; Sync=%lu; Pakete=%lu; Kopf=%lu; CRC/Codierung=%lu; Zeitfrist=%lu; SPI=%lu; Zu_lang=%lu; Warteschlange_verworfen=%lu\n",
      static_cast<unsigned long>(synchronisationen.load()), static_cast<unsigned long>(pakete),
      static_cast<unsigned long>(fehler[1]), static_cast<unsigned long>(fehler[2]),
      static_cast<unsigned long>(fehler[4]), static_cast<unsigned long>(fehler[5]),
      static_cast<unsigned long>(fehler[8]), static_cast<unsigned long>(verloreneMeldungen.load()));
  }
}
