// Handyansicht: vorhandene Daten und Aktionen behalten ihre bisherigen Funktionen.
(() => {
  const stil = document.createElement('style');
  stil.textContent = `
  .handyNavSymbol{display:none}
  @media(max-width:700px){
    html{scroll-padding-bottom:110px}body{font-size:15px}
    main{padding:18px 14px calc(104px + env(safe-area-inset-bottom));min-width:0}
    main>header{gap:12px;align-items:center;margin-bottom:18px;flex-wrap:wrap}
    main>header h1{font-size:27px;letter-spacing:-.8px;margin:0}
    main>.row:has(#farbschema){float:right;margin-bottom:8px}
    #farbschema{min-width:44px;min-height:44px;border-radius:50%}
    .card{padding:18px;border-radius:20px;box-shadow:0 3px 16px #12333b05;min-width:0}
    button,input,select{min-height:46px}input,select{font-size:16px;max-width:100%;min-width:0}
    button{touch-action:manipulation}label{min-width:0;max-width:100%}
    .row>*{max-width:100%}h2{font-size:18px}.unit{white-space:nowrap}
    .bereichTabs{display:flex;flex-wrap:nowrap;justify-content:flex-start;overflow-x:auto;gap:4px;padding:4px;margin-bottom:18px;background:var(--card);border:1px solid var(--line);border-radius:15px;scrollbar-width:none}
    .bereichTabs button{flex:1 0 auto;border:0;background:transparent;border-radius:11px;padding:10px 12px;min-height:44px;font-size:13px}
    #start .zaehlerKopf{gap:9px;padding:14px 16px;margin-bottom:14px!important;border-radius:18px}
    #start .zaehlerKopf label{flex-basis:100%;min-width:0;font-size:12px}
    #start #zaehler{margin-top:5px;font-size:16px;border:0;background:var(--bg);border-radius:11px}
    #start #letztes{display:none}
    #schluesselUebersicht{font-size:12px;margin:0;flex-basis:100%;overflow-wrap:anywhere}
    #empfangNeu{font-size:12px}
    #start .hauptRaster{gap:12px}
    #start .flussKarte{min-height:215px;padding:25px;border:0;border-radius:23px;position:relative;overflow:hidden;box-shadow:0 8px 24px #083f4522}
    #start .flussKarte::after{content:'';position:absolute;width:130px;height:130px;border:24px solid #ffffff06;border-radius:50%;right:-65px;top:-65px;pointer-events:none}
    #start .flussKarte small{font-size:12px;letter-spacing:1.6px}
    #start .flussKarte #fluss{font-size:54px;font-variant-numeric:tabular-nums;line-height:1.18;margin:8px 0;letter-spacing:-2px}
    #start .flussKarte .unit{font-size:18px}#flussZustand{font-size:14px;margin:8px 0 5px}#flussZeit{font-size:12px}
    #start .hero{min-height:0;padding:14px 18px}#start .hero h2{font-size:14px;margin:0}
    #start .hero .meter{height:110px;margin:0 auto;display:block}
    #start .hero .badge{font-size:11px}
    #start .verbrauchKarten{gap:10px;margin-top:12px}
    #start .verbrauchKarten .metric{padding:17px;min-height:100px;border-radius:18px;gap:9px}
    #start .verbrauchKarten small{font-size:11px;letter-spacing:.6px}
    #start .verbrauchKarten strong{font-size:26px;font-variant-numeric:tabular-nums;overflow-wrap:anywhere}
    #start .verbrauchKarten .gesamtstand{grid-column:1/-1;grid-row:1;min-height:88px;flex-direction:row;justify-content:space-between;align-items:center;flex-wrap:wrap}
    #start .verbrauchKarten .gesamtstand strong{font-size:30px}
    #start .verbrauchKarten .monatsverbrauch{grid-column:1/-1;min-height:80px;flex-direction:row;align-items:center;justify-content:space-between;flex-wrap:wrap}
    .below{margin-top:14px}.zeitTabs button{flex:1;min-height:44px}
    #technikDetails>summary{min-height:44px;font-size:14px;cursor:pointer}
    .leckKarte{padding:17px;border-radius:18px}.leckKarte .row button{flex:1 1 140px}.leckZahlen{gap:16px}
    nav{padding:7px 12px calc(7px + env(safe-area-inset-bottom));background:var(--card);border-top:1px solid var(--line);box-shadow:0 -5px 24px #12333b0d}
    nav .tabs{gap:6px}nav .tabs button{display:flex;flex-direction:column;gap:4px;align-items:center;justify-content:center;min-height:58px;padding:7px 4px;color:var(--muted);border-radius:14px;font-size:11px}
    nav .tabs button.active{background:var(--bg);color:var(--mint);font-weight:700}
    .handyNavSymbol{display:block;width:21px;height:21px;fill:none;stroke:currentColor;stroke-width:1.7;stroke-linecap:round;stroke-linejoin:round}
    #meldung{bottom:calc(90px + env(safe-area-inset-bottom));max-width:calc(100vw - 28px)}
  }
  @media(max-width:360px){main{padding-left:10px;padding-right:10px}#start .flussKarte #fluss{font-size:46px}.bereichTabs button{font-size:12px;padding:8px}.card{padding:15px}}
  `;
  document.head.append(stil);
  $('volumen').closest('.card').classList.add('gesamtstand');
  $('monat').closest('.card').classList.add('monatsverbrauch');
  // Schlüssel- und Empfangsstatus gehören direkt zum ausgewählten Zähler.
  $('zaehler').closest('.zaehlerKopf').append($('schluesselUebersicht'));
  const symbole = {
    start:'<path d="M3 10 12 3l9 7v10a1 1 0 0 1-1 1h-5v-7H9v7H4a1 1 0 0 1-1-1Z"/>',
    historie:'<path d="M4 3v17h17M8 15l4-5 4 3 5-8"/>',
    einstellungen:'<path d="M4 6h16M4 12h16M4 18h16"/><circle cx="9" cy="6" r="2"/><circle cx="16" cy="12" r="2"/><circle cx="8" cy="18" r="2"/>'
  };
  for(const b of document.querySelectorAll('nav [data-tab]')){
    const svg=document.createElementNS('http://www.w3.org/2000/svg','svg');
    svg.setAttribute('viewBox','0 0 24 24');svg.setAttribute('aria-hidden','true');
    svg.classList.add('handyNavSymbol');svg.innerHTML=symbole[b.dataset.tab]||'';b.prepend(svg);
  }
})();
