// Die Bewegung zeigt Wasserfluss an, niemals geschätzte Messwerte.
(() => {
  const karte=$('fluss').closest('.card');
  const stil=document.createElement('style');
  stil.textContent=`
  .flussBewegung{height:24px;width:100%;margin-top:16px;overflow:hidden;opacity:.28}
  .flussBewegung svg{height:24px;width:100%;display:block;overflow:hidden}
  .flussBewegung path{fill:none;stroke:currentColor;stroke-width:2;stroke-linecap:round;stroke-dasharray:14 12}
  .flussLaeuft .flussBewegung{opacity:.75}
  .flussLaeuft .flussBewegung path{animation:flussStroemen 1.6s linear infinite}
  .flussBewegung path:nth-child(2){opacity:.45;animation-delay:-.8s}
  @keyframes flussStroemen{to{stroke-dashoffset:-52}}
  @media(prefers-reduced-motion:reduce){.flussLaeuft .flussBewegung path{animation:none!important}}
  `;
  document.head.append(stil);
  const grafik=document.createElement('div');grafik.className='flussBewegung';grafik.setAttribute('aria-hidden','true');
  grafik.innerHTML='<svg viewBox="0 0 320 24" preserveAspectRatio="none"><path d="M-20 8 Q0 0 20 8 T60 8 T100 8 T140 8 T180 8 T220 8 T260 8 T300 8 T340 8"/><path d="M-20 19 Q0 11 20 19 T60 19 T100 19 T140 19 T180 19 T220 19 T260 19 T300 19 T340 19"/></svg>';
  karte.append(grafik);
  const vorher=startseiteAktualisieren;
  startseiteAktualisieren=function(){vorher();karte.classList.toggle('flussLaeuft',$('hero').classList.contains('running'));};
  startseiteAktualisieren();
})();
