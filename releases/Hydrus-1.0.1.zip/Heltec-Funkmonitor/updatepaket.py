"""Gemeinsames signiertes Updateformat. Der private Herausgeberschlüssel gehört nie ins Downloadpaket."""
import base64
import hashlib
import json
import struct
from pathlib import Path
from urllib.parse import urlsplit
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import padding, rsa

MAGIE = b'HYDRUS02'
BUILD = 2026092602
VERSION = '1.0.1'
STANDARD_UPDATE_URL = 'https://raw.githubusercontent.com/Baum1555/hydrus-updates/main/pc-version.json'

class BereitsAktuell(ValueError):
    pass


def metadaten_pruefen(roh, signatur, public, produkt, aktueller_build=BUILD):
    if not 1 <= len(roh) <= 4096 or len(signatur) != 256:
        raise ValueError('Ungültiges Updateformat')
    key = serialization.load_pem_public_key(public)
    if not isinstance(key, rsa.RSAPublicKey) or key.key_size != 2048:
        raise ValueError('Ungültiger Herausgeberschlüssel')
    key.verify(signatur, roh, padding.PKCS1v15(), hashes.SHA256())
    d = json.loads(roh)
    if d.get('produkt') != produkt or type(d.get('build')) is not int:
        raise ValueError('Update passt nicht')
    if d['build'] <= aktueller_build:
        raise BereitsAktuell('Keine neuere Version verfügbar')
    if type(d.get('groesse')) is not int or not 1 <= d['groesse'] <= (3342336 if produkt == 'heltec-v3' else 50000000):
        raise ValueError('Ungültige Paketgröße')
    if not isinstance(d.get('sha256'), str) or len(d['sha256']) != 64:
        raise ValueError('Prüfsumme fehlt')
    bytes.fromhex(d['sha256'])
    return d


def manifest_pruefen(text, public, produkt):
    if len(text) > 10000:
        raise ValueError('Versionsdatei zu groß')
    m = json.loads(text)
    return metadaten_pruefen(base64.b64decode(m['metadaten'], validate=True),
                            base64.b64decode(m['signatur'], validate=True), public, produkt)


def https_url(url):
    u = urlsplit(url)
    if u.scheme != 'https' or not u.hostname or u.username or u.password or u.fragment:
        raise ValueError('Eine HTTPS-Downloadadresse ohne Anmeldedaten wird benötigt')
    return url


def paket_pruefen(datei, public, produkt):
    with open(datei, 'rb') as f:
        h = f.read(12)
        if len(h) != 12 or h[:8] != MAGIE:
            raise ValueError('Keine signierte HYDRUS-Datei')
        n = struct.unpack('>I', h[8:])[0]
        if not 1 <= n <= 4096:
            raise ValueError('Ungültiger Paketkopf')
        roh, sig = f.read(n), f.read(256)
        d = metadaten_pruefen(roh, sig, public, produkt)
        start = f.tell()
        digest, gelesen = hashlib.sha256(), 0
        while block := f.read(65536):
            gelesen += len(block)
            if gelesen > d['groesse']:
                raise ValueError('Paket ist zu groß')
            digest.update(block)
        if gelesen != d['groesse'] or digest.hexdigest() != d['sha256']:
            raise ValueError('Update beschädigt')
        return d, start
