#pragma once
static const char WEB_ANSICHT[] PROGMEM = R"HYDRUSWEB(<!doctype html><html lang="de"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>HYDRUS · Wasser im Blick</title>
<style>
:root{--nav:#102e36;--ink:#173b44;--muted:#657f86;--mint:#087f78;--bg:#f1f6f5;--line:#dce8e5;--card:#fff;--warn:#956016}*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--ink);font:15px system-ui,-apple-system,'Segoe UI',sans-serif}button,input,select{font:inherit}button{cursor:pointer;border:1px solid var(--line);border-radius:10px;background:white;color:var(--ink);padding:10px 16px}button:hover{border-color:var(--mint);background:#effaf7}button.primary{background:var(--mint);color:white;border-color:var(--mint)}button:disabled{opacity:.5;cursor:wait}input,select{padding:10px;border:1px solid var(--line);border-radius:9px;background:white;color:var(--ink);max-width:100%}label{display:grid;gap:6px;font-size:13px;color:var(--muted)}nav{position:fixed;inset:0 auto 0 0;width:220px;background:var(--nav);color:#d9e9e9;padding:32px 20px;display:flex;flex-direction:column;gap:10px}.brand{margin-bottom:30px;font-size:25px;letter-spacing:3px;font-weight:800;color:white}.brand small{display:block;font-size:11px;letter-spacing:2px;font-weight:500;color:#7fb3b6;margin:10px 0 38px}nav button{background:transparent;border:0;color:#bad1d4;text-align:left;padding:14px}nav button.active{background:#254950;color:#87ead3}nav footer{margin-top:auto;font-size:12px;line-height:1.9;color:#83a3aa}main{margin-left:220px;max-width:1650px;padding:32px 38px}header{display:flex;justify-content:space-between;align-items:center;gap:16px;margin-bottom:26px}h1{font-size:30px;letter-spacing:-1px;margin:4px 0 8px}h2{font-size:18px;margin:0 0 15px}p{line-height:1.6}.eyebrow{text-transform:uppercase;letter-spacing:2px;font-size:11px;color:var(--mint);font-weight:800}.sub{color:var(--muted);font-size:13px}.badge{display:inline-block;border-radius:30px;background:#e0f4eb;color:#18735a;padding:7px 11px;font-size:12px}.badge.warn{background:#fff0d9;color:var(--warn)}.badge.off{background:#e8eeee;color:#5f777d}.card{border:1px solid var(--line);border-radius:20px;background:var(--card);padding:24px;box-shadow:0 6px 22px #173b4405}.row{display:flex;align-items:center;gap:12px;flex-wrap:wrap}.row.spread{justify-content:space-between}.connection{margin-bottom:20px;padding:16px 20px}.grid{display:grid;grid-template-columns:1.2fr 1fr;gap:20px}.metrics{display:grid;grid-template-columns:1fr 1fr;gap:16px}.metric{min-height:155px;display:flex;flex-direction:column;justify-content:center;gap:20px}.metric strong{font-size:30px;font-weight:650;letter-spacing:-1px;font-variant-numeric:tabular-nums}.metric small{color:var(--muted)}.metric .unit{font-size:15px;letter-spacing:0;font-weight:400}.hero{background:linear-gradient(155deg,#fafffe,#e9f4f1);min-height:360px;position:relative;overflow:hidden}.meter{display:block;width:100%;height:248px}.meter .rotor{transform-origin:250px 188px}.running .rotor{animation:drehen 2s linear infinite}.running .water{stroke-dasharray:10 14;animation:wasser 1s linear infinite}.water{stroke:#4cc4ba;stroke-width:4}.rotor{fill:#118b82}.metertext{font:600 24px monospace;fill:#173b44}.meterlabel{font:12px system-ui;fill:#597a82}.hero .sub{text-align:center}.below{margin-top:20px}.chart{width:100%;height:180px;display:block}.chart text{font:11px system-ui;fill:#71888d}.scroll{overflow:auto}table{width:100%;border-collapse:collapse;font-size:13px;white-space:nowrap}th{text-align:left;color:var(--muted);font-weight:500;padding:12px;border-bottom:1px solid var(--line)}td{padding:12px;border-bottom:1px solid #edf3f1}tr:hover td{background:#f3faf7}tbody tr{cursor:pointer}.selected td{background:#e3f4ef}.notice{margin:16px 0;padding:12px 16px;border-radius:10px;background:#fff4df;color:#805919;font-size:13px;line-height:1.6}.statusline{font-size:13px;color:var(--muted);min-height:22px;margin-top:8px;overflow-wrap:anywhere}.empty{text-align:center;padding:30px;color:var(--muted)}pre{white-space:pre-wrap;overflow-wrap:anywhere;background:#122e37;color:#c6e4dd;padding:18px;border-radius:12px;font:12px/1.7 monospace;max-height:310px;overflow:auto}.hidden{display:none!important}.section{display:none}.section.active{display:block}.form{display:grid;gap:15px;max-width:620px}.pulse{animation:puls .6s ease}#meldung{position:fixed;bottom:20px;right:20px;background:#173b44;color:white;border-radius:12px;padding:14px 20px;max-width:450px;z-index:10;box-shadow:0 5px 25px #0002}.kpi{color:var(--mint)}.wide{grid-column:1/-1}.logoicon{display:inline-flex;background:#17515a;color:#83e5d0;border-radius:10px;width:34px;height:34px;align-items:center;justify-content:center;margin-right:6px}#ports{width:125px}#adresse{width:165px}#netzPort{width:85px}@keyframes drehen{to{transform:rotate(360deg)}}@keyframes wasser{to{stroke-dashoffset:-24}}@keyframes puls{50%{background:#dff7ee}}@media(prefers-reduced-motion:reduce){*{animation:none!important;transition:none!important}}@media(max-width:1050px){nav{width:180px;padding:25px 14px}main{margin-left:180px;padding:25px}.grid{grid-template-columns:1fr}.hero{min-height:330px}.metrics{grid-template-columns:repeat(4,1fr)}.metric{padding:18px}.metric strong{font-size:24px}}@media(max-width:700px){nav{position:static;width:auto;padding:16px;display:block}.brand{font-size:20px}.brand small,nav footer{display:none}nav .tabs{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:4px;margin-top:12px}nav button{white-space:normal;padding:10px 5px;font-size:12px;text-align:center}main{margin:0;padding:18px 14px}header{align-items:flex-start}h1{font-size:25px}header .sub{max-width:235px}.metrics{grid-template-columns:1fr 1fr}.metric{min-height:135px}.card{padding:18px;border-radius:16px}.hero{min-height:310px}.meter{height:220px}.connection label{flex:1;min-width:100px}.connection .row{align-items:flex-end}#meldung{left:12px;right:12px;bottom:12px}table{font-size:12px}}
body[data-theme="dunkel"]{--nav:#0c1e24;--ink:#e0efea;--muted:#a2bcb5;--mint:#63d2ba;--bg:#10262d;--line:#365058;--card:#19343c}body[data-theme="dunkel"] .card,body[data-theme="dunkel"] button,body[data-theme="dunkel"] input,body[data-theme="dunkel"] select{background:var(--card);color:var(--ink)}body[data-theme="dunkel"] .hero{background:#1b3c43}body[data-theme="dunkel"] td{border-color:var(--line)}body[data-theme="dunkel"] tr:hover td{background:#294c53}body[data-theme="dunkel"] .selected td{background:#294c53}body[data-theme="dunkel"] .notice{background:#443d25;color:#ffdf9b}body[data-theme="dunkel"] button.primary{background:#187e71;color:white}summary{cursor:pointer;font-weight:600}
</style></head><body>
<nav><div class="brand"><span class="logoicon">≈</span>HYDRUS</div><div class="tabs"><button class="active" data-tab="start">◉ Übersicht</button><button data-tab="diagnose">⌁ Funksuche & Diagnose</button><button data-tab="pakete">≡ Funkpakete</button><button data-tab="historie">◷ Verlauf</button><button data-tab="einstellungen">⚙ Einstellungen</button><button data-tab="updates">↻ Updates</button></div><span id="plattform" class="hidden"></span></nav>
<main><div class="row" style="justify-content:flex-end"><button id="farbschema" aria-label="Farbschema wechseln">◐</button></div><header><div><h1 id="seitentitel">Übersicht</h1></div><span class="badge off" id="verbindung">Verbindung wird geprüft</span></header>
<div class="card connection hidden" id="pcverbindung"><div class="row"><label>Verbindung<select id="art"><option>WLAN</option><option>USB</option></select></label><label>Heltec-IP<input id="adresse" value="192.168.4.1" placeholder="IP im Heimnetz"></label><label>TCP-Port<input id="netzPort" type="number" value="8765" min="1" max="65535"></label><label>USB-Port<select id="ports"></select></label><button id="portsNeu">Suchen</button><label>Baud<input id="baud" type="number" value="115200" style="width:105px"></label><button class="primary" id="verbinden">Verbinden</button><button id="trennen">Trennen</button></div></div>
<section id="start" class="section active"><div class="row spread" style="margin-bottom:18px"><label>Zähler<select id="zaehler"><option value="">Zähler auswählen</option></select></label><span class="sub" id="letztes">Noch keine Pakete</span></div>
<div class="grid"><div class="card hero" id="hero"><div class="row spread"><h2>Wasserzähler</h2><span class="badge off" id="messstatus">Keine Messwerte</span></div>
<svg class="meter" viewBox="0 0 500 250" aria-label="Schematische Darstellung eines Wasserzählers"><defs><linearGradient id="koerper" x2="0" y2="1"><stop stop-color="#fff"/><stop offset="1" stop-color="#d8e7e7"/></linearGradient><linearGradient id="metall"><stop stop-color="#829ba0"/><stop offset=".4" stop-color="#deebeb"/><stop offset="1" stop-color="#78989e"/></linearGradient></defs><ellipse cx="250" cy="229" rx="146" ry="12" fill="#163d4210"/><rect x="24" y="151" width="452" height="49" rx="9" fill="url(#metall)"/><path class="water" d="M30 175H137 M365 175H470"/><rect x="89" y="141" width="28" height="68" rx="5" fill="#708e94"/><rect x="381" y="141" width="28" height="68" rx="5" fill="#708e94"/><rect x="135" y="36" width="232" height="179" rx="29" fill="url(#koerper)" stroke="#b3ccce" stroke-width="2"/><path d="M158 43h186" stroke="white" stroke-width="5" stroke-linecap="round"/><text x="250" y="73" text-anchor="middle" class="meterlabel" style="letter-spacing:3px">WASSERZÄHLER</text><rect x="157" y="91" width="188" height="59" rx="8" fill="#d2e1d6" stroke="#b5cbbf"/><text id="zaehlerstandSvg" x="250" y="120" text-anchor="middle" class="metertext">— — —</text><text x="323" y="140" class="meterlabel">m³</text><circle cx="250" cy="188" r="14" fill="#c5ddda"/><g class="rotor"><path d="M248 176h4v24h-4z M238 186h24v4h-24z"/></g><text x="250" y="168" text-anchor="middle" class="meterlabel" id="idSvg">ID —</text></svg></div>
<div class="metrics"><div class="card metric"><small>ZÄHLERSTAND</small><strong id="volumen">— <span class="unit">m³</span></strong></div><div class="card metric"><small>DURCHFLUSS</small><strong id="fluss" class="kpi">— <span class="unit">l/min</span></strong></div><div class="card metric"><small>HEUTE</small><strong id="heute">— <span class="unit">l</span></strong></div><div class="card metric"><small>DIESEN MONAT</small><strong id="monat">— <span class="unit">m³</span></strong></div></div></div>
<div id="alarm" class="notice hidden" role="status"></div>
<div class="card below"><div class="row spread"><h2>Verbrauch</h2><select id="zeitraum" aria-label="Zeitraum"><option value="tag">Heute</option><option value="woche" selected>7 Tage</option><option value="monat">Dieser Monat</option></select></div><svg id="verbrauchGrafik" class="chart" viewBox="0 0 900 180" preserveAspectRatio="none"></svg><div class="row spread sub"><span id="gestern">Gestern: —</span><span>Erfasster Verbrauch</span><button id="statistikNeu">Aktualisieren</button></div></div>
<div id="zaehlerZusatz" class="below"><div class="row spread"><h2>Zählerzustand</h2><span id="zusatzAlter" class="badge off">Noch keine Daten</span></div><div class="metrics zusatzRaster"><div class="card metric"><small>BATTERIE · RESTLAUFZEIT</small><strong id="batterie">—</strong><span id="batterieHinweis" class="sub"></span></div><div class="card metric"><small>WASSERTEMPERATUR</small><strong id="temperatur">—</strong></div><div class="card metric"><small>UMGEBUNGSTEMPERATUR</small><strong id="umgebung">—</strong></div><div class="card metric"><small>ZÄHLERSTATUS</small><strong id="geraeteZustand">—</strong><span id="statusHinweis" class="sub"></span></div></div><div class="card below"><h2>Weitere Zählerwerte</h2><div id="zusatzWerte" class="zusatzWerte"></div><p id="zusatzLeer" class="sub">Keine weiteren Werte im Telegramm</p></div><div id="registerKarte" class="card below hidden"><h2>Gespeicherte Werte &amp; Tarife</h2><div class="scroll"><table><thead><tr><th>Messwert</th><th>Wert</th><th>Zuordnung</th></tr></thead><tbody id="registerWerte"></tbody></table></div></div></div>
<div class="notice" id="auswertung">Warte auf Empfang</div>
<div class="card below"><div class="row spread"><h2>Durchfluss im Verlauf</h2><span class="sub">l/min</span></div><svg id="verlauf" class="chart" viewBox="0 0 900 180" preserveAspectRatio="none"></svg><div class="sub" id="verlaufsinfo">Noch keine auswertbaren Durchflusswerte.</div></div>
<div class="card below"><h2>Messwerte</h2><div class="scroll"><table><thead><tr><th>Messwert</th><th>Wert</th><th>Einheit</th><th>Funktion</th><th>Speicher / Tarif / Gerät</th><th>Hinweis</th></tr></thead><tbody id="messwerte"></tbody></table></div><div class="empty" id="messLeer">Keine Messwerte</div><div class="row below"><span class="badge off" id="signal">RSSI —</span><span class="badge off" id="modus">Modus —</span><span class="badge off" id="anzahl">0 Pakete</span><button id="messExport">Messwerte exportieren</button></div></div></section>
<section id="diagnose" class="section"><div class="card"><h2>Empfang untersuchen</h2><div class="row"><button class="primary" data-command="TC">T/C auf 868,95 MHz</button><button data-command="SCAN">Aktivitätsscan starten</button><button data-command="STOP">Scan stoppen</button><input id="frequenz" value="868,95" aria-label="Frequenz in MHz" style="width:120px"><button id="freqSet">Frequenz testen</button></div><p class="statusline" id="funkstatus">Noch keine Statusmeldung</p><div class="scroll"><table><thead><tr><th>MHz eingestellt</th><th>Maximum dBm</th><th>Mittel dBm</th><th>Durchgang</th></tr></thead><tbody id="scans"></tbody></table></div></div><div class="card below"><h2>Gesehene Zähler</h2><div class="scroll"><table><thead><tr><th>Kennung</th><th>Hersteller</th><th>Medium</th><th>Version</th><th>Modus</th><th>MHz</th><th>Pakete</th><th>RSSI</th></tr></thead><tbody id="geraete"></tbody></table></div><div class="row below"><button id="bericht">Diagnosebericht speichern</button></div></div><div class="card below"><h2>Verbindungsprotokoll</h2><pre id="protokoll">Noch keine Meldungen.</pre></div></section>
<section id="pakete" class="section"><div class="card"><div class="row spread"><h2>Empfangene Funkpakete</h2><div class="row"><button id="csv">CSV speichern</button><button id="leeren">Sitzung leeren</button></div></div><div class="scroll"><table><thead><tr><th>Zeit</th><th>Kennung</th><th>Modus</th><th>RSSI</th><th>Bytes</th><th>Auswertung</th></tr></thead><tbody id="paketliste"></tbody></table></div><h2 class="below">Ausgewähltes Telegramm</h2><pre id="paketdetails">Paket auswählen</pre></div></section>
<section id="historie" class="section"><div class="card"><div class="row spread"><h2>Gespeicherte Messwerte</h2><div class="row"><button id="historieLaden">Verlauf laden</button><button id="historieExport">CSV exportieren</button></div></div><p class="statusline" id="historieStatus">Noch nicht geladen</p><label>Zähler<select id="historieId"></select></label><svg id="historieGrafik" class="chart" viewBox="0 0 900 180" preserveAspectRatio="none"></svg><div class="scroll"><table><thead><tr><th>Zeit</th><th>Zähler</th><th>Stand m³</th><th>Durchfluss l/min</th><th>Status</th></tr></thead><tbody id="historieTabelle"></tbody></table></div><pre id="historieDetails" class="hidden"></pre></div></section>
<section id="einstellungen" class="section"><div class="card"><h2>Zähler verwalten</h2><form id="geraeteForm" class="form"><div class="row"><label>Gespeicherte Zähler<select id="geraetAuswahl"></select></label><button type="button" id="geraetHinzufuegen">+ Zähler hinzufügen</button></div><h2 id="geraetFormTitel">Zähler bearbeiten</h2><label>Funkkennung (8 Stellen)<input id="geraetId" maxlength="8" pattern="[0-9A-Fa-f]{8}" required></label><label>Name für die Übersicht<input id="geraetName" maxlength="48" placeholder="z. B. Wasserzähler Keller"></label><label>Neuer Schlüssel<input id="geraetKey" type="password" minlength="32" maxlength="32" autocomplete="new-password"></label><span id="keyStatus" class="sub"></span><label><span><input id="keyLoeschen" type="checkbox"> Schlüssel entfernen</span></label><div class="row"><button class="primary" id="geraetSpeichern">Änderungen speichern</button><button type="button" id="geraetAbbrechen" class="hidden">Abbrechen</button></div><p id="geraetMeldung" role="status"></p><button type="button" id="geraetZurUebersicht" class="hidden">In der Übersicht anzeigen</button></form></div><div class="card below"><h2>Datensicherung</h2><button id="sicherung">Sicherung herunterladen</button></div><div class="below"></div><div class="card"><h2>Heimnetz</h2><div id="pcWlan" class="hidden"><button class="primary" id="webOeffnen">WLAN-Einrichtung öffnen</button></div><div id="webWlan"><p id="wlanstatus" class="statusline">Status wird geladen</p><form id="wlanForm" class="form"><label>WLAN (2,4 GHz)<select id="wlanListe" required><option value="">WLAN auswählen</option><option value="manuell">Anderes / verborgenes WLAN</option></select></label><div><button type="button" id="wlanSuchen">WLANs suchen</button><p id="wlanSuchStatus" class="statusline"></p></div><input id="ssid" type="hidden"><label id="wlanManuellZeile" class="hidden">WLAN-Name<input id="wlanManuell" maxlength="32" autocomplete="off"></label><label>WLAN-Passwort<input id="passwort" type="password" minlength="8" maxlength="63" autocomplete="new-password" required></label><button class="primary" id="wlanSpeichern">Speichern & verbinden</button></form><h2 class="below">Accesspoint</h2><p class="statusline">HYDRUS-Monitor · 192.168.4.1</p><form id="apForm" class="form"><label>Neues WLAN-Passwort<input id="apPasswort" type="password" minlength="8" maxlength="63" autocomplete="new-password" required></label><label>Passwort wiederholen<input id="apWiederholung" type="password" minlength="8" maxlength="63" autocomplete="new-password" required></label><p class="sub">8–63 Zeichen ohne Umlaute. Danach mit dem neuen Passwort verbinden.</p><button id="apSpeichern" class="primary">Speichern &amp; neu starten</button><p id="apStatus" role="status"></p></form><h2 class="below">Messwertspeicher</h2><p id="speicherStatus" class="statusline">Status wird geladen</p><button id="speicherStart" class="hidden">Speicher einrichten</button></div></div></section>
<section id="updates" class="section"><div class="card"><h2>Software-Updates</h2><p id="updateVersion" class="statusline">Version 2.1.15</p><p id="updateStatus">Kein Update-Server eingerichtet</p><div class="row"><button id="updatePruefen">Nach Updates suchen</button><button id="updateInstallieren" disabled>Update installieren</button><button id="updateNeustart" class="hidden">Neue Version starten</button></div><h2 class="below">Update-Datei</h2><button id="updateDateiPc">Datei auswählen</button><form id="updateDateiForm" class="form"><input id="updateDatei" type="file" accept=".hup" required><button id="updateDateiSenden">Firmware installieren</button></form><details class="below"><summary>Update-Server</summary><div class="form below"><label>Versionsdatei (HTTPS)<input id="updateUrl" type="url" placeholder="https://…/version.json"></label><label id="caGruppe">CA-Zertifikat (optional)<textarea id="updateCa" rows="5" maxlength="4096"></textarea></label><button id="updateQuelle">Speichern</button></div></details></div></section><section id="warnungen" class="section"><div class="card"><h2>Leckwarnung und Empfang</h2><form id="warnForm" class="form"><label>Zähler<select id="warnZaehler"></select></label><div id="warnLeer" class="statusline">Zuerst einen Zähler hinzufügen.</div><div id="warnInhalt"><fieldset class="warnEinstellung"><legend>Längerer Wasserfluss</legend><label class="warnSchalter"><input id="leckAktiv" type="checkbox" checked> Bei anhaltendem Wasserfluss warnen</label><div class="warnFelder"><label>Mindestens so viel Wasser<input id="leckLiter" type="number" min="0.001" max="1000" step="0.001" value="0.1" required><span class="sub">Liter pro Minute · feste Grenze</span></label><label>So lange ohne Unterbrechung<input id="leckDauer" type="number" min="1" max="1440" value="30" required><span class="sub">Minuten</span></label></div><p id="leckErklaerung" class="warnZusammenfassung" role="status"></p><p class="sub">Fällt der gemeldete Durchfluss unter die Grenze, beginnt die Zeitmessung beim nächsten Überschreiten neu. Auch normales, längeres Wasserlaufen kann eine Warnung auslösen.</p></fieldset><fieldset class="warnEinstellung"><legend>Keine neuen Zählerdaten</legend><label>Warnen nach<input id="empfangDauer" type="number" min="1" max="1440" value="10" required><span class="sub">Minuten ohne neue Daten</span></label><p id="empfangErklaerung" class="warnZusammenfassung" role="status"></p></fieldset><button id="warnSpeichern" class="primary">Einstellungen speichern</button></div><p id="warnMeldung" role="status"></p></form><button id="warnWeb" class="hidden">Leckwarnung am Gerät einstellen</button></div></section></main><div id="meldung" class="hidden" role="status"></div>
<script id="decoder">
// Gleiche Feldgrenzen und Einheiten wie im Python-Auswerter. Unbekanntes bleibt sichtbar.
const zustandsnamen={REAL_DATA_DEKODIERT:'Real Data · Prüfsumme OK, nicht authentifiziert',REAL_DATA_SCHLUESSEL_FEHLT:'Diehl Real Data · Schlüssel fehlt',REAL_DATA_PRUEFSUMME_FALSCH:'Diehl Real Data · Schlüssel oder Format passt nicht',REAL_DATA_FORMAT_NICHT_UNTERSTUETZT:'Real-Data-Variante nicht unterstützt',DIEHL_REAL_DATA:'Real Data · Firmware-Update nötig',SCHLUESSEL_FEHLT:'AES-Schlüssel fehlt im Heltec',SCHLUESSEL_UNGUELTIG:'Schlüsseleintrag ungültig',ENTSCHLUESSELT:'Entschlüsselt',UNVERSCHLUESSELT:'Unverschlüsselt',ROHDATEN:'Rohdaten'};
function hexBytes(s){if(typeof s!=='string'||s.length%2||!/^[\da-f]*$/i.test(s)||s.length>512)throw Error('Ungültige Nutzdaten');return Uint8Array.from(s.match(/../g)||[],x=>parseInt(x,16));}
function hex(b){return Array.from(b,x=>x.toString(16).padStart(2,'0')).join('').toUpperCase()}
function datum(b){if(b.length===4){if(b[0]&128)throw Error('Ungültiges Datum');let h=b[1]&31,m=b[0]&63;if(h>23||m>59)throw Error('Ungültige Uhrzeit');return datum(b.slice(2))+' '+String(h).padStart(2,'0')+':'+String(m).padStart(2,'0')}if(b.length!==2)throw Error('Datumsformat unbekannt');let d=b[0]&31,m=b[1]&15,y=((b[0]>>5)&7)|((b[1]>>1)&120),v=new Date(Date.UTC(2000+y,m-1,d));if(y>99||v.getUTCDate()!==d||v.getUTCMonth()!==m-1)throw Error('Ungültiges Datum');return v.toISOString().slice(0,10)}
function einheit(v,e){let b=v&127;if(e.length){if(b===125&&e.length===1){if(e[0]===23)return['Fehlerflags (Rohbits)','Hex',0];if(e[0]===116)return['Batterie-Restlaufzeit','Tage',0];if(e[0]===8)return['Übertragungszähler','',0];if(e[0]>=44&&e[0]<=47)return['Zeit seit letzter Auslesung',['s','min','h','Tage'][e[0]&3],0]}if(e.length===1&&[59,60].includes(e[0])&&b>=16&&b<=23)return[e[0]===59?'Vorwärtsvolumen':'Rückwärtsvolumen','m³',b-22];return null}let g=[[0,7,'Energie','Wh',-3],[8,15,'Energie','J',0],[16,23,'Volumen','m³',-6],[24,31,'Masse','kg',-3],[40,47,'Leistung','W',-3],[48,55,'Leistung','J/h',0],[56,63,'Durchfluss','m³/h',-6],[64,71,'Durchfluss','m³/min',-7],[72,79,'Durchfluss','m³/s',-9],[80,87,'Massenfluss','kg/h',-3],[88,91,'Vorlauftemperatur','°C',-3],[92,95,'Rücklauftemperatur','°C',-3],[96,99,'Temperaturdifferenz','K',-3],[100,103,'Externe Temperatur','°C',-3],[104,107,'Druck','bar',-3]];for(let[a,z,n,u,k]of g)if(b>=a&&b<=z)return[n,u,k+b-a];if(b>=32&&b<=39)return[b>=36?'Betriebsdauer':'Einschaltdauer',['s','min','h','Tage'][b&3],0];if([108,109].includes(b))return[b===108?'Datum':'Datum/Uhrzeit','',0];return null}
function zahl(b,k,unsigniert=false){if([1,2,3,4,6,7].includes(k)){let n=0n;for(let i=b.length-1;i>=0;--i)n=(n<<8n)|BigInt(b[i]);if(!unsigniert&&b.length&&(b[b.length-1]&128))n-=1n<<BigInt(b.length*8);if(n>BigInt(Number.MAX_SAFE_INTEGER)||n<BigInt(Number.MIN_SAFE_INTEGER))throw Error('Zahl außerhalb exakter Browserdarstellung');return Number(n)}if(k===5){let n=new DataView(b.buffer,b.byteOffset,b.length).getFloat32(0,true);if(!Number.isFinite(n))throw Error('Ungültige Zahl');return n}if([9,10,11,12,14].includes(k)){let s=hex(b.slice().reverse()),neg=s.startsWith('F');if(neg)s=s.slice(1);if(!/^\d+$/.test(s))throw Error('Ungültige BCD-Zahl');return Number(s)*(neg?-1:1)}throw Error('Datentyp nur als Rohdaten verfügbar')}
function dekodieren(p){let name=zustandsnamen[p.auswertung]||p.auswertung||'Rohdaten';if(p.auswertung==='ENTSCHLUESSELT')name+=p.authentifiziert?' · MAC geprüft':' · ohne MAC-Authentifizierung';if(!['REAL_DATA_DEKODIERT','ENTSCHLUESSELT','UNVERSCHLUESSELT'].includes(p.auswertung))return{felder:[],text:name};if(p.sicherheitsmodus===7&&!p.authentifiziert)return{felder:[],text:'Modus 7 ohne bestätigte MAC-Prüfung'};let a,felder=[],fehler=[];try{a=hexBytes(p.nutzdaten_hex||'')}catch(e){return{felder:[],text:e.message}}let i=0;const laengen={0:0,1:1,2:2,3:3,4:4,5:4,6:6,7:8,8:0,9:1,10:2,11:3,12:4,14:6};while(i<a.length){let start=i,d=a[i++];if(d===47)continue;let f={bezeichnung:'Unbekanntes Feld',wert:'—',einheit:'',funktion:'',speicher:0,tarif:0,untereinheit:0,dif_vif:'',rohwert:'',hinweis:''};try{if((d&15)===15)throw Error('Herstellerspezifische Daten vorhanden');f.speicher=(d>>6)&1;let alt=d,j=0;while(alt&128){if(i>=a.length||j>=10)throw Error('DIFE-Kette unvollständig/zu lang');alt=a[i++];f.speicher+=(alt&15)*2**(1+4*j);f.tarif+=((alt>>4)&3)*2**(2*j);f.untereinheit+=((alt>>6)&1)*2**j;j++}if(i>=a.length)throw Error('VIF fehlt');let v=a[i++],e=[];if((v&127)===124)throw Error('Text-VIF nicht unterstützt');alt=v;while(alt&128){if(i>=a.length||e.length>=10)throw Error('VIFE-Kette unvollständig/zu lang');alt=a[i++];e.push(alt&127)}let ende=i,k=d&15,l=laengen[k];if(k===13){if(i>=a.length)throw Error('Variable Datenlänge fehlt');let x=a[i++];if(x>239)throw Error('Variable Sonderlänge nicht unterstützt');l=x<=191?x:x&15}if(l===undefined||i+l>a.length)throw Error('Datensatz abgeschnitten');let b=a.slice(i,i+l);i+=l;Object.assign(f,{funktion:['Momentanwert','Maximum','Minimum','Wert im Fehlerzustand'][(d>>4)&3],dif_vif:hex(a.slice(start,ende)),rohwert:hex(b)});let u=einheit(v,e);if(!u)f.hinweis='Einheit/Erweiterung nicht interpretiert';else{[f.bezeichnung,f.einheit]=u;try{if(u[1]==='Hex'){f.wert='0x'+hex(b.slice().reverse());f.hinweis='Bedeutung der Bits herstellerabhängig'}else if([108,109].includes(v&127)){if(k!==((v&127)===108?2:4))throw Error('Abweichender Datums-Datentyp');f.wert=datum(b)}else f.wert=String(Number((zahl(b,k,['Übertragungszähler','Batterie-Restlaufzeit'].includes(f.bezeichnung))*10**u[2]).toPrecision(15)))}catch(err){f.hinweis=err.message}}felder.push(f)}catch(err){fehler.push(err.message);f.bezeichnung='Nicht auswertbarer Rest';f.rohwert=hex(a.slice(start));f.hinweis=err.message;felder.push(f);break}}if(fehler.length){if(p.auswertung==='REAL_DATA_DEKODIERT')return{felder:[],text:name+' · Datenstruktur unplausibel: '+fehler.join('; ')};name+=' · '+fehler.join('; ')}return{felder,text:name}}
function kopf(p){let a;try{a=hexBytes(p.hex)}catch(e){return{}}if(a.length<11)return{};let n=a[2]+256*a[3],m=[10,5,0].map(s=>String.fromCharCode(64+((n>>s)&31))).join(''),real=['DME','HYD','EWT','SAP','SPL'].includes(m)&&[68,70].includes(a[1])&&(a[10]===113||(a[10]===122&&a.length>=15&&(a[14]&16)));let med=a[real?5:9],ver=a[real?4:8];let namen={0:'Sonstiges',1:'Öl',2:'Strom',3:'Gas',4:'Wärme',5:'Dampf',6:'Warmwasser',7:'Wasser',8:'Heizkostenverteiler',9:'Druckluft',10:'Kälte (Auslauf)',11:'Kälte (Einlauf)',12:'Wärme (Vorlauf)',13:'Wärme/Kälte',14:'Systemkomponente',15:'Unbekannt',21:'Heißwasser',22:'Kaltwasser',23:'Warm-/Kaltwasser',24:'Druck',25:'A/D-Wandler',26:'Rauchmelder',27:'Raumsensor',28:'Gasdetektor',32:'Elektrischer Schalter',33:'Ventil',37:'Kundenanzeige',40:'Abwasser',41:'Abfall',54:'Funkkonverter (System)',55:'Funkkonverter (Zähler)'};return{hersteller:m,medium:namen[med]||'Medium 0x'+med.toString(16).padStart(2,'0'),version:'0x'+ver.toString(16).padStart(2,'0')}}
</script><script>
'use strict';const $=id=>document.getElementById(id),pc=new URLSearchParams(location.search).has('pc');let bridge=null,online=false,token='',letzteLaufzeit=0,wahl=localStorage.getItem('hydrus-kennung')||'',letztesNetz=0;let zaehler=new Map(),pakete=[],scans=new Map(),logs=[],folge=0,benachrichtigung;
function melden(s){$('meldung').textContent=s;$('meldung').classList.remove('hidden');clearTimeout(benachrichtigung);benachrichtigung=setTimeout(()=>$('meldung').classList.add('hidden'),7000)}
function log(s){logs.push(s);if(logs.length>500)logs.shift();$('protokoll').textContent=logs.join('\n')}
function verbindung(ok,text){online=ok;$('verbindung').textContent=text;$('verbindung').className='badge '+(ok?'':'off');aktualisieren()}
function zeile(tbody,werte,aktion){let tr=document.createElement('tr');for(const w of werte){let td=document.createElement('td');td.textContent=w??'—';tr.append(td)}if(aktion)tr.onclick=aktion;tbody.append(tr);return tr}
function zeigen(tab){document.querySelectorAll('.section').forEach(x=>x.classList.toggle('active',x.id===tab));document.querySelectorAll('[data-tab]').forEach(x=>x.classList.toggle('active',x.dataset.tab===tab));$('seitentitel').textContent={start:'Übersicht',diagnose:'Funksuche & Diagnose',pakete:'Funkpakete',einstellungen:'Einstellungen',historie:'Verlauf',updates:'Updates'}[tab]}
document.querySelectorAll('[data-tab]').forEach(b=>b.onclick=()=>zeigen(b.dataset.tab));
function feldwert(felder,namen){let f=felder.find(f=>namen.includes(f.bezeichnung)&&f.funktion==='Momentanwert'&&f.speicher===0&&f.tarif===0&&f.untereinheit===0&&!f.hinweis);if(!f||!Number.isFinite(Number(f.wert)))return null;return f}
function durchfluss(felder){let f=feldwert(felder,['Durchfluss']);if(!f)return null;return Number(f.wert)*({'m³/h':1000/60,'m³/min':1000,'m³/s':1000*60}[f.einheit]??NaN)}
function aufnehmen(e){const p=e.paket,id=p.zaehlerkennung||'Unbekannt',alt=zaehler.get(id),seq=e.seq??++folge,zeit=Date.now()-(e.alter_ms||0);if(alt&&alt.seq===seq){alt.zeit=zeit;return}let d=p.felder?{felder:p.felder,text:p.auswertung_text}:dekodieren(p),k=p.kopf||kopf(p);let historisch=alt?.verlauf||[],fluss=durchfluss(d.felder);if(Number.isFinite(fluss))historisch.push([zeit,fluss]);if(historisch.length>120)historisch.shift();let o={p,felder:d.felder,text:d.text,k,zeit,seq,anzahl:e.anzahl??((alt?.anzahl||0)+1),verlauf:historisch};zaehler.set(id,o);pakete.push({...p,zeit:new Date(zeit).toISOString()});if(pakete.length>5000)pakete.shift();auswahl();if(id===wahl){$('hero').classList.remove('pulse');void $('hero').offsetWidth;$('hero').classList.add('pulse')}tabellen();aktualisieren()}
function auswahl(){if(!wahl&&zaehler.size)wahl=zaehler.keys().next().value;let ids=[...new Set([wahl,...zaehler.keys()])].filter(Boolean);$('zaehler').replaceChildren();for(let id of ids){let o=document.createElement('option');o.value=id;o.textContent=id+(zaehler.has(id)?'':' · wartet auf Empfang');$('zaehler').append(o)}$('zaehler').value=wahl}
$('zaehler').onchange=()=>{wahl=$('zaehler').value;localStorage.setItem('hydrus-kennung',wahl);aktualisieren()};
function wert(id,f,unit){let n=f===null?'—':Number(f).toLocaleString('de-DE',{minimumFractionDigits:unit==='m³'?3:1,maximumFractionDigits:unit==='m³'?3:2});$(id).replaceChildren(document.createTextNode(n+' '));let s=document.createElement('span');s.className='unit';s.textContent=unit;$(id).append(s)}
function aktualisieren(){let o=zaehler.get(wahl),alter=o?Math.max(0,Math.floor((Date.now()-o.zeit)/1000)):null,frisch=online&&alter!==null&&alter<=120,f=o?.felder||[],v=feldwert(f,['Volumen']),t=feldwert(f,['Vorlauftemperatur']),b=feldwert(f,['Batterie-Restlaufzeit']),fluss=durchfluss(f);wert('volumen',v?Number(v.wert):null,'m³');wert('fluss',Number.isFinite(fluss)?fluss:null,'l/min');wert('temperatur',t?Number(t.wert):null,'°C');wert('batterie',b?Number(b.wert):null,'Tage');$('zaehlerstandSvg').textContent=v?Number(v.wert).toLocaleString('de-DE',{minimumFractionDigits:3,maximumFractionDigits:3}):'— — —';$('idSvg').textContent='ID '+wahl;$('hero').classList.toggle('running',frisch&&fluss!==null&&fluss>0);$('letztes').textContent=o?'Letztes Paket vor '+alter+' s':'Noch kein Paket dieses Zählers';$('messstatus').textContent=!o?'Warte auf Empfang':!frisch?'Daten veraltet':!f.length?'Keine Messwerte':'Messwerte empfangen';$('messstatus').className='badge '+(!frisch||!f.length?'warn':'');$('auswertung').textContent=(o?.text||'Warte auf Empfang')+(!frisch&&o?' · Nicht aktuell.':'');$('signal').textContent='RSSI '+(o?.p.rssi??'—')+' dBm';$('modus').textContent='Modus '+(o?.p.modus||'—');$('anzahl').textContent=(o?.anzahl||0)+' Pakete';$('messwerte').replaceChildren();for(let x of f)zeile($('messwerte'),[x.bezeichnung,x.wert,x.einheit,x.funktion,[x.speicher,x.tarif,x.untereinheit].join(' / '),x.hinweis]);$('messLeer').classList.toggle('hidden',!!f.length);chart(o?.verlauf||[]);if(typeof zusatzAktualisieren==='function')zusatzAktualisieren()}
function chart(v){let s=$('verlauf');s.replaceChildren();function svg(tag,a){let e=document.createElementNS('http://www.w3.org/2000/svg',tag);for(let[k,v]of Object.entries(a))e.setAttribute(k,v);s.append(e);return e}let max=Math.max(1,...v.map(p=>p[1])),min=Math.min(0,...v.map(p=>p[1])),span=max-min;for(let i=0;i<4;i++){let y=12+i*45;svg('line',{x1:48,y1:y,x2:890,y2:y,stroke:'#e2eeea'});svg('text',{x:3,y:y+4}).textContent=(max-span*i/3).toFixed(1)}if(!v.length)return;let x0=v[0][0],dt=Math.max(1,v[v.length-1][0]-x0);let coords=v.map(p=>[48+(p[0]-x0)/dt*830,12+(max-p[1])/span*135]);svg('polyline',{points:coords.map(p=>p.join(',')).join(' '),fill:'none',stroke:'#0c9687','stroke-width':3,'stroke-linejoin':'round'});for(let p of coords)svg('circle',{cx:p[0],cy:p[1],r:3,fill:'#0c9687'});$('verlaufsinfo').textContent=v.length+' Messpunkte · '+new Date(x0).toLocaleTimeString('de-DE')+' bis '+new Date(v[v.length-1][0]).toLocaleTimeString('de-DE')}
function tabellen(){$('geraete').replaceChildren();for(let[id,o]of zaehler)zeile($('geraete'),[id,o.k.hersteller,o.k.medium,o.k.version,o.p.modus,o.p.frequenz_hz?(o.p.frequenz_hz/1e6).toFixed(3):'—',o.anzahl,o.p.rssi],()=>{wahl=id;auswahl();zeigen('start');aktualisieren()});$('paketliste').replaceChildren();for(let p of pakete.slice(-200).reverse())zeile($('paketliste'),[new Date(p.zeit).toLocaleTimeString('de-DE'),p.zaehlerkennung,p.modus,p.rssi,p.hex.length/2,p.auswertung],()=>{$('paketdetails').textContent=JSON.stringify(p,null,2)});$('scans').replaceChildren();for(let s of [...scans.values()].sort((a,b)=>b.maximum_dbm-a.maximum_dbm))zeile($('scans'),[(s.frequenz_hz/1e6).toFixed(3),s.maximum_dbm,s.mittel_dbm,s.durchgang],()=>{$('frequenz').value=(s.frequenz_hz/1e6).toFixed(2)})}
function ereignis(raw){try{let e=typeof raw==='string'?JSON.parse(raw):raw;if(e.typ==='update')updateAnzeige(e);if(e.typ==='statistik')statistikLesen(e.text);if(e.typ==='verlauf')historieLesen(e.text);if(e.typ==='paket')aufnehmen(e);if(e.typ==='status'){log(e.text);$('funkstatus').textContent=e.text}if(e.typ==='scan'){scans.set(e.daten.frequenz_hz,e.daten);tabellen()}if(e.typ==='verbindung')verbindung(e.online,e.text);if(e.typ==='ports'){$('ports').replaceChildren();for(let p of e.ports){let o=document.createElement('option');o.value=o.textContent=p;$('ports').append(o)}}if(e.typ==='meldung')melden(e.text)}catch(e){melden('Daten konnten nicht verarbeitet werden: '+e.message)}}
async function sitzungLaden(){let r=await fetch('/api/einrichtung',{cache:'no-store'});if(!r.ok)throw Error('Einrichtung nicht erreichbar');let j=await r.json();token=j.token;}
async function senden(c){try{if(pc){bridge.senden(c);return}if(!token)await sitzungLaden();let r=await fetch('/api/befehl',{method:'POST',headers:{'X-Hydrus-Token':token},body:new URLSearchParams({befehl:c})});let t=await r.text();if(!r.ok)throw Error(t);melden(t)}catch(e){melden(e.message)}}
document.querySelectorAll('[data-command]').forEach(b=>b.onclick=()=>senden(b.dataset.command));$('freqSet').onclick=()=>{let n=Number($('frequenz').value.replace(',','.'));if(!Number.isFinite(n)||n<863||n>870){melden('Bitte 863 bis 870 MHz eingeben.');return}senden('FREQ '+Math.round(n*1e6))};
$('wlanForm').onsubmit=async e=>{e.preventDefault();$('wlanSpeichern').disabled=true;const neuerName=$('ssid').value,neuesPasswort=$('passwort').value;try{if(!token)await sitzungLaden();$('ssid').value=neuerName;let r=await fetch('/api/wlan',{method:'POST',headers:{'X-Hydrus-Token':token},body:new URLSearchParams({ssid:neuerName,passwort:neuesPasswort})});let t=await r.text();if(!r.ok)throw Error(t);$('passwort').value='';melden(t)}catch(e){melden(e.message)}finally{$('wlanSpeichern').disabled=false}};
function datei(name,text,typ){let a=document.createElement('a');a.href=URL.createObjectURL(new Blob(['\ufeff'+text],{type:typ}));a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(a.href),2000)}
function csv(zeilen){return zeilen.map(r=>r.map(v=>{let s=String(v??'');if(/^[=+@-]/.test(s))s="'"+s;return '"'+s.replaceAll('"','""')+'"'}).join(';')).join('\r\n')}
function exportieren(art){if(pc){bridge.exportieren(art);return}if(art==='bericht'){datei('diagnose.json',JSON.stringify({zeit:new Date().toISOString(),zaehler:[...zaehler],scans:[...scans.values()],pakete},null,2),'application/json');return}if(art==='messwerte'){let z=[['Kennung','Messwert','Wert','Einheit','Funktion','Speicher','Tarif','Gerät','Hinweis']];for(let[id,o]of zaehler)for(let f of o.felder)z.push([id,f.bezeichnung,f.wert,f.einheit,f.funktion,f.speicher,f.tarif,f.untereinheit,f.hinweis]);datei('messwerte.csv',csv(z),'text/csv');return}datei('funkpakete.csv',csv([['PC-Zeit','Zaehlerkennung','RSSI_dBm','Modus','Hex'],...pakete.map(p=>[p.zeit,p.zaehlerkennung,p.rssi,p.modus,p.hex])]),'text/csv')}
$('csv').onclick=()=>exportieren('pakete');$('bericht').onclick=()=>exportieren('bericht');$('messExport').onclick=()=>exportieren('messwerte');$('leeren').onclick=()=>{pakete=[];zaehler.clear();scans.clear();logs=[];$('protokoll').textContent='';$('paketdetails').textContent='';$('verlaufsinfo').textContent='Noch keine auswertbaren Durchflusswerte.';if(pc)bridge.leeren();auswahl();tabellen();aktualisieren()};
async function abfragen(){try{let r=await fetch('/api/status',{cache:'no-store',signal:AbortSignal.timeout(5000)});if(!r.ok)throw Error('HTTP '+r.status);let j=await r.json();if(j.laufzeit_ms<letzteLaufzeit){zaehler.clear();scans.clear();melden('Heltec neu gestartet. Empfangszähler zurückgesetzt.')}letzteLaufzeit=j.laufzeit_ms;komfortStatus(j);if(j.speicher){$('speicherStatus').textContent=j.speicher.fehler||(j.speicher.bereit?'Aktiv · '+Math.round(j.speicher.bytes/1024)+' / 512 KiB · alle 5 Minuten':'Nicht eingerichtet');$('speicherStart').classList.toggle('hidden',j.speicher.bereit)}if(!historieGeladen&&j.speicher?.bereit){historieGeladen=true;historieLaden()}letztesNetz=Date.now();verbindung(true,j.wlan.verbunden?'Heimnetz verbunden':'Einrichtungs-WLAN');$('wlanstatus').textContent=(j.wlan.verbunden?'Verbunden mit ':'Noch keine Heimnetzverbindung: ')+j.wlan.ssid+' · IP '+j.wlan.ip;$('funkstatus').textContent=j.status;for(let p of j.pakete.sort((a,b)=>a.seq-b.seq))aufnehmen(p);for(let s of j.scans)scans.set(s.frequenz_hz,s);tabellen()}catch(e){verbindung(false,'Heltec nicht erreichbar')}setTimeout(abfragen,2000)}

let historie=[],historieGeladen=false;
function historieLesen(text){historie=[];let defekt=0;for(const zeile of text.split('\n')){if(!zeile.trim())continue;try{let x=JSON.parse(zeile);if(!x.paket||!x.paket.zaehlerkennung)throw Error();x.werte=dekodieren(x.paket);historie.push(x)}catch(e){defekt++}}$('historieStatus').textContent=historie.length+' Einträge'+(defekt?' · '+defekt+' beschädigte Einträge übersprungen':'');let aus=$('historieId'),vorher=aus.value||wahl;aus.replaceChildren();for(const id of new Set(historie.map(x=>x.paket.zaehlerkennung))){let o=document.createElement('option');o.value=o.textContent=id;aus.append(o)}if([...aus.options].some(o=>o.value===vorher))aus.value=vorher;historieZeigen()}
function historieZeit(x){return Number.isFinite(x.zeit)&&x.zeit>1700000000?new Date(x.zeit*1000).toLocaleString('de-DE'):'Ohne Uhrzeit · Start '+x.boot+' · '+Math.floor(x.laufzeit_ms/60000)+' min'}
function historieZeigen(){let liste=historie.filter(x=>x.paket.zaehlerkennung===$('historieId').value);$('historieTabelle').replaceChildren();for(const x of liste.slice(-1000).reverse()){let v=feldwert(x.werte.felder,['Volumen']),f=durchfluss(x.werte.felder);zeile($('historieTabelle'),[historieZeit(x),x.paket.zaehlerkennung,v?Number(v.wert).toLocaleString('de-DE',{maximumFractionDigits:6}):'—',Number.isFinite(f)?f.toLocaleString('de-DE'):'—',x.werte.text],()=>{$('historieDetails').classList.remove('hidden');$('historieDetails').textContent=JSON.stringify(x,null,2)})}let svg=$('historieGrafik');svg.replaceChildren();let punkte=liste.map(x=>[x.zeit,feldwert(x.werte.felder,['Volumen'])]).filter(x=>x[0]>1700000000&&x[1]).map(x=>[x[0],Number(x[1].wert)]).sort((a,b)=>a[0]-b[0]);if(punkte.length<2)return;let min=Math.min(...punkte.map(x=>x[1])),max=Math.max(...punkte.map(x=>x[1])),anf=punkte[0][0],ende=punkte.at(-1)[0];let linie=document.createElementNS('http://www.w3.org/2000/svg','polyline');linie.setAttribute('points',punkte.map(x=>(40+820*(x[0]-anf)/Math.max(1,ende-anf))+','+(140-110*(x[1]-min)/Math.max(.001,max-min))).join(' '));linie.setAttribute('fill','none');linie.setAttribute('stroke','#087f78');linie.setAttribute('stroke-width','2');svg.append(linie);for(const [x,y,t]of [[40,20,'Zählerstand '+min.toLocaleString('de-DE')+' – '+max.toLocaleString('de-DE')+' m³'],[40,170,new Date(anf*1000).toLocaleString('de-DE')],[600,170,new Date(ende*1000).toLocaleString('de-DE')]]){let e=document.createElementNS(svg.namespaceURI,'text');e.setAttribute('x',x);e.setAttribute('y',y);e.textContent=t;svg.append(e)}}
async function historieLaden(){try{$('historieStatus').textContent='Lädt …';if(pc){if(!bridge)throw Error('Noch nicht bereit');bridge.verlaufLaden($('adresse').value);return}let r=await fetch('/api/verlauf',{cache:'no-store',signal:AbortSignal.timeout(30000)});if(!r.ok)throw Error(await r.text());historieLesen(await r.text())}catch(e){$('historieStatus').textContent=e.message}}
$('historieLaden').onclick=historieLaden;$('historieId').onchange=historieZeigen;
$('historieExport').onclick=()=>{let z=[['Zeit','Start','Laufzeit_ms','Kennung','Messwert','Wert','Einheit','Funktion','Speicher','Tarif','Gerät']];for(let x of historie)for(let f of x.werte.felder)z.push([x.zeit?new Date(x.zeit*1000).toISOString():'',x.boot,x.laufzeit_ms,x.paket.zaehlerkennung,f.bezeichnung,f.wert,f.einheit,f.funktion,f.speicher,f.tarif,f.untereinheit]);let text='\uFEFF'+z.map(r=>r.map(v=>'"'+String(v??'').replace(/^[=+@-]/,"'$&").replaceAll('"','""')+'"').join(';')).join('\r\n');if(pc){bridge.verlaufExportieren(text);return}let a=document.createElement('a'),u=URL.createObjectURL(new Blob([text],{type:'text/csv;charset=utf-8'}));a.href=u;a.download='hydrus-verlauf.csv';a.click();setTimeout(()=>URL.revokeObjectURL(u),1000)};
$('speicherStart').onclick=async()=>{if(!confirm('Messwertspeicher initialisieren? Vorhandene Daten in einer nicht lesbaren Speicherpartition werden gelöscht.'))return;try{if(!token)await sitzungLaden();let r=await fetch('/api/speicher',{method:'POST',headers:{'X-Hydrus-Token':token},body:new URLSearchParams({bestaetigung:'INITIALISIEREN'})});let t=await r.text();if(!r.ok)throw Error(t);melden(t)}catch(e){melden(e.message)}};

if(pc){$('pcverbindung').classList.remove('hidden');$('pcWlan').classList.remove('hidden');$('webWlan').classList.add('hidden');$('plattform').textContent='Desktop';let script=document.createElement('script');script.src='qrc:///qtwebchannel/qwebchannel.js';script.onload=()=>new QWebChannel(qt.webChannelTransport,c=>{bridge=c.objects.monitor;bridge.ereignis.connect(ereignis);bridge.bereit();$('verbinden').onclick=()=>bridge.verbinden($('art').value,$('art').value==='USB'?$('ports').value:$('adresse').value,Number($('art').value==='USB'?$('baud').value:$('netzPort').value));$('trennen').onclick=()=>bridge.trennen();$('portsNeu').onclick=()=>bridge.portsSuchen();$('webOeffnen').onclick=()=>bridge.webOeffnen($('adresse').value)});document.head.append(script)}else abfragen();auswahl();setInterval(aktualisieren,1000);
</script><script id="wlan-suche">
// WLAN-Suche des Heltec; unabhängig vom 868-MHz-Zählerempfang.
let wlanSchonGesucht=false,wlanSuchAktiv=false;
function wlanAuswaehlen(){
  const option=$('wlanListe').selectedOptions[0],manuell=option?.value==='manuell';
  $('wlanManuellZeile').classList.toggle('hidden',!manuell);
  $('wlanManuell').required=manuell;
  $('ssid').value=manuell?$('wlanManuell').value:(option?.dataset.ssid||'');
}
function wlanNetzeZeigen(netze){
  const bisher=$('ssid').value,sortiert=new Map();
  for(const n of netze||[])if(typeof n.ssid==='string'&&n.ssid&&(!sortiert.has(n.ssid)||n.rssi>sortiert.get(n.ssid).rssi))sortiert.set(n.ssid,n);
  const liste=$('wlanListe');liste.replaceChildren(new Option('WLAN auswählen',''));
  let nummer=0;
  for(const n of [...sortiert.values()].sort((a,b)=>b.rssi-a.rssi)){
    const o=new Option(n.ssid+' · '+n.rssi+' dBm'+(n.offen?' · offen':''),String(++nummer));o.dataset.ssid=n.ssid;
    // Die Heimnetz-Einrichtung verwendet ein WPA-Passwort.
    o.disabled=!!n.offen;liste.add(o);if(n.ssid===bisher&&!n.offen)o.selected=true;
  }
  liste.add(new Option('Anderes / verborgenes WLAN','manuell'));
  if(bisher&&![...liste.options].some(o=>o.dataset.ssid===bisher&&!o.disabled)){liste.value='manuell';$('wlanManuell').value=bisher;}
  wlanAuswaehlen();
  $('wlanSuchStatus').textContent=sortiert.size?sortiert.size+' WLANs gefunden':'Keine WLANs gefunden';
}
async function wlanSuchen(){
  if(pc||wlanSuchAktiv)return;
  wlanSuchAktiv=true;wlanSchonGesucht=true;$('wlanSuchen').disabled=true;$('wlanSuchStatus').textContent='WLANs werden gesucht …';
  try{
    if(!token)await sitzungLaden();
    const beginn=Date.now();let antwort=await fetch('/api/wlan/suche',{method:'POST',headers:{'X-Hydrus-Token':token},signal:AbortSignal.timeout(8000)});
    while(true){
      if(!antwort.ok)throw Error('WLAN-Suche fehlgeschlagen');const j=await antwort.json();
      if(j.fehler)throw Error(j.fehler);
      if(!j.laeuft){wlanNetzeZeigen(j.netze);break;}
      if(Date.now()-beginn>25000)throw Error('WLAN-Suche abgelaufen');
      await new Promise(r=>setTimeout(r,800));
      antwort=await fetch('/api/wlan/suche',{cache:'no-store',signal:AbortSignal.timeout(8000)});
    }
  }catch(e){$('wlanSuchStatus').textContent=e.message;}
  finally{wlanSuchAktiv=false;$('wlanSuchen').disabled=false;}
}
$('wlanListe').onchange=wlanAuswaehlen;$('wlanManuell').oninput=wlanAuswaehlen;$('wlanSuchen').onclick=wlanSuchen;
document.querySelector('[data-tab="einstellungen"]').addEventListener('click',()=>{if(!wlanSchonGesucht)wlanSuchen();});

// Kein Passwort wird vom Geraet zurueckgelesen oder im Browser gespeichert.
let apSpeichernAktiv=false;
$('apForm').onsubmit=async e=>{
  e.preventDefault();if(apSpeichernAktiv)return;
  const passwort=$('apPasswort').value;
  if(!/^[\x20-\x7e]{8,63}$/.test(passwort)){$('apStatus').textContent='8 bis 63 Zeichen ohne Umlaute verwenden';return;}
  if(passwort!==$('apWiederholung').value){$('apStatus').textContent='Passwörter stimmen nicht überein';return;}
  if(!confirm('Accesspoint-Passwort ändern und Heltec neu starten?'))return;
  apSpeichernAktiv=true;$('apSpeichern').disabled=true;$('apStatus').textContent='Passwort wird gespeichert …';
  try{
    if(!token)await sitzungLaden();
    const r=await fetch('/api/accesspoint',{method:'POST',headers:{'X-Hydrus-Token':token},body:new URLSearchParams({passwort}),signal:AbortSignal.timeout(10000)});
    const text=await r.text();if(!r.ok)throw Error(text);
    $('apPasswort').value='';$('apWiederholung').value='';$('apStatus').textContent=text;
  }catch(e){$('apStatus').textContent=e.message;}
  finally{apSpeichernAktiv=false;$('apSpeichern').disabled=false;}
};

</script>
<script id="komfort">
// Gemeinsame Funktionen für Handy und PySide6. Namen, Schlüssel und Warnregeln liegen im Heltec.
let geraeteKonfigGeladen=false;
let geraeteListe=[],geraeteStatus=new Map(),verbrauchDaten=new Map(),statistikGeladen=false;
const berlin=new Intl.DateTimeFormat('sv-SE',{timeZone:'Europe/Berlin',year:'numeric',month:'2-digit',day:'2-digit'});
function kalendertag(d,offset){let [y,m,t]=berlin.format(d).split('-').map(Number);return new Date(Date.UTC(y,m-1,t+offset,12));}
function tagnummer(d){return Number(berlin.format(d).replaceAll('-',''))}
function komfortStatus(j){
  if(j.zaehler){geraeteKonfigGeladen=true;geraeteListe=j.zaehler;geraeteAuswahl();auswahl();}
  for(const a of j.analyse||[])geraeteStatus.set(a.id,{...a,empfangen:Date.now()});
  if(j.verbrauch_fehler)melden(j.verbrauch_fehler);
  if(!statistikGeladen){statistikGeladen=true;statistikLaden();}
  komfortAktualisieren();
}
function statistikLesen(text){
  verbrauchDaten.clear();
  for(const z of text.split('\n'))try{
    if(!z.trim())continue;let d=JSON.parse(z);
    if(d.typ==='aktuell'){for(const a of d.werte||[])geraeteStatus.set(a.id,{...a,empfangen:Date.now()});continue;}
    if(!['tage','stunden'].includes(d.typ)||!Number.isFinite(d.m3)||d.m3<0)continue;
    let k=d.typ+':'+d.id+':'+d.periode,alt=verbrauchDaten.get(k);
    if(!alt||d.bis>=alt.bis)verbrauchDaten.set(k,d);
  }catch(e){/* Abgebrochene letzte Flash-Zeile überspringen. */}
  auswahl();komfortAktualisieren();
}
async function statistikLaden(){try{
  if(pc){if(bridge)bridge.statistikLaden($('adresse').value);return;}
  let r=await fetch('/api/statistik',{cache:'no-store',signal:AbortSignal.timeout(30000)});
  if(!r.ok)throw Error('Verbrauch nicht erreichbar');statistikLesen(await r.text());
}catch(e){melden(e.message)}}
function perioden(id,typ){let m=new Map();for(const d of verbrauchDaten.values())if(d.id===id&&d.typ===typ)m.set(d.periode,d.m3);
  let a=geraeteStatus.get(id);if(a?.zeit){if(typ==='tage')m.set(a.tag,a.tag_m3);else m.set(a.stunde,a.stunde_m3);}return m;}
function verbrauchWert(id,n,einheit){wert(id,Number.isFinite(n)?n:null,einheit);if(Number.isFinite(n)&&n>0)$(id).prepend(document.createTextNode('≥ '));}
function komfortAktualisieren(){
  let jetzt=new Date(),heute=tagnummer(jetzt),vorher=kalendertag(jetzt,-1),gestern=tagnummer(vorher),monat=Math.floor(heute/100),tage=perioden(wahl,'tage');
  verbrauchWert('heute',tage.has(heute)?tage.get(heute)*1000:null,'l');
  let bekannt=[...tage].filter(([t])=>Math.floor(t/100)===monat&&t<=heute);
  verbrauchWert('monat',bekannt.length?bekannt.reduce((s,[t,v])=>s+v,0):null,'m³');
  $('gestern').textContent='Gestern: '+(tage.has(gestern)?'≥ '+(tage.get(gestern)*1000).toLocaleString('de-DE',{maximumFractionDigits:1})+' l':'—');
  let a=geraeteStatus.get(wahl),g=geraeteListe.find(x=>x.id===wahl),o=zaehler.get(wahl),warn=[];
  let alter=a?Number(a.alter_s||0)+(Date.now()-a.empfangen)/1000:o?(Date.now()-o.zeit)/1000:0;
  if(!online)warn.push('Verbindung getrennt');
  if(alter>(g?.empfang_sekunden||a?.empfang_sekunden||600)||a?.empfang_fehlt)warn.push('Kein Zählerempfang');
  else if(a?.leckverdacht)warn.push('Leckverdacht · anhaltender Durchfluss');
  if(a?.zaehler_ruecksprung)warn.push('Zählerstand zurückgesetzt');
  $('alarm').textContent=warn.join(' · ');$('alarm').classList.toggle('hidden',!warn.length);
  verbrauchZeichnen(tage,jetzt);
}
function verbrauchZeichnen(tage,jetzt){
  let typ=$('zeitraum').value,werte=[],labels=[];
  if(typ==='tag'){
    const stunden=perioden(wahl,'stunden'),heute=tagnummer(jetzt);
    for(let h=Math.floor(jetzt.getTime()/3600000)-25;h<=Math.floor(jetzt.getTime()/3600000);h++){
      let d=new Date(h*3600000);if(tagnummer(d)!==heute)continue;
      werte.push(stunden.has(h)?stunden.get(h)*1000:null);labels.push(new Intl.DateTimeFormat('de-DE',{timeZone:'Europe/Berlin',hour:'2-digit'}).format(d));
    }
  }else{
    let anzahl=typ==='woche'?7:Number(berlin.format(jetzt).slice(-2));
    for(let i=anzahl-1;i>=0;i--){let d=kalendertag(jetzt,-i),tag=tagnummer(d);werte.push(tage.has(tag)?tage.get(tag)*1000:null);labels.push(String(tag%100));}
  }
  let svg=$('verbrauchGrafik');svg.replaceChildren();let max=Math.max(1,...werte.filter(Number.isFinite)),breite=820/Math.max(1,werte.length);
  function el(tag,attr,text){let e=document.createElementNS(svg.namespaceURI,tag);for(const[k,v]of Object.entries(attr))e.setAttribute(k,v);if(text!==undefined)e.textContent=text;return e;}
  svg.append(el('text',{x:20,y:15},'Liter'));
  werte.forEach((v,i)=>{let x=40+i*breite,hoehe=v===null?0:120*v/max;
    let balken=el('rect',{x,y:145-hoehe,width:Math.max(2,breite-5),height:Math.max(2,hoehe),fill:v===null?'#b6c5c1':'#168e80'});
    balken.append(el('title',{},labels[i]+': '+(v===null?'keine Daten':v.toLocaleString('de-DE')+' l')));svg.append(balken);
    if(i%Math.ceil(werte.length/12)===0)svg.append(el('text',{x,y:170},labels[i]));
  });
  if(!werte.some(Number.isFinite))svg.append(el('text',{x:330,y:80},'Noch keine Verbrauchsdaten'));
}
const bisherAufnehmen=aufnehmen;
aufnehmen=function(e){if(e.paket?.geraetestatus){let a=e.paket.geraetestatus;geraeteStatus.set(a.id,{...a,empfangen:Date.now()});}bisherAufnehmen(e);komfortAktualisieren();};
const bisherAuswahl=auswahl;
auswahl=function(){
 const ids=geraeteKonfigGeladen?geraeteListe.map(g=>g.id):[...new Set([...geraeteListe.map(g=>g.id),...geraeteStatus.keys(),...zaehler.keys(),wahl].filter(Boolean))];
 if(geraeteKonfigGeladen&&!ids.includes(wahl))wahl=ids[0]||'';
 if(!wahl&&ids.length)wahl=ids[0];$('zaehler').replaceChildren();
 for(const id of ids){const g=geraeteListe.find(g=>g.id===id),a=geraeteStatus.get(id),name=g?.name||a?.name;
  const text=(name&&name!==id?name+' · ':'')+id+(zaehler.has(id)?'':' · wartet auf Empfang');
  $('zaehler').append(new Option(text,id));
 }$('zaehler').value=wahl;
};
const bisherAktualisieren=aktualisieren;
aktualisieren=function(){bisherAktualisieren();komfortAktualisieren();};
// Beim PC-Verbindungsaufbau die im Gerät gespeicherten Summen nachladen.
const bisherVerbindung=verbindung;
verbindung=function(aktiv,text){let vorher=online;bisherVerbindung(aktiv,text);if(pc&&aktiv&&!vorher)statistikLaden();};
$('zeitraum').onchange=komfortAktualisieren;$('statistikNeu').onclick=statistikLaden;

let geraetNeu=false,geraetFormInitialisiert=false,geraetSpeichert=false;
function geraeteAuswahl(){
 const s=$('geraetAuswahl'),alt=s.value,ids=JSON.stringify(geraeteListe);
 if(s.dataset.ids===ids)return;s.dataset.ids=ids;s.replaceChildren();
 for(const g of geraeteListe)s.append(new Option(g.name&&g.name!==g.id?g.name+' · '+g.id:g.id,g.id));
 s.append(new Option('Neuen Zähler anlegen',''));
 s.value=geraetNeu?'':geraeteListe.some(g=>g.id===alt)?alt:geraeteListe[0]?.id||'';
 // Statusabfragen duerfen einen begonnenen Entwurf nicht zuruecksetzen.
 if(!geraetFormInitialisiert){geraetFormInitialisiert=true;geraetAnzeigen();}
 $('geraetHinzufuegen').disabled=geraeteListe.length>=8||geraetSpeichert;
}
function geraetAnzeigen(){
 const g=geraeteListe.find(x=>x.id===$('geraetAuswahl').value);geraetNeu=!g;
 $('geraetId').value=g?.id||'';$('geraetId').readOnly=!!g;
 $('geraetName').value=g?.name||'';$('geraetKey').value='';$('keyLoeschen').checked=false;
 $('keyStatus').textContent=g?.schluessel_vorhanden?'Schlüssel gespeichert · leer lassen zum Beibehalten':'Schlüssel optional · für verschlüsselte Messwerte erforderlich';

 $('geraetSpeichern').textContent=g?'Änderungen speichern':'Zähler hinzufügen';
 $('geraetFormTitel').textContent=g?'Zähler bearbeiten':'Neuen Zähler anlegen';
 if($('geraetLoeschen'))$('geraetLoeschen').classList.toggle('hidden',!g);
 $('geraetMeldung').textContent='';$('geraetAbbrechen').classList.toggle('hidden',!!g);
}
$('geraetAuswahl').onchange=()=>geraetAnzeigen();
$('geraetHinzufuegen').onclick=()=>{if(geraeteListe.length>=8)return;$('geraetAuswahl').value='';geraetAnzeigen();$('geraetId').focus();};
$('geraetAbbrechen').onclick=()=>{$('geraetAuswahl').value=geraeteListe[0]?.id||'';geraetAnzeigen();};
$('geraetZurUebersicht').onclick=()=>{zeigen('start');aktualisieren();};
$('geraeteForm').onsubmit=async e=>{
 e.preventDefault();if(geraetSpeichert)return;if(pc){bridge.webOeffnen($('adresse').value);return;}
 const id=$('geraetId').value.trim().toUpperCase(),name=$('geraetName').value.trim()||id,key=$('geraetKey').value.replace(/\s/g,'');
 if(!/^[0-9A-F]{8}$/.test(id)){$('geraetMeldung').textContent='Bitte die achtstellige Funkkennung eingeben.';return;}
 if(geraetNeu&&geraeteListe.some(g=>g.id===id)){$('geraetMeldung').textContent='Dieser Zähler ist bereits gespeichert. Oben zum Bearbeiten auswählen.';return;}
 if(geraetNeu&&geraeteListe.length>=8){$('geraetMeldung').textContent='Es sind bereits acht Zähler gespeichert.';return;}
 if(key&&!/^[0-9A-Fa-f]{32}$/.test(key)){$('geraetMeldung').textContent='Der AES-Schlüssel muss aus 32 Hex-Zeichen bestehen.';return;}
 const daten={id,name,bereich:'stammdaten',schluessel:key,schluessel_loeschen:$('keyLoeschen').checked?'1':'0',neu:geraetNeu?'1':'0'};
 geraetSpeichert=true;$('geraetSpeichern').disabled=true;$('geraetHinzufuegen').disabled=true;$('geraetAuswahl').disabled=true;
 $('geraetMeldung').textContent='Zähler wird gespeichert …';
 try{
  if(!token)await sitzungLaden();
  const r=await fetch('/api/zaehler',{method:'POST',headers:{'X-Hydrus-Token':token},body:new URLSearchParams(daten),signal:AbortSignal.timeout(15000)});
  const text=await r.text();if(!r.ok)throw Error(text);
  const alt=geraeteListe.find(g=>g.id===id),g={id,name,schluessel_vorhanden:daten.schluessel_loeschen==='1'?false:!!key||!!alt?.schluessel_vorhanden,leck_l_min:alt?.leck_l_min??.1,leck_sekunden:alt?.leck_sekunden??1800,empfang_sekunden:alt?.empfang_sekunden??600,leck_aktiv:alt?.leck_aktiv??true};
  geraeteListe=geraeteListe.filter(x=>x.id!==id);geraeteListe.push(g);geraetNeu=false;geraeteAuswahl();$('geraetAuswahl').value=id;geraetAnzeigen();
  wahl=id;localStorage.setItem('hydrus-kennung',id);auswahl();aktualisieren();
  $('geraetMeldung').textContent='Gespeichert. Der Zähler ist jetzt in der Übersicht auswählbar.';$('geraetZurUebersicht').classList.remove('hidden');
 }catch(err){$('geraetMeldung').textContent=err.message;}
 finally{geraetSpeichert=false;$('geraetSpeichern').disabled=false;$('geraetAuswahl').disabled=false;$('geraetHinzufuegen').disabled=geraeteListe.length>=8;}
};
$('sicherung').onclick=async()=>{if(pc){bridge.webOeffnen($('adresse').value);return;}try{if(!token)await sitzungLaden();let antwort=await Promise.all(['/api/konfiguration','/api/verlauf','/api/statistik'].map(u=>fetch(u,{cache:'no-store',signal:AbortSignal.timeout(30000)})));if(antwort.some(r=>!r.ok))throw Error('Sicherung unvollständig');let [konfiguration,verlauf,statistik]=await Promise.all(antwort.map(r=>r.text()));let daten={schema:2,erstellt:new Date().toISOString(),konfiguration:JSON.parse(konfiguration),verlauf,statistik};let u=URL.createObjectURL(new Blob([JSON.stringify(daten)],{type:'application/json'})),a=document.createElement('a');a.href=u;a.download='hydrus-sicherung-'+new Date().toISOString().slice(0,10)+'.json';a.click();setTimeout(()=>URL.revokeObjectURL(u),1000);}catch(e){melden(e.message)}};
function farbeSetzen(t){document.body.dataset.theme=t;localStorage.setItem('hydrus-farbe',t);}
farbeSetzen(localStorage.getItem('hydrus-farbe')||'hell');$('farbschema').onclick=()=>farbeSetzen(document.body.dataset.theme==='hell'?'dunkel':'hell');
if(pc){$('geraeteForm').classList.add('hidden');let hinweis=document.createElement('button');hinweis.textContent='Zählerverwaltung öffnen';hinweis.onclick=()=>bridge.webOeffnen($('adresse').value);$('geraeteForm').parentElement.append(hinweis);}
geraeteAuswahl();

</script><script id="updates-ui">
// Fortschritt bleibt auch beim Wechsel des Tabs erhalten.
let updateLaeuft=false,updateAngebotVorhanden=false;
const updateStil=document.createElement('style');
updateStil.textContent=`#updateFortschritt{margin:16px 0}#updateBalken{width:100%;height:14px;accent-color:var(--accent,#087f80)}.updateWarten{display:inline-block;width:14px;height:14px;border:2px solid #a6cccc;border-top-color:#087f80;border-radius:50%;animation:updateDrehen 1s linear infinite;margin-right:8px;vertical-align:middle}@keyframes updateDrehen{to{transform:rotate(360deg)}}@media(prefers-reduced-motion:reduce){.updateWarten{animation:none}}`;
document.head.append(updateStil);
$('updateStatus').insertAdjacentHTML('afterend','<div id="updateFortschritt" class="hidden" role="status" aria-live="polite"><span id="updateSpinner" class="updateWarten"></span><span id="updatePhase"></span><progress id="updateBalken" max="100" aria-label="Updatefortschritt"></progress></div>');
function updateFortschritt(aktiv,text,prozent=null){
  updateLaeuft=aktiv;
  $('updates').setAttribute('aria-busy',String(aktiv));
  $('updateFortschritt').classList.toggle('hidden',!aktiv&&prozent===null);
  $('updateSpinner').classList.toggle('hidden',!aktiv||prozent!==null);
  $('updatePhase').textContent=text+(prozent!==null?' · '+Math.round(prozent)+' %':'');
  if(prozent===null)$('updateBalken').removeAttribute('value');else $('updateBalken').value=Math.max(0,Math.min(100,prozent));
  for(const id of ['updatePruefen','updateQuelle','updateDateiPc','updateDateiSenden','updateDatei','updateNeustart'])$(id).disabled=aktiv;
  $('updateInstallieren').disabled=aktiv||!updateAngebotVorhanden;
}
function updateAnzeige(d){
  if(d.version)$('updateVersion').textContent='Version '+d.version;
  const text=d.meldung||d.text||'Bereit';$('updateStatus').textContent=text;
  if(d.url!==undefined)$('updateUrl').value=d.url;
  if(d.server!==undefined)$('updateUrl').value=d.server;
  if(d.angebot!==undefined)updateAngebotVorhanden=!!d.angebot;
  if(d.pfad)$('updateNeustart').classList.remove('hidden');
  if(d.aktiv===true)updateFortschritt(true,text,Number.isFinite(d.prozent)?d.prozent:null);
  else updateFortschritt(false,text,d.fertig||d.pfad?100:null);
}
function updateFehler(e){updateFortschritt(false,'');$('updateStatus').textContent=e.message||String(e);melden(e.message||String(e));}
async function updateAnfrage(pfad,body){
  if(!token)await sitzungLaden();
  let r=await fetch(pfad,{method:'POST',headers:{'X-Hydrus-Token':token},body,signal:AbortSignal.timeout(180000)});
  if(!r.ok)throw Error(await r.text());
  if((r.headers.get('content-type')||'').includes('json'))updateAnzeige(await r.json());else {const text=await r.text();updateAnzeige({text});}
}
const vorherZeigen=zeigen;
zeigen=function(tab){vorherZeigen(tab);if(tab==='updates'&&!pc&&!updateLaeuft)fetch('/api/update',{cache:'no-store'}).then(r=>{if(!r.ok)throw Error('Heltec nicht erreichbar');return r.json()}).then(d=>{if(!updateLaeuft)updateAnzeige(d)}).catch(e=>{if(!updateLaeuft)updateFehler(e)});};
$('updatePruefen').onclick=async()=>{if(updateLaeuft)return;updateFortschritt(true,'Suche nach Updates …');try{if(pc){bridge.updatePruefen($('updateUrl').value);return;}await updateAnfrage('/api/update/pruefen',new URLSearchParams());}catch(e){updateFehler(e)}};
$('updateInstallieren').onclick=async()=>{if(updateLaeuft||!confirm('Update installieren?'))return;updateFortschritt(true,'Update wird heruntergeladen, geprüft und installiert …');try{if(pc){bridge.updateInstallieren();return;}await updateAnfrage('/api/update/installieren',new URLSearchParams());}catch(e){updateFehler(e)}};
$('updateNeustart').onclick=()=>bridge.updateStarten();
$('updateDateiPc').onclick=()=>{if(!updateLaeuft)bridge.updateDatei()};
// Der Browser meldet echte Upload-Bytes. Danach ist die Geräteprüfung unbestimmt.
function updateDateiUebertragen(body){return new Promise((resolve,reject)=>{
  const x=new XMLHttpRequest();x.open('POST','/api/update/datei');x.setRequestHeader('X-Hydrus-Token',token);x.timeout=180000;
  x.upload.onprogress=e=>updateFortschritt(true,'Übertragung zum Heltec',e.lengthComputable&&e.total?Math.min(100,e.loaded/e.total*100):null);
  x.upload.onload=()=>updateFortschritt(true,'Firmware wird geprüft und abgeschlossen …');
  x.onload=()=>{if(x.status<200||x.status>=300){reject(Error(x.responseText||'Installation fehlgeschlagen'));return;}try{updateAnzeige(JSON.parse(x.responseText));resolve()}catch(e){reject(Error('Ungültige Update-Antwort'))}};
  x.onerror=()=>reject(Error('Verbindung unterbrochen. Gerätestatus vor erneutem Installieren prüfen.'));
  x.ontimeout=()=>reject(Error('Keine Antwort. Gerätestatus vor erneutem Installieren prüfen.'));
  x.onabort=()=>reject(Error('Übertragung abgebrochen'));x.send(body);
})}
$('updateDateiForm').onsubmit=async e=>{e.preventDefault();if(updateLaeuft)return;let f=$('updateDatei').files[0];if(!f||!confirm('Firmware installieren und Heltec neu starten?'))return;updateFortschritt(true,'Übertragung wird vorbereitet …');try{if(!token)await sitzungLaden();let b=new FormData();b.append('datei',f);await updateDateiUebertragen(b);}catch(e){updateFehler(e)}};
$('updateQuelle').onclick=async()=>{if(updateLaeuft)return;updateFortschritt(true,pc?'Suche nach Updates …':'Update-Server wird gespeichert …');try{if(pc){bridge.updatePruefen($('updateUrl').value);return;}await updateAnfrage('/api/update/quelle',new URLSearchParams({url:$('updateUrl').value,ca:$('updateCa').value}));}catch(e){updateFehler(e)}};
if(pc){$('updateDateiForm').classList.add('hidden');$('caGruppe').classList.add('hidden');}else{$('updateDateiPc').classList.add('hidden');}

</script><script id="ueberwachung">
// Ereignisse vom Gerät; Messvergleich lokal im geöffneten Browser/PC.
const monitoringKnopf=document.createElement('button');monitoringKnopf.dataset.tab='ueberwachung';monitoringKnopf.textContent='◇ Überwachung';
document.querySelector('nav .tabs').append(monitoringKnopf);
const monitoring=document.createElement('section');monitoring.id='ueberwachung';monitoring.className='section';
monitoring.innerHTML=`<div class="card"><div class="row spread"><h2>Ereignisse</h2><div class="row"><button id="ereignisseNeu">Aktualisieren</button><button id="ereignisseExport">CSV exportieren</button></div></div><p id="ereignisseStatus" class="statusline">Noch nicht geladen</p><div class="scroll"><table><thead><tr><th>Zeit</th><th>Zähler</th><th>Ereignis</th><th>Dauer</th></tr></thead><tbody id="ereignisseTabelle"></tbody></table></div></div>
<div class="card below"><h2>Messwerte vergleichen</h2><p class="statusline">Zähler in der Übersicht auswählen. Während der Messung nur eine bekannte Wassermenge entnehmen.</p><div class="row"><button id="vergleichStart">1. Startwert übernehmen</button><button id="vergleichEnde" disabled>2. Entnahme beendet</button><button id="vergleichAbbrechen">Abbrechen</button></div><p id="vergleichStatus" class="statusline">Noch keine Messung</p><form id="vergleichForm" class="form"><label>Entnommene Menge (Liter)<input id="vergleichLiter" type="number" min="0.001" step="any" value="10" required></label><label>Abgelesener Endstand am Zähler (m³, optional)<input id="vergleichDisplay" type="number" min="0" step="any"></label><button>3. Vergleich berechnen</button></form><pre id="vergleichErgebnis" class="hidden"></pre></div>
<div class="card below"><h2>Handy-Mitteilungen</h2><div id="pushPc" class="hidden"><button id="pushWeb">Am Gerät einrichten</button></div><div id="pushWebForm"><button id="pushLaden">Einstellungen laden</button><form id="pushForm" class="form below"><label><span><input id="pushAktiv" type="checkbox"> Aktiv</span></label><label>ntfy-Server<input id="pushServer" type="url" value="https://ntfy.sh" required></label><label>Thema<input id="pushThema" pattern="[A-Za-z0-9_-]+" maxlength="64"></label><label>Zugriffstoken (optional)<input id="pushToken" type="password" autocomplete="new-password" maxlength="256"></label><label><span><input id="pushLoeschen" type="checkbox"> Gespeicherten Token entfernen</span></label><button>Speichern</button></form><button id="pushTest" class="below">Testnachricht senden</button></div><p id="pushStatus" class="statusline">Ausgeschaltet</p></div>`;
document.querySelector('main').append(monitoring);
let ereignisDaten=[],ereignisLaedt=false,ereignisStand=null,vergleich=null,letzterBoot=null;
const vorherMonitoringZeigen=zeigen;
zeigen=function(tab){vorherMonitoringZeigen(tab);if(tab==='ueberwachung'){$('seitentitel').textContent='Überwachung';ereignisseLaden();}};
monitoringKnopf.onclick=()=>zeigen('ueberwachung');
function ereignisseLesen(text){
  ereignisDaten=[];let defekt=0;
  for(const z of text.split('\n')){if(!z.trim())continue;try{const e=JSON.parse(z);if(typeof e.art!=='string'||typeof e.text!=='string')throw Error();ereignisDaten.push(e);}catch(e){defekt++;}}
  $('ereignisseTabelle').replaceChildren();
  for(const e of ereignisDaten.slice(-300).reverse()){
    const zeit=e.zeit?new Date(e.zeit*1000).toLocaleString('de-DE'):'Start '+e.boot+' · '+e.laufzeit_s+' s';
    zeile($('ereignisseTabelle'),[zeit,e.name||e.id||'Gerät',e.text,e.art==='neustart'?'—':e.dauer_s+' s']);
  }
  $('ereignisseStatus').textContent=ereignisDaten.length+' Einträge'+(defekt?' · '+defekt+' beschädigte Zeilen übersprungen':'');
}
async function ereignisseLaden(){
  if(ereignisLaedt)return;ereignisLaedt=true;
  try{if(pc){if(bridge)bridge.ereignisseLaden($('adresse').value);return;}
    const r=await fetch('/api/ereignisse',{cache:'no-store',signal:AbortSignal.timeout(30000)});if(!r.ok)throw Error('Ereignisse nicht erreichbar');ereignisseLesen(await r.text());
  }catch(e){$('ereignisseStatus').textContent=e.message;}finally{ereignisLaedt=false;}
}
const vorherMonitoringEreignis=ereignis;
ereignis=function(raw){let e=typeof raw==='string'?JSON.parse(raw):raw;if(e.typ==='ereignisse'){ereignisseLesen(e.text);return;}vorherMonitoringEreignis(raw);};
$('ereignisseNeu').onclick=ereignisseLaden;
$('ereignisseExport').onclick=()=>{
  const esc=x=>'"'+String(x??'').replaceAll('"','""')+'"';
  const text='Zeit;Startkennung;Laufzeit_s;Kennung;Name;Art;Phase;Vorgang;Dauer_s;Text\r\n'+ereignisDaten.map(e=>[e.zeit?new Date(e.zeit*1000).toISOString():'',e.boot,e.laufzeit_s,e.id,e.name,e.art,e.phase,e.vorgang,e.dauer_s,e.text].map(esc).join(';')).join('\r\n');
  if(pc){bridge.verlaufExportieren(text);return;}let u=URL.createObjectURL(new Blob(['\ufeff'+text],{type:'text/csv;charset=utf-8'})),a=document.createElement('a');a.href=u;a.download='hydrus-ereignisse.csv';a.click();setTimeout(()=>URL.revokeObjectURL(u),1000);
};
function vergleichVerwerfen(text){vergleich=null;$('vergleichEnde').disabled=true;$('vergleichStatus').textContent=text;}
function aktuellerVergleichswert(){
  const o=zaehler.get(wahl),v=feldwert(o?.felder||[],['Volumen']);
  if(!online||!o||!v||Date.now()-o.zeit>120000)throw Error('Aktuellen entschlüsselten Zählerstand abwarten');
  return {id:wahl,stand:Number(v.wert),seq:o.seq,zeit:o.zeit,boot:letzterBoot};
}
$('vergleichStart').onclick=()=>{try{vergleich={start:aktuellerVergleichswert(),wartet:false};$('vergleichEnde').disabled=false;$('vergleichErgebnis').classList.add('hidden');$('vergleichStatus').textContent='Start: '+vergleich.start.stand.toLocaleString('de-DE')+' m³ · jetzt bekannte Menge entnehmen';}catch(e){melden(e.message)}};
$('vergleichEnde').onclick=()=>{try{if(!vergleich)throw Error('Zuerst Startwert übernehmen');const aktuell=aktuellerVergleichswert();if(aktuell.id!==vergleich.start.id)throw Error('Zähler gewechselt');vergleich.wartet=true;vergleich.nachSeq=aktuell.seq;$('vergleichEnde').disabled=true;$('vergleichStatus').textContent='Warte auf das nächste Telegramm nach der Entnahme …';}catch(e){vergleichVerwerfen(e.message)}};
$('vergleichAbbrechen').onclick=()=>vergleichVerwerfen('Messung abgebrochen');
function vergleichBerechnen(start,ende,liter,display=null){
  if(!Number.isFinite(liter)||liter<=0||!Number.isFinite(start.stand)||!Number.isFinite(ende.stand)||ende.stand<start.stand||start.id!==ende.id)throw Error('Messwerte oder Menge ungültig');
  const gemessen=(ende.stand-start.stand)*1000,abweichung=gemessen-liter;
  return {kennung:start.id,start_m3:start.stand,ende_m3:ende.stand,soll_l:liter,gemessen_l:gemessen,abweichung_l:abweichung,abweichung_prozent:100*abweichung/liter,display_abweichung_l:display===null?null:(ende.stand-display)*1000};
}
$('vergleichForm').onsubmit=e=>{e.preventDefault();try{
  if(!vergleich?.ende)throw Error('Zuerst Entnahme beenden und neues Telegramm abwarten');
  const display=$('vergleichDisplay').value===''?null:Number($('vergleichDisplay').value);
  let r=vergleichBerechnen(vergleich.start,vergleich.ende,Number($('vergleichLiter').value),display);
  if(display!==null&&!Number.isFinite(display))throw Error('Displaywert ungültig');
  const f=x=>x.toLocaleString('de-DE',{maximumFractionDigits:3});
  $('vergleichErgebnis').textContent='Zähler '+r.kennung+'\nEntnommen: '+f(r.soll_l)+' l\nPer Funk erfasst: '+f(r.gemessen_l)+' l\nAbweichung: '+f(r.abweichung_l)+' l ('+f(r.abweichung_prozent)+' %)'+(r.display_abweichung_l===null?'':'\nAbweichung zum Display: '+f(r.display_abweichung_l)+' l')+'\nDie Auflösung und das Sendeintervall beeinflussen den Vergleich. Keine automatische Änderung der Messwerte.';
  $('vergleichErgebnis').classList.remove('hidden');localStorage.setItem('hydrus-letzter-vergleich',JSON.stringify({erstellt:new Date().toISOString(),...r,text:$('vergleichErgebnis').textContent}));
}catch(err){melden(err.message)}};
try{const alt=JSON.parse(localStorage.getItem('hydrus-letzter-vergleich'));if(alt?.text){$('vergleichErgebnis').textContent='Letzter Vergleich · '+new Date(alt.erstellt).toLocaleString('de-DE')+'\n'+alt.text;$('vergleichErgebnis').classList.remove('hidden');}}catch(e){}
const vorherMonitoringAufnehmen=aufnehmen;
aufnehmen=function(e){vorherMonitoringAufnehmen(e);if(!vergleich||vergleich.ende)return;
  if(Date.now()-vergleich.start.zeit>1200000){vergleichVerwerfen('Messung abgelaufen – neu beginnen');return;}
  if(e.paket.zaehlerkennung!==vergleich.start.id)return;
  if(e.paket.geraetestatus?.empfang_fehlt||e.paket.geraetestatus?.zaehler_ruecksprung){vergleichVerwerfen('Messung durch Empfangsausfall oder Zählerrücksprung unterbrochen');return;}
  if(vergleich.wartet)try{const end=aktuellerVergleichswert();if(end.seq!==vergleich.nachSeq){vergleich.ende=end;vergleich.wartet=false;$('vergleichStatus').textContent='Endwert: '+end.stand.toLocaleString('de-DE')+' m³ · entnommene Menge eintragen';}}catch(e){vergleichVerwerfen(e.message)}
};
const vorherMonitoringVerbindung=verbindung;
verbindung=function(an,text){vorherMonitoringVerbindung(an,text);if(!an&&vergleich&&!vergleich.ende)vergleichVerwerfen('Verbindung unterbrochen – Messung neu beginnen');};
const vorherMonitoringStatus=komfortStatus;
komfortStatus=function(j){vorherMonitoringStatus(j);
  if(letzterBoot!==null&&j.boot!==letzterBoot&&vergleich&&!vergleich.ende)vergleichVerwerfen('Heltec neu gestartet – Messung neu beginnen');letzterBoot=j.boot;
  if(j.ereignisse_fehler)$('ereignisseStatus').textContent=j.ereignisse_fehler;
  if(j.mitteilung_status)$('pushStatus').textContent=j.mitteilung_status;
  if(j.ereignisse_revision!==ereignisStand&&monitoring.classList.contains('active')){ereignisStand=j.ereignisse_revision;ereignisseLaden();}
};
async function pushAnfrage(pfad,body){if(!token)await sitzungLaden();const r=await fetch(pfad,{method:'POST',headers:{'X-Hydrus-Token':token},body,signal:AbortSignal.timeout(10000)});let t=await r.text();if(!r.ok)throw Error(t);$('pushStatus').textContent=t;}
$('pushLaden').onclick=async()=>{try{let r=await fetch('/api/mitteilung',{cache:'no-store'});if(!r.ok)throw Error('Einstellungen nicht erreichbar');let d=await r.json();$('pushAktiv').checked=d.aktiv;$('pushServer').value=d.server;$('pushThema').value=d.thema;$('pushToken').value='';$('pushStatus').textContent=d.meldung+' · '+d.wartend+' vorgemerkt'+(d.token_vorhanden?' · Token gespeichert':'');}catch(e){melden(e.message)}};
$('pushForm').onsubmit=async e=>{e.preventDefault();try{await pushAnfrage('/api/mitteilung',new URLSearchParams({aktiv:$('pushAktiv').checked?'1':'0',server:$('pushServer').value,thema:$('pushThema').value,token:$('pushToken').value,loeschen:$('pushLoeschen').checked?'1':'0'}));$('pushToken').value='';$('pushLoeschen').checked=false;}catch(err){melden(err.message)}};
$('pushTest').onclick=async()=>{try{await pushAnfrage('/api/mitteilung/test',new URLSearchParams());}catch(e){melden(e.message)}};
if(pc){$('pushWebForm').classList.add('hidden');$('pushPc').classList.remove('hidden');$('pushWeb').onclick=()=>bridge.webOeffnen($('adresse').value);}

</script><script id="warnregeln">
// Die Zusammenfassung beschreibt die eingestellten Regeln, keine Verbrauchsprognose.
const warnStil=document.createElement('style');warnStil.textContent=`.warnEinstellung{min-width:0;border:1px solid var(--line);border-radius:14px;padding:18px;margin:6px 0}.warnEinstellung legend{font-weight:650;padding:0 8px}.warnFelder{display:grid;grid-template-columns:1fr 1fr;gap:16px;margin-top:18px}.warnSchalter{display:flex;align-items:center;gap:10px;color:var(--ink)}.warnZusammenfassung{padding:12px;border-radius:10px;background:var(--bg);margin-bottom:0}.warnEinstellung input[type=number]{width:100%}@media(max-width:500px){.warnFelder{grid-template-columns:1fr}}`;
document.head.append(warnStil);
function warnregelText(){
 const aktiv=$('leckAktiv').checked,fluss=$('leckLiter').valueAsNumber,dauer=$('leckDauer').valueAsNumber,empfang=$('empfangDauer').valueAsNumber;
 const n=x=>x.toLocaleString('de-DE',{maximumFractionDigits:3});
 $('leckLiter').disabled=!aktiv;$('leckDauer').disabled=!aktiv;
 $('leckErklaerung').textContent=!aktiv?'Warnung bei längerem Wasserfluss ausgeschaltet.':!Number.isFinite(fluss)||!Number.isFinite(dauer)||fluss<=0||dauer<=0?'Wassermenge und Dauer eingeben.':'Warnung, wenn mindestens '+n(fluss)+' Liter pro Minute für '+n(dauer)+' Minuten durchgehend gemeldet werden. Die Grenze ist kein Aufschlag auf den aktuellen Durchfluss.';
 $('empfangErklaerung').textContent=Number.isFinite(empfang)&&empfang>0?'Warnung, wenn der Heltec '+n(empfang)+' Minuten lang keine neuen Daten dieses Zählers erhält.':'Wartezeit in Minuten eingeben.';
}
for(const id of ['leckAktiv','leckLiter','leckDauer','empfangDauer'])$(id).addEventListener('input',warnregelText);
// Warnregeln unabhängig von den Stammdaten bearbeiten; Statusabfragen erhalten Entwürfe.
let warnGeladen='',warnBeschaeftigt=false;
function warnAuswahl(){
 const s=$('warnZaehler'),alt=s.value,signatur=JSON.stringify(geraeteListe.map(g=>[g.id,g.name]));
 if(s.dataset.liste!==signatur){s.dataset.liste=signatur;s.replaceChildren();for(const g of geraeteListe)s.append(new Option((g.name!==g.id?g.name+' · ':'')+g.id,g.id));s.value=geraeteListe.some(g=>g.id===alt)?alt:geraeteListe[0]?.id||'';}
 if(warnGeladen!==s.value)warnAnzeigen();
 $('warnLeer').classList.toggle('hidden',!!s.value);$('warnInhalt').classList.toggle('hidden',!s.value);
}
function warnAnzeigen(){
 const g=geraeteListe.find(g=>g.id===$('warnZaehler').value);warnGeladen=g?.id||'';
 $('leckLiter').value=g?.leck_l_min??.1;$('leckDauer').value=(g?.leck_sekunden??1800)/60;$('empfangDauer').value=(g?.empfang_sekunden??600)/60;$('leckAktiv').checked=g?.leck_aktiv??true;
 $('warnMeldung').textContent='';warnregelText();
}
$('warnZaehler').onchange=warnAnzeigen;
const auswahlOhneWarnungen=geraeteAuswahl;geraeteAuswahl=function(){auswahlOhneWarnungen();warnAuswahl();};
$('warnForm').onsubmit=async e=>{
 e.preventDefault();if(warnBeschaeftigt||!$('warnZaehler').value)return;
 const id=$('warnZaehler').value,daten={bereich:'warnungen',id,leck_l_min:$('leckLiter').value,leck_sekunden:Number($('leckDauer').value)*60,empfang_sekunden:Number($('empfangDauer').value)*60,leck_aktiv:$('leckAktiv').checked?'1':'0'};
 warnBeschaeftigt=true;$('warnSpeichern').disabled=true;$('warnZaehler').disabled=true;$('warnMeldung').textContent='Wird gespeichert …';
 try{if(!token)await sitzungLaden();const r=await fetch('/api/zaehler',{method:'POST',headers:{'X-Hydrus-Token':token},body:new URLSearchParams(daten),signal:AbortSignal.timeout(15000)});const text=await r.text();if(!r.ok)throw Error(text);
 const g=geraeteListe.find(g=>g.id===id);if(g)Object.assign(g,{leck_l_min:Number(daten.leck_l_min),leck_sekunden:daten.leck_sekunden,empfang_sekunden:daten.empfang_sekunden,leck_aktiv:daten.leck_aktiv==='1'});
 $('warnMeldung').textContent='Einstellungen gespeichert.';
 }catch(err){$('warnMeldung').textContent=err.message;}finally{warnBeschaeftigt=false;$('warnSpeichern').disabled=false;$('warnZaehler').disabled=false;}
};
if(pc){$('warnForm').classList.add('hidden');$('warnWeb').classList.remove('hidden');$('warnWeb').onclick=()=>bridge.webOeffnen($('adresse').value);}
warnAuswahl();warnregelText();

</script><script id="zaehler-details">
// Zusatzwerte stammen ausschliesslich aus dem letzten Paket des gewaehlten Zaehlers.
const zusatzStil=document.createElement('style');zusatzStil.textContent=`.zusatzRaster{grid-template-columns:repeat(4,minmax(0,1fr))}.zusatzRaster strong{font-size:24px;overflow-wrap:anywhere}.zusatzRaster .metric{gap:12px}#geraeteZustand{font-size:18px;hyphens:auto;letter-spacing:0}.zusatzWerte{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:20px}.zusatzWerte small{display:block;color:var(--muted);margin-bottom:6px}.zusatzWerte strong{overflow-wrap:anywhere}.zusatzWarnung{color:var(--warn)}@media(max-width:1100px){.zusatzRaster,.zusatzWerte{grid-template-columns:repeat(2,minmax(0,1fr))}}@media(max-width:400px){.zusatzWerte{grid-template-columns:1fr}}`;
document.head.append(zusatzStil);
function aktuellesZusatzfeld(f){return f.funktion==='Momentanwert'&&f.speicher===0&&f.tarif===0&&f.untereinheit===0;}
function lesbaresZusatzfeld(f){return f.wert!==undefined&&f.wert!==null&&String(f.wert)!=='—'&&(!f.hinweis||f.bezeichnung==='Fehlerflags (Rohbits)');}
function zusatzText(f){const n=Number(f.wert);return (f.einheit==='Hex'||!Number.isFinite(n)?String(f.wert):n.toLocaleString('de-DE',{maximumFractionDigits:6}))+(f.einheit&&f.einheit!=='Hex'?' '+f.einheit:'');}
function zaehlerZusatzdaten(o){
 const f=o?.felder||[],aktuell=f.filter(x=>aktuellesZusatzfeld(x)&&lesbaresZusatzfeld(x));
 const b=feldwert(f,['Batterie-Restlaufzeit']);
 let batterie='—',batterieHinweis='Keine Angabe',status=[],warnung=false;
 if(b&&Number(b.wert)>=0){batterie=zusatzText(b);batterieHinweis=b.einheit==='Tage'?'≈ '+(Number(b.wert)/365.25).toLocaleString('de-DE',{maximumFractionDigits:1})+' Jahre':'';}
 // Standard-Transportstatus: kein Prozentwert und keine herstellerspezifischen Alarmannahmen.
 const s=o?.p.zaehlerstatus,hatStatus=Number.isInteger(s)&&s>=0&&s<=255;
 if(hatStatus){
   if(s&4){status.push('Batteriewarnung');batterieHinweis='Batteriewarnung';warnung=true;}
   if(s&8){status.push('Dauerhafter Fehler');warnung=true;}
   if(s&16){status.push('Vorübergehender Fehler');warnung=true;}
   if(s&3){status.push('Anwendungsstatus '+(s&3));warnung=true;}
   if(s&224){status.push('Herstellerstatus');warnung=true;}
 }
 const flags=aktuell.filter(x=>x.bezeichnung==='Fehlerflags (Rohbits)'&&/^0x[0-9a-f]+$/i.test(x.wert));
 if(flags.some(x=>BigInt(x.wert)!==0n)){status.push('Fehlerflags gesetzt');warnung=true;}
 const statusText=status.length?status.join(' · '):(hatStatus||flags.length?'Keine Fehlermeldung':'Keine Angabe');
 const roh=[...(hatStatus?['Status 0x'+s.toString(16).padStart(2,'0').toUpperCase()]:[]),...flags.map(x=>'Fehlerflags '+x.wert)].join(' · ');
 return {batterie,batterieHinweis,statusText,roh,warnung,
 weitere:aktuell.filter(x=>!['Volumen','Durchfluss','Vorlauftemperatur','Externe Temperatur','Batterie-Restlaufzeit','Fehlerflags (Rohbits)'].includes(x.bezeichnung)),
 register:f.filter(x=>lesbaresZusatzfeld(x)&&!aktuellesZusatzfeld(x))};
}
function zusatzAktualisieren(){
 const o=zaehler.get(wahl),d=zaehlerZusatzdaten(o),f=o?.felder||[];
 $('batterie').textContent=d.batterie;$('batterieHinweis').textContent=d.batterieHinweis;
 const umgebung=feldwert(f,['Externe Temperatur']);wert('umgebung',umgebung?Number(umgebung.wert):null,'°C');
 $('geraeteZustand').textContent=d.statusText;$('geraeteZustand').classList.toggle('zusatzWarnung',d.warnung);$('statusHinweis').textContent=d.roh;
 const alter=o?Math.max(0,Math.floor((Date.now()-o.zeit)/1000)):null;
 $('zusatzAlter').textContent=alter===null?'Noch keine Daten':!online?'Verbindung getrennt':alter>120?'Letztes Telegramm · '+alter+' s alt':'Letztes Telegramm · '+alter+' s';
 $('zusatzAlter').className='badge '+(!online||alter===null||alter>120?'warn':'');
 $('zusatzWerte').replaceChildren();
 for(const x of d.weitere){const box=document.createElement('div'),titel=document.createElement('small'),wert=document.createElement('strong');titel.textContent=x.bezeichnung;wert.textContent=zusatzText(x);box.append(titel,wert);$('zusatzWerte').append(box);}
 $('zusatzLeer').classList.toggle('hidden',!!d.weitere.length);
 $('registerWerte').replaceChildren();
 for(const x of d.register){const teile=[x.funktion];if(x.speicher)teile.push('Speicher '+x.speicher);if(x.tarif)teile.push('Tarif '+x.tarif);if(x.untereinheit)teile.push('Gerät '+x.untereinheit);zeile($('registerWerte'),[x.bezeichnung,zusatzText(x),teile.join(' · ')]);}
 $('registerKarte').classList.toggle('hidden',!d.register.length);
}
zusatzAktualisieren();

</script><script id="navigation">
// Drei Hauptbereiche mit zugehörigen Unterseiten. Bestehende Aktionen und Daten bleiben erhalten.
const navStil=document.createElement('style');navStil.textContent='.bereichTabs{display:flex;flex-wrap:wrap;gap:8px;margin:0 0 20px;justify-content:center}.bereichTabs button.active{background:var(--mint);color:white;border-color:var(--mint)}nav .tabs{display:grid;gap:5px}@media(max-width:700px){nav .tabs{grid-template-columns:repeat(3,minmax(0,1fr))}.bereichTabs{gap:6px}.bereichTabs button{padding:9px 11px;font-size:13px}}';document.head.append(navStil);
function unterseite(id,inhalt){const s=document.createElement('section');s.id=id;s.className='section';for(const el of inhalt)s.append(el);document.querySelector('main').append(s);return s;}
const monitoringKarten=[...$('ueberwachung').children];
unterseite('ereignisse',[monitoringKarten[0]]);unterseite('vergleich',[monitoringKarten[1]]);unterseite('mitteilungen',[monitoringKarten[2]]);
const einstellungenKarten=[...$('einstellungen').children];
unterseite('netzwerk',[einstellungenKarten[3]]);unterseite('sicherungSeite',[einstellungenKarten[1]]);einstellungenKarten[2].remove();
$('einstellungen').id='verwaltung';
const erweitert=unterseite('erweitert',[]);const k=document.createElement('div');k.className='card';k.innerHTML='<h2>Erweiterte Diagnose</h2><div class="row"><button id="diagFunk">Funksuche</button><button id="diagPakete">Funkpakete</button><button id="diagVergleich">Messvergleich</button></div>';erweitert.append(k);
$('diagFunk').onclick=()=>zeigen('diagnose');$('diagPakete').onclick=()=>zeigen('pakete');$('diagVergleich').onclick=()=>zeigen('vergleich');
const gruppen={start:[['start','Messwerte'],['warnungen','Leckwarnung einstellen'],['verwaltung','Zähler verwalten']],historie:[['historie','Messwerte'],['ereignisse','Ereignisse']],einstellungen:[['netzwerk','WLAN'],['mitteilungen','Mitteilungen'],['sicherungSeite','Datensicherung'],['updates','Updates'],['erweitert','Erweiterte Diagnose']]};
const titel={start:'Übersicht',historie:'Verlauf',einstellungen:'Einstellungen'};
// Existierende Hauptknöpfe behalten ihre Listener, überzählige Einträge entfallen.
for(const b of [...document.querySelectorAll('nav [data-tab]')]){if(!gruppen[b.dataset.tab])b.remove();else b.textContent=titel[b.dataset.tab];}
const nav=document.querySelector('nav .tabs');for(const id of ['start','historie','einstellungen'])nav.append(nav.querySelector('[data-tab="'+id+'"]'));
for(const [gruppe,seiten]of Object.entries(gruppen))if(seiten.length>1)for(const[id]of seiten){const leiste=document.createElement('div');leiste.className='bereichTabs';leiste.setAttribute('aria-label',titel[gruppe]);for(const[z,beschriftung]of seiten){const b=document.createElement('button');b.textContent=beschriftung;b.classList.toggle('active',z===id);b.onclick=()=>zeigen(z);leiste.append(b);}$ (id).prepend(leiste);}
const zeigenOhneGruppen=zeigen;
const diagnoseSeiten=['diagnose','pakete','vergleich'];
for(const id of diagnoseSeiten){const b=document.createElement('button');b.textContent='← Erweiterte Diagnose';b.className='below';b.onclick=()=>zeigen('erweitert');$(id).prepend(b);}
zeigen=function(tab){
 if(tab==='ueberwachung')tab='ereignisse';if(tab==='einstellungen')tab='netzwerk';
 zeigenOhneGruppen(tab);
 const gruppe=diagnoseSeiten.includes(tab)?'einstellungen':Object.keys(gruppen).find(g=>gruppen[g].some(([id])=>id===tab))||'start';
 $('seitentitel').textContent=titel[gruppe];for(const b of document.querySelectorAll('nav [data-tab]'))b.classList.toggle('active',b.dataset.tab===gruppe);
 if(tab==='ereignisse')ereignisseLaden();
 if(tab==='warnungen'){warnAuswahl();if(geraeteListe.some(g=>g.id===wahl)&&$('warnZaehler').value!==wahl){$('warnZaehler').value=wahl;warnAnzeigen();}}
 if(tab==='netzwerk'&&!wlanSchonGesucht)wlanSuchen();
};
// Die Warnseite und die Messwertübersicht verwenden denselben ausgewählten Zähler.
$('warnZaehler').addEventListener('change',()=>{wahl=$('warnZaehler').value;localStorage.setItem('hydrus-kennung',wahl);auswahl();aktualisieren();});
const warnLink=document.createElement('button');warnLink.type='button';warnLink.textContent='Leckwarnung einstellen';warnLink.onclick=()=>{warnAuswahl();const id=$('geraetAuswahl').value;if(id){wahl=id;auswahl();$('warnZaehler').value=id;warnAnzeigen();}zeigen('warnungen');};$('geraeteForm').append(warnLink);
zeigen('start');

</script><script id="animationen">
// Warnungen bleiben auf jeder Seite sichtbar, auch für andere gespeicherte Zähler.
const bewegungStil=document.createElement('style');bewegungStil.textContent=`
.leckKarten{display:grid;gap:12px;margin-bottom:20px}.leckKarte{border:1px solid #efb4a7;border-left:5px solid #bb4932;background:#fff3ee;color:#6d291d;border-radius:16px;padding:20px}.leckKarte h2{color:#8e3222;margin:0}.leckKopf{display:flex;gap:12px;align-items:center}.leckSymbol{font-size:24px}.leckKarte p{margin:10px 0}.leckZahlen{display:flex;gap:24px;flex-wrap:wrap;margin:14px 0}.leckZahlen strong{display:block;font-size:22px}.leckZahlen small{font-size:12px}.leckKarte button{background:#fff8f5;color:#782b20;border-color:#e4b9ae}.leckKarte[data-alt=true]{border-color:#d7bf85;background:#fff7e5;color:#72551a}.srNur{position:absolute;width:1px;height:1px;overflow:hidden;clip-path:inset(50%)}
button{transition:background-color .18s,border-color .18s,box-shadow .18s}button:active:not(:disabled){transform:translateY(1px)}input:focus-visible,select:focus-visible,button:focus-visible{outline:3px solid #51b9ab;outline-offset:3px}.section.active{animation:ansichtEin .22s ease-out}.badge{transition:background-color .25s,color .25s}.leckSymbol{animation:warnAtmen 1.8s ease-in-out 3}
@keyframes ansichtEin{from{opacity:0;transform:translateY(7px)}to{opacity:1;transform:none}}@keyframes warnAtmen{50%{transform:scale(1.12)}}
@media(prefers-reduced-motion:reduce){*,*::before,*::after{animation:none!important;transition:none!important}button:active:not(:disabled){transform:none}}
`;document.head.append(bewegungStil);
const leckBereich=document.createElement('div');leckBereich.id='leckKarten';leckBereich.className='leckKarten hidden';document.querySelector('main header').after(leckBereich);
const leckAnsage=document.createElement('div');leckAnsage.className='srNur';leckAnsage.setAttribute('role','alert');document.body.append(leckAnsage);
const leckAnsichten=new Map();let leckSignatur='';
function leckAktualisieren(){
 const vorhanden=new Set(),meldungen=[];const zahl=x=>Number.isFinite(x)?x.toLocaleString('de-DE',{maximumFractionDigits:2}):'—';
 for(const [id,a]of geraeteStatus){
  if(!a.leckverdacht)continue;vorhanden.add(id);const g=geraeteListe.find(g=>g.id===id),name=g?.name||a.name||id;
  const alter=Number(a.alter_s||0)+Math.max(0,(Date.now()-a.empfangen)/1000),alt=!online||a.empfang_fehlt||alter>(g?.empfang_sekunden||a.empfang_sekunden||600);
  let v=leckAnsichten.get(id);if(!v){const el=document.createElement('article');el.className='leckKarte';el.innerHTML='<div class="leckKopf"><span class="leckSymbol" aria-hidden="true">⚠</span><h2>Leckverdacht</h2></div><p class="leckName"></p><div class="leckZahlen"><div><strong class="leckFluss"></strong><small>Zuletzt gemeldeter Durchfluss</small></div><div><strong class="leckZeit"></strong><small>Gemeldeter Dauerverbrauch</small></div></div><p class="leckHinweis"></p><div class="row"><button class="leckAnsehen">Zähler ansehen</button><button class="leckRegeln">Warneinstellungen öffnen</button></div>';leckBereich.append(el);v={el};leckAnsichten.set(id,v);
   const oeffnen=tab=>{wahl=id;localStorage.setItem('hydrus-kennung',id);auswahl();aktualisieren();zeigen(tab);};el.querySelector('.leckAnsehen').onclick=()=>oeffnen('start');el.querySelector('.leckRegeln').onclick=()=>oeffnen('warnungen');
  }
  const text=(klasse,t)=>{const e=v.el.querySelector(klasse);if(e.textContent!==t)e.textContent=t;};v.el.dataset.alt=String(alt);
  text('h2',alt?'Leckverdacht · Status nicht aktuell':'Leckverdacht');text('.leckName',name===id?id:name+' · '+id);
  text('.leckFluss',Number.isFinite(a.durchfluss_l_min)?zahl(a.durchfluss_l_min)+' l/min':'Nicht verfügbar');
  text('.leckZeit',Number.isFinite(a.leck_seit_s)?zahl(a.leck_seit_s/60)+' min':'Nicht verfügbar');
  text('.leckHinweis',alt?'Letzter bekannter Zustand. Verbindung und Zählerempfang prüfen.':'Es fließt länger Wasser als eingestellt. Bitte Wasserhähne, Toiletten und Leitungen prüfen.');
  meldungen.push(id+':'+alt);
 }
 for(const[id,v]of leckAnsichten)if(!vorhanden.has(id)){v.el.remove();leckAnsichten.delete(id);}
 leckBereich.classList.toggle('hidden',!vorhanden.size);const signatur=meldungen.sort().join('|');if(signatur!==leckSignatur){leckAnsage.textContent=vorhanden.size?'Leckverdacht bei '+vorhanden.size+' Zähler'+(vorhanden.size===1?'':'n')+'. Bitte prüfen.':leckSignatur?'Keine aktive Leckwarnung mehr.':'';leckSignatur=signatur;}
}
const komfortOhneLeckkarte=komfortAktualisieren;komfortAktualisieren=function(){komfortOhneLeckkarte();leckAktualisieren();};
setInterval(leckAktualisieren,1000);
// Nur tatsächlich geänderte Messwerte kurz hervorheben, keine erfundenen Zwischenwerte.
const reduzierteBewegung=matchMedia('(prefers-reduced-motion: reduce)');
for(const el of document.querySelectorAll('.metric strong')){let letzter=el.textContent;new MutationObserver(()=>{const neu=el.textContent;if(neu===letzter)return;letzter=neu;if(!reduzierteBewegung.matches){for(const a of el.getAnimations())a.cancel();el.animate([{opacity:.55,transform:'translateY(3px)'},{opacity:1,transform:'none'}],{duration:260,easing:'ease-out'});}}).observe(el,{childList:true,characterData:true,subtree:true});}
leckAktualisieren();

</script><script id="startseite">
// Übersicht: vorhandene Messwerte neu anordnen, ohne Messungen zu schätzen.
const startStil=document.createElement('style');startStil.textContent=`
#start .zaehlerKopf{padding:18px 22px;border:1px solid var(--line);border-radius:16px;background:var(--card);align-items:center}#start .zaehlerKopf label{flex:1;min-width:180px}#start #zaehler{width:100%;max-width:520px;font-weight:600}#start .hauptRaster{display:grid;grid-template-columns:1.1fr 1fr;gap:18px}#start .flussKarte{background:linear-gradient(145deg,#093e45,#116d6b);color:#effffa;display:flex;flex-direction:column;justify-content:center;min-height:275px;padding:30px}#start .flussKarte small{color:#b9e2dd}#start .flussKarte #fluss{font-size:clamp(42px,5vw,64px);color:#fff;letter-spacing:-2px}#start .flussKarte .unit{font-size:19px;letter-spacing:0}#flussZustand{font-size:16px;font-weight:600;margin:14px 0 5px}#flussZeit{color:#c0dedb;font-size:13px}#start .hero{min-height:275px}#start .hero .meter{height:190px}#start .verbrauchKarten{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:14px;margin-top:18px}#start .verbrauchKarten .metric{min-height:125px;gap:12px;padding:22px}#start .verbrauchKarten strong{font-size:27px}#technikDetails>summary{padding:4px 0;min-height:36px}#technikDetails[open]>summary{margin-bottom:20px}.zeitTabs{display:flex;gap:4px;padding:4px;border-radius:12px;background:var(--bg)}.zeitTabs button{border:0;background:transparent;min-height:42px}.zeitTabs button[aria-pressed=true]{background:var(--mint);color:var(--card)}#diagrammAuswahl{min-height:24px;margin-top:12px;font-size:14px;font-weight:600}#verbrauchGrafik{height:230px}#verbrauchGrafik text{fill:var(--muted);font-size:12px}#verbrauchGrafik [role=button]{cursor:pointer}#verbrauchGrafik [role=button]:focus{outline:none;stroke:var(--ink);stroke-width:2}#verbrauchGrafik .diagrammRaster{stroke:var(--line)}#verbrauchGrafik .diagrammBalken{fill:var(--mint)}#verbrauchGrafik .diagrammLuecke{fill:var(--bg);stroke:var(--muted);stroke-dasharray:3 3}#verbrauchGrafik [aria-pressed=true] .diagrammBalken{stroke:var(--ink);stroke-width:2}
@media(max-width:1100px){#start .verbrauchKarten{grid-template-columns:repeat(2,minmax(0,1fr))}}@media(max-width:700px){nav{position:fixed;inset:auto 0 0;width:100%;padding:8px 12px calc(8px + env(safe-area-inset-bottom));z-index:30;box-shadow:0 -4px 20px #102e3620}nav .brand{display:none}nav .tabs{margin:0;grid-template-columns:repeat(3,1fr)}nav button{min-height:48px;font-size:13px}main{padding-bottom:110px}#meldung{bottom:90px}#start .hauptRaster{grid-template-columns:1fr}#start .flussKarte{min-height:225px;padding:24px}#start .hero{min-height:230px}#start .hero .meter{height:165px}#start .verbrauchKarten{gap:10px}#start .verbrauchKarten .metric{padding:16px;min-height:112px}#start .verbrauchKarten strong{font-size:24px}.bereichTabs button{min-height:44px}#start .zaehlerKopf{padding:16px}#verbrauchGrafik{height:210px}.zeitTabs{width:100%;justify-content:space-between}}
`;document.head.append(startStil);
const startKopf=$('zaehler').closest('.row');startKopf.classList.add('zaehlerKopf');const empfangNeu=document.createElement('span');empfangNeu.id='empfangNeu';empfangNeu.className='badge off';startKopf.append(empfangNeu);
const haupt=$('hero').parentElement;haupt.className='hauptRaster';const altesRaster=$('fluss').closest('.metrics'),flussKarte=$('fluss').closest('.card');flussKarte.classList.add('flussKarte');flussKarte.querySelector('small').textContent='DURCHFLUSS';const flussStatus=document.createElement('div');flussStatus.innerHTML='<p id="flussZustand">Warte auf Messwerte</p><span id="flussZeit"></span>';flussKarte.append(flussStatus);haupt.prepend(flussKarte);
const karten=document.createElement('div');karten.className='verbrauchKarten';haupt.after(karten);for(const id of ['heute','monat','volumen'])karten.append($(id).closest('.card'));altesRaster.remove();
const gesternKarte=document.createElement('div');gesternKarte.className='card metric';gesternKarte.innerHTML='<small>GESTERN</small><strong id="gesternWert">— <span class="unit">l</span></strong>';karten.insertBefore(gesternKarte,$('monat').closest('.card'));
// Technische Angaben bleiben erreichbar, beanspruchen aber nicht die Startansicht.
const details=document.createElement('details');details.id='technikDetails';details.className='card below';const summary=document.createElement('summary');summary.textContent='Weitere Messwerte & Funkdetails';details.append(summary);$('start').append(details);details.append($('zaehlerZusatz'),$('auswertung'),$('messwerte').closest('.card'));
const zeitraumTabs=document.createElement('div');zeitraumTabs.className='zeitTabs';zeitraumTabs.setAttribute('aria-label','Verbrauchszeitraum');$('zeitraum').classList.add('hidden');$('zeitraum').after(zeitraumTabs);
for(const [v,t]of [['tag','Tag'],['woche','Woche'],['monat','Monat']]){const b=document.createElement('button');b.textContent=t;b.dataset.zeit=v;b.onclick=()=>{$('zeitraum').value=v;komfortAktualisieren();};zeitraumTabs.append(b);}
const diagrammInfo=document.createElement('p');diagrammInfo.id='diagrammAuswahl';diagrammInfo.textContent='Balken antippen, um den erfassten Verbrauch zu sehen.';$('verbrauchGrafik').after(diagrammInfo);
let diagrammStand='',diagrammGewaehlterIndex=null;
verbrauchZeichnen=function(tage,jetzt){
 const typ=$('zeitraum').value,werte=[],labels=[];for(const b of zeitraumTabs.children)b.setAttribute('aria-pressed',String(b.dataset.zeit===typ));
 if(typ==='tag'){const stunden=perioden(wahl,'stunden'),heute=tagnummer(jetzt);for(let h=Math.floor(jetzt.getTime()/3600000)-25;h<=Math.floor(jetzt.getTime()/3600000);h++){let d=new Date(h*3600000);if(tagnummer(d)!==heute)continue;werte.push(stunden.has(h)?stunden.get(h)*1000:null);labels.push(new Intl.DateTimeFormat('de-DE',{timeZone:'Europe/Berlin',hour:'2-digit',minute:'2-digit'}).format(d));}}
 else{const n=typ==='woche'?7:Number(berlin.format(jetzt).slice(-2));for(let i=n-1;i>=0;i--){const d=kalendertag(jetzt,-i),tag=tagnummer(d);werte.push(tage.has(tag)?tage.get(tag)*1000:null);labels.push(new Intl.DateTimeFormat('de-DE',{timeZone:'Europe/Berlin',day:'2-digit',month:'2-digit'}).format(d));}}
 const svgBreite=Math.max(320,$('verbrauchGrafik').clientWidth||800);const signatur=JSON.stringify([wahl,typ,werte,labels,svgBreite]);if(signatur===diagrammStand)return;diagrammStand=signatur;diagrammGewaehlterIndex=null;
 const svg=$('verbrauchGrafik');svg.setAttribute('viewBox','0 0 '+svgBreite+' 230');svg.replaceChildren();svg.setAttribute('aria-label','Erfasster Wasserverbrauch in Litern');
 const max=Math.max(1,...werte.filter(Number.isFinite)),breite=(svgBreite-80)/Math.max(1,werte.length),ns=svg.namespaceURI;
 function el(tag,attr,text){const e=document.createElementNS(ns,tag);for(const[k,v]of Object.entries(attr))e.setAttribute(k,v);if(text!==undefined)e.textContent=text;return e;}
 for(let i=0;i<=4;i++){const y=185-i*40;svg.append(el('line',{x1:65,y1:y,x2:svgBreite-10,y2:y,class:'diagrammRaster'}),el('text',{x:55,y:y+4,'text-anchor':'end'},(max*i/4).toLocaleString('de-DE',{maximumFractionDigits:1})));}
 svg.append(el('text',{x:65,y:14},'Liter'));
 werte.forEach((v,i)=>{const x=70+i*breite,hoehe=v===null?8:Math.max(2,160*v/max),text=labels[i]+' · '+(v===null?'Keine Daten':(v>0?'Mindestens ':'')+v.toLocaleString('de-DE',{maximumFractionDigits:2})+' Liter');const gruppe=el('g',{role:'button',tabindex:0,'aria-label':text});gruppe.append(el('rect',{x,y:20,width:Math.max(3,breite-3),height:170,fill:'transparent'}));gruppe.append(el('rect',{x,y:185-hoehe,width:Math.max(3,breite-5),height:hoehe,rx:3,class:v===null?'diagrammLuecke':'diagrammBalken'}));gruppe.append(el('title',{},text));const waehlen=()=>{diagrammGewaehlterIndex=i;diagrammInfo.textContent=text;for(const g of svg.querySelectorAll('[role=button]'))g.setAttribute('aria-pressed',String(g===gruppe));};gruppe.onclick=waehlen;gruppe.onkeydown=e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();waehlen();}};svg.append(gruppe);if(i%Math.ceil(werte.length/(svgBreite<500?4:7))===0)svg.append(el('text',{x,y:215},labels[i]));});
 diagrammInfo.textContent=werte.some(Number.isFinite)?'Balken antippen · gestrichelte Felder: keine Daten':'Noch keine Verbrauchsdaten.';
};
function startseiteAktualisieren(){
 const o=zaehler.get(wahl),g=geraeteListe.find(g=>g.id===wahl),alter=o?Math.max(0,(Date.now()-o.zeit)/1000):Infinity,frisch=online&&!!o&&alter<=(g?.empfang_sekunden||120),fluss=durchfluss(o?.felder||[]);
 const bekannt=Number.isFinite(fluss);$('flussZustand').textContent=!o?'Warte auf Messwerte':!frisch?'Messwert nicht aktuell':!bekannt?'Durchfluss nicht übermittelt':fluss>0?'Aktuell fließt Wasser':fluss===0?'Kein Wasserfluss':'Rückfluss gemeldet';
 $('flussZeit').textContent=o?'Letzter Empfang: '+new Date(o.zeit).toLocaleTimeString('de-DE',{hour:'2-digit',minute:'2-digit',second:'2-digit'}):'Noch kein Telegramm dieses Zählers';
 $('hero').classList.toggle('running',frisch&&bekannt&&fluss>0);$('empfangNeu').textContent=!online?'Verbindung getrennt':!o?'Warte auf Empfang':!frisch?'Empfang veraltet':'Empfang aktuell';$('empfangNeu').className='badge '+(!frisch?'warn':'');
 const tage=perioden(wahl,'tage'),tag=tagnummer(kalendertag(new Date(),-1));verbrauchWert('gesternWert',tage.has(tag)?tage.get(tag)*1000:null,'l');
}
const zusatzOhneStartseite=zusatzAktualisieren;zusatzAktualisieren=function(){zusatzOhneStartseite();startseiteAktualisieren();};
const komfortOhneStartseite=komfortAktualisieren;komfortAktualisieren=function(){komfortOhneStartseite();startseiteAktualisieren();};
$('zeitraum').onchange=komfortAktualisieren;komfortAktualisieren();

</script><script id="zaehler-loeschen">
// Löschen betrifft die gespeicherte Einrichtung. Archivierte Messwerte bleiben erhalten.
const loeschKnopf=document.createElement('button');loeschKnopf.id='geraetLoeschen';loeschKnopf.type='button';loeschKnopf.textContent='Zähler löschen';loeschKnopf.style.color='#a53727';$('geraeteForm').append(loeschKnopf);
const loeschDialog=document.createElement('dialog');loeschDialog.id='loeschDialog';loeschDialog.style.cssText='border:1px solid var(--line);border-radius:18px;padding:24px;max-width:440px;width:calc(100% - 32px);background:var(--card);color:var(--ink)';loeschDialog.innerHTML='<h2>Zähler löschen?</h2><p id="loeschName"></p><p>Name, Schlüssel und Warneinstellungen werden entfernt. Gespeicherte Messwerte und Ereignisse bleiben im Verlauf erhalten.</p><div class="row"><button id="loeschAbbrechen" autofocus>Abbrechen</button><button id="loeschBestaetigen">Zähler löschen</button></div><p id="loeschStatus" role="status"></p>';document.body.append(loeschDialog);loeschDialog.setAttribute('aria-labelledby','loeschName');
let loeschId='',loeschLaeuft=false;
loeschKnopf.onclick=()=>{if(geraetSpeichert)return;const g=geraeteListe.find(g=>g.id===$('geraetAuswahl').value);if(!g)return;loeschId=g.id;$('loeschName').textContent=(g.name!==g.id?g.name+' · ':'')+g.id;$('loeschStatus').textContent='';loeschDialog.showModal();};
$('loeschAbbrechen').onclick=()=>loeschDialog.close();loeschDialog.addEventListener('cancel',e=>{if(loeschLaeuft)e.preventDefault();});
$('loeschBestaetigen').onclick=async()=>{
 if(loeschLaeuft||!loeschId)return;loeschLaeuft=true;geraetSpeichert=true;$('loeschBestaetigen').disabled=true;$('loeschAbbrechen').disabled=true;$('loeschStatus').textContent='Wird gelöscht …';
 const id=loeschId;
 try{if(!token)await sitzungLaden();const r=await fetch('/api/zaehler/loeschen',{method:'POST',headers:{'X-Hydrus-Token':token},body:new URLSearchParams({id}),signal:AbortSignal.timeout(15000)});const text=await r.text();if(!r.ok)throw Error(text);
 geraeteKonfigGeladen=true;geraeteListe=geraeteListe.filter(g=>g.id!==id);geraeteStatus.delete(id);zaehler.delete(id);
 if(wahl===id){wahl=geraeteListe[0]?.id||'';localStorage.setItem('hydrus-kennung',wahl);}
 geraetNeu=!geraeteListe.length;geraeteAuswahl();$('geraetAuswahl').value=geraeteListe[0]?.id||'';geraetAnzeigen();warnAuswahl();auswahl();aktualisieren();loeschDialog.close();$('geraetMeldung').textContent='Zähler gelöscht.';
 }catch(e){$('loeschStatus').textContent=e.message;}finally{loeschLaeuft=false;geraetSpeichert=false;$('loeschBestaetigen').disabled=false;$('loeschAbbrechen').disabled=false;$('geraetHinzufuegen').disabled=geraeteListe.length>=8;}
};
// Statusabfragen können Löschungen von einem anderen Handy enthalten.
const statusVorLoeschen=komfortStatus;komfortStatus=function(j){if(j.zaehler){const ids=new Set(j.zaehler.map(g=>g.id));for(const id of geraeteStatus.keys())if(!ids.has(id))geraeteStatus.delete(id);}statusVorLoeschen(j);};
loeschKnopf.classList.toggle('hidden',!geraeteListe.some(g=>g.id===$('geraetAuswahl').value));

</script></body></html>
)HYDRUSWEB";
