#pragma once
// Lokales Handy-Dashboard und persistente Heimnetz-Einrichtung. Keine Cloud.
#include <Arduino.h>
#include <WiFi.h>
#include <WebServer.h>
#include <Preferences.h>
#include <ESPmDNS.h>
#include "WlanZugang.h"
#include "AccesspointZugang.h"
#include "WebAnsicht.h"
#include "VerlaufSpeicher.h"
#include "Verbrauch.h"
#include "FirmwareUpdate.h"
#include "EreignisVerlauf.h"
#include "HandyMitteilung.h"

class WebPortal {
 public:
  bool (*befehl)(const String &) = nullptr;
  bool bereit = false;
  String adresse() { return WiFi.status() == WL_CONNECTED ? WiFi.localIP().toString() : WiFi.softAPIP().toString(); }
  void starten() {
    Geraete.starten(); Auswertung.starten(); updates.starten();
    verlauf.zulaessig=[](const String &id){return Geraete.finden(id)>=0;};
    verlauf.starten();
    ereignisse.starten();Handy.starten();
    ereignisse.nachricht=[](const String &text){Handy.merken(text);};
    WiFi.persistent(false);
    WiFi.mode(WIFI_AP_STA);
    WiFi.setHostname("heltec-wasser");
    WiFi.softAPConfig(IPAddress(192,168,4,1), IPAddress(192,168,4,1), IPAddress(255,255,255,0));
    const String apPasswort=apZugang.laden();
    bereit = WiFi.softAP(WLAN_NAME, apPasswort.c_str(), 1, false, 4);
    speicher.begin("hydrus-netz", false);
    // Zugangsdaten als ein NVS-Blob: keine halb gespeicherte SSID/Passwort-Kombination.
    if (speicher.getBytesLength("zugang") == sizeof(zugang)) speicher.getBytes("zugang", &zugang, sizeof(zugang));
    zugang.ssid[32] = 0; zugang.passwort[64] = 0;
    verbinden();
    configTzTime("CET-1CEST,M3.5.0,M10.5.0/3", "pool.ntp.org", "time.google.com");
    char zufall[17]; snprintf(zufall, sizeof(zufall), "%08lx%08lx", (unsigned long)esp_random(), (unsigned long)esp_random());
    token = zufall;
    const char *header[] = {"X-Hydrus-Token"}; http.collectHeaders(header, 1);
    http.on("/", HTTP_GET, [this]() { http.sendHeader("Cache-Control", "no-store"); http.send_P(200, "text/html; charset=utf-8", WEB_ANSICHT); });
    http.on("/api/verlauf", HTTP_GET, [this]() { verlauf.senden(http); });
    http.on("/api/speicher", HTTP_POST, [this]() {
      if(!schreibenErlaubt()) return;
      if(http.arg("bestaetigung")!="INITIALISIEREN") { http.send(400,"text/plain","Bestaetigung fehlt"); return; }
      if(verlauf.bereit) { http.send(409,"text/plain","Speicher bereits eingerichtet"); return; }
      const bool ok=verlauf.initialisieren(); http.send(ok?200:500,"text/plain",ok?"Speicher bereit":verlauf.fehler);
    });
    http.on("/api/statistik", HTTP_GET, [this](){Auswertung.senden(http);});
    http.on("/api/ereignisse", HTTP_GET, [this](){ereignisse.senden(http);});
    http.on("/api/mitteilung", HTTP_GET, [this](){
      JsonDocument d;Handy.json(d.to<JsonObject>());String s;serializeJson(d,s);http.sendHeader("Cache-Control","no-store");http.send(200,"application/json",s);
    });
    http.on("/api/mitteilung", HTTP_POST, [this](){
      if(!schreibenErlaubt())return;
      bool ok=Handy.einstellen(http.arg("aktiv")=="1",http.arg("server"),http.arg("thema"),http.arg("token"),http.arg("loeschen")=="1");
      http.send(ok?200:400,"text/plain; charset=utf-8",ok?"Gespeichert":"Server, Thema oder Token ungültig");
    });
    http.on("/api/mitteilung/test", HTTP_POST, [this](){
      if(!schreibenErlaubt())return;bool ok=Handy.merken("Testnachricht vom HYDRUS-Wassermonitor");
      http.send(ok?200:409,"text/plain; charset=utf-8",ok?"Testnachricht vorgemerkt":"Benachrichtigungen ausgeschaltet oder Warteschlange voll");
    });
    http.on("/api/konfiguration", HTTP_GET, [this](){
      JsonDocument d;d["schema"]=1;Geraete.json(d["zaehler"].to<JsonArray>());String s;serializeJson(d,s);http.sendHeader("Cache-Control","no-store");http.send(200,"application/json",s);
    });
    http.on("/api/zaehler/loeschen",HTTP_POST,[this](){
      if(!schreibenErlaubt())return;
      String id=http.arg("id");id.toUpperCase();const int i=Geraete.finden(id);
      if(i<0){http.send(404,"text/plain; charset=utf-8","Zähler nicht gefunden");return;}
      const bool ok=Geraete.loeschen(id);if(ok)Auswertung.neuBewerten(i);
      http.send(ok?200:500,"text/plain; charset=utf-8",ok?"Zähler gelöscht":"Speichern fehlgeschlagen");
    });
    http.on("/api/zaehler", HTTP_POST, [this](){
      if(!schreibenErlaubt())return;
      String id=http.arg("id");id.toUpperCase();
      if(http.arg("neu")=="1" && Geraete.finden(id)>=0){http.send(409,"text/plain; charset=utf-8","Zähler ist bereits gespeichert");return;}
      // Getrennte Formulare ändern ausschließlich ihren eigenen Bereich.
      const int index=Geraete.finden(id);const String bereich=http.arg("bereich");
      if(bereich=="stammdaten") {
        const Geraet alt=index>=0?Geraete.geraete[index]:Geraet{};
        const bool ok=Geraete.aendern(id,http.arg("name"),http.arg("schluessel"),http.arg("schluessel_loeschen")=="1",alt.leckLiter,alt.leckSekunden,alt.empfangSekunden,alt.leckAktiv);
        if(ok)Auswertung.neuBewerten(Geraete.finden(id));
        http.send(ok?200:400,"text/plain; charset=utf-8",ok?"Gespeichert":"Eingaben ungültig oder Speicherfehler");return;
      }
      if(bereich=="warnungen" && index<0){http.send(404,"text/plain","Zaehler nicht gefunden");return;}
      String liter=http.arg("leck_l_min"),dauer=http.arg("leck_sekunden"),empfang=http.arg("empfang_sekunden");
      char *e1,*e2,*e3;float l=strtof(liter.c_str(),&e1);unsigned long d=strtoul(dauer.c_str(),&e2,10),e=strtoul(empfang.c_str(),&e3,10);
      bool ok=liter.length()&&dauer.length()&&empfang.length()&&!*e1&&!*e2&&!*e3 &&
        Geraete.aendern(id,bereich=="warnungen"?String(Geraete.geraete[index].name):http.arg("name"),bereich=="warnungen"?String(""):http.arg("schluessel"),bereich!="warnungen" && http.arg("schluessel_loeschen")=="1",l,d,e,http.arg("leck_aktiv")=="1");
      if(ok)Auswertung.neuBewerten(Geraete.finden(id));
      http.send(ok?200:400,"text/plain; charset=utf-8",ok?"Gespeichert":"Eingaben ungültig oder Speicherfehler");
    });
    http.on("/api/update", HTTP_GET, [this](){updateStatus();});
    http.on("/api/update/quelle", HTTP_POST, [this](){if(!schreibenErlaubt())return;bool ok=updates.quelleSetzen(http.arg("url"),http.arg("ca"));http.send(ok?200:400,"text/plain",ok?"Gespeichert":"HTTPS-Adresse und CA-Zertifikat prüfen");});
    http.on("/api/update/pruefen", HTTP_POST, [this](){if(!schreibenErlaubt())return;updates.pruefen();updateStatus();});
    http.on("/api/update/installieren", HTTP_POST, [this](){if(!schreibenErlaubt())return;updates.installieren();updateStatus();});
    http.on("/api/update/datei", HTTP_POST, [this](){if(!schreibenErlaubt())return;updateStatus();}, [this](){
      auto &u=http.upload();
      if(u.status==UPLOAD_FILE_START){uploadErlaubt=http.header("X-Hydrus-Token")==token;if(uploadErlaubt)updates.anfang();}
      if(!uploadErlaubt)return;
      if(u.status==UPLOAD_FILE_WRITE)updates.daten(u.buf,u.currentSize);
      if(u.status==UPLOAD_FILE_END)updates.ende();
      if(u.status==UPLOAD_FILE_ABORTED)updates.abbrechen("Upload abgebrochen");
    });
    http.on("/api/status", HTTP_GET, [this]() { statusSenden(); });
    http.on("/api/einrichtung", HTTP_GET, [this]() {
      http.sendHeader("Cache-Control", "no-store");
      http.send(200, "application/json", "{\"token\":" + zitieren(token) + ",\"ssid\":" + zitieren(zugang.ssid) + "}");
    });
    http.on("/api/accesspoint", HTTP_POST, [this]() {
      if(!schreibenErlaubt())return;
      if(apNeustart || Update.isRunning()) {http.send(409,"text/plain","Vorgang laeuft bereits");return;}
      const String passwort=http.arg("passwort");
      if(!AccesspointZugang::gueltig(passwort)) {http.send(400,"text/plain; charset=utf-8","8 bis 63 Zeichen ohne Umlaute verwenden");return;}
      if(!apZugang.speichern(passwort)) {http.send(500,"text/plain","Passwort konnte nicht gespeichert werden");return;}
      // Erst die Antwort senden, dann neu starten und das gespeicherte Passwort nutzen.
      http.sendHeader("Cache-Control","no-store");
      http.send(200,"text/plain; charset=utf-8","Gespeichert. Heltec startet neu. Mit dem neuen WLAN-Passwort verbinden.");
      apNeustart=millis()+3000;
    });
    http.on("/api/wlan", HTTP_POST, [this]() {
      if (!schreibenErlaubt()) return;
      const String ssid = http.arg("ssid"), passwort = http.arg("passwort");
      if (ssid.length() < 1 || ssid.length() > 32 || passwort.length() < 8 || passwort.length() > 63 ||
          hatNull(ssid) || hatNull(passwort)) {
        http.send(400, "text/plain; charset=utf-8", "SSID: 1–32 Bytes, WPA-Passwort: 8–63 Bytes."); return;
      }
      Zugang neu{}; ssid.toCharArray(neu.ssid, sizeof(neu.ssid)); passwort.toCharArray(neu.passwort, sizeof(neu.passwort));
      if (speicher.putBytes("zugang", &neu, sizeof(neu)) != sizeof(neu)) {
        http.send(500, "text/plain", "Speichern fehlgeschlagen"); return;
      }
      zugang = neu; neuVerbinden = true;
      http.send(200, "text/plain; charset=utf-8", "Gespeichert. Verbinde mit Heimnetz. Der Einrichtungs-Accesspoint bleibt erreichbar.");
    });
    http.on("/api/befehl", HTTP_POST, [this]() {
      if (!schreibenErlaubt()) return;
      if (!befehl || !befehl(http.arg("befehl"))) { http.send(409,"text/plain","Befehl ungueltig oder Empfaenger nicht bereit"); return; }
      http.send(200, "text/plain", "Auftrag angenommen");
    });
    http.on("/api/wlan/suche", HTTP_POST, [this]() {
      if(!schreibenErlaubt())return;
      if(!wlanSucheLaeuft){
        WiFi.scanDelete();wlanSuchErgebnis="";
        // Asynchron: Webserver und separater Zählerempfang bleiben bedienbar.
        int ergebnis=WiFi.scanNetworks(true,false,false,120);
        wlanSucheLaeuft=ergebnis==WIFI_SCAN_RUNNING;wlanSuchStart=millis();
        if(ergebnis==WIFI_SCAN_FAILED)wlanSuchErgebnis="WLAN-Suche konnte nicht gestartet werden";
      }
      wlanSucheSenden();
    });
    http.on("/api/wlan/suche", HTTP_GET, [this]() { wlanSucheSenden(); });
    http.onNotFound([this]() { http.send(404,"text/plain","Nicht gefunden"); });
    http.begin();
    MDNS.begin("heltec-wasser"); MDNS.addService("http", "tcp", 80);
  }
  void pflegen() {
    http.handleClient();
    if(apNeustart && int32_t(millis()-apNeustart)>=0)ESP.restart();
    verlauf.pflegen();
    Auswertung.pflegen(); updates.pflegen();
    if(uint32_t(millis()-letzteWarnpruefung)>=500){
      letzteWarnpruefung=millis();JsonDocument pruefung;Auswertung.json(pruefung.to<JsonArray>());
      ereignisse.pruefen(pruefung.as<JsonArrayConst>(),verlauf.bereit);
    }
    Handy.pflegen();
    if (wlanSucheLaeuft && WiFi.scanComplete()!=WIFI_SCAN_RUNNING)wlanSucheLaeuft=false;
    if (wlanSucheLaeuft && uint32_t(millis()-wlanSuchStart)>20000){wlanSucheLaeuft=false;WiFi.scanDelete();wlanSuchErgebnis="WLAN-Suche abgelaufen";}
    if (neuVerbinden && !wlanSucheLaeuft) { neuVerbinden = false; WiFi.disconnect(false, false); verbinden(); }
    const bool online = WiFi.status() == WL_CONNECTED;
    if (online && !warOnline) Serial.printf("STATUS Heimnetz verbunden. Webseite: http://%s/ ; TCP %u\n", adresse().c_str(), WLAN_DATENPORT);
    warOnline = online;
    if (!online && !wlanSucheLaeuft && zugang.ssid[0] && uint32_t(millis()-letzterVersuch)>30000) verbinden();
  }
  void zeile(const String &text) {
    if (text.startsWith("WMBUS {")) {
      const int stelle = text.indexOf("\"zaehlerkennung\":\"");
      if (stelle < 0) return;
      const int anfang = stelle + strlen("\"zaehlerkennung\":\"");
      const String id = text.substring(anfang, anfang+8);
      if (id.length()!=8) return;
      verlauf.merken(id,text.substring(6));
      size_t ziel=0;
      for (size_t i=0;i<8;++i) {
        if (daten[i].kennung==id) { ziel=i; break; }
        if (!daten[i].json.length()) { ziel=i; break; }
        if (uint32_t(millis()-daten[i].zeit)>uint32_t(millis()-daten[ziel].zeit)) ziel=i;
      }
      if (daten[ziel].kennung!=id) daten[ziel].anzahl=0;
      daten[ziel].kennung=id; daten[ziel].json=text.substring(6);
      daten[ziel].zeit=millis(); daten[ziel].folge=++folge; ++daten[ziel].anzahl;
    } else if (text.startsWith("SCAN {")) {
      // Nur die letzten 71 Messpunkte behalten, keine unbeschraenkte Historie.
      scans[scanIndex++ % 71]=text.substring(5);
    } else if (text.startsWith("FUNKSTATUS ") || text.startsWith("STATUS ") || text.startsWith("FEHLER ") || text.startsWith("FUNKFEHLER ")) {
      status=text.substring(0,512);
    }
  }
 private:
  struct Zugang { char ssid[33] = {}; char passwort[65] = {}; } zugang;
  struct Eintrag { String kennung, json; uint32_t zeit=0, folge=0, anzahl=0; } daten[8];
  WebServer http{80}; Preferences speicher;
  AccesspointZugang apZugang;uint32_t apNeustart=0;
  VerlaufSpeicher verlauf; FirmwareUpdate updates; bool uploadErlaubt=false;
  EreignisVerlauf ereignisse;
  uint32_t letzteWarnpruefung=0;
  void updateStatus(){JsonDocument d;d["version"]=FIRMWARE_VERSION;d["build"]=FIRMWARE_BUILD;d["server"]=updates.server();d["eingerichtet"]=updates.eingerichtet();d["angebot"]=updates.angebot;d["angebot_version"]=updates.angebotVersion;d["meldung"]=updates.meldung;d["fertig"]=updates.fertig;String s;serializeJson(d,s);http.sendHeader("Cache-Control","no-store");http.send(200,"application/json",s);}
  String token, status, scans[71]; uint32_t scanIndex=0, folge=0, letzterVersuch=0;
  bool neuVerbinden=false, warOnline=false;
  bool wlanSucheLaeuft=false;uint32_t wlanSuchStart=0;String wlanSuchErgebnis;
  void wlanSucheSenden(){
    int n=WiFi.scanComplete();JsonDocument d;d["laeuft"]=wlanSucheLaeuft;d["fehler"]=wlanSuchErgebnis;
    if(!wlanSucheLaeuft && n==WIFI_SCAN_FAILED && !wlanSuchErgebnis.length())d["fehler"]="WLAN-Suche fehlgeschlagen";
    JsonArray liste=d["netze"].to<JsonArray>();
    if(!wlanSucheLaeuft)for(int i=0;i<n && i<64;++i){
      String name=WiFi.SSID(i);if(!name.length())continue;
      JsonObject netz=liste.add<JsonObject>();netz["ssid"]=name;netz["rssi"]=WiFi.RSSI(i);netz["offen"]=WiFi.encryptionType(i)==WIFI_AUTH_OPEN;
    }
    String s;serializeJson(d,s);http.sendHeader("Cache-Control","no-store");http.send(200,"application/json",s);
  }
  void verbinden() { letzterVersuch=millis(); if(zugang.ssid[0]) WiFi.begin(zugang.ssid, zugang.passwort); }
  static bool hatNull(const String &s) { for(size_t i=0;i<s.length();++i) if(s[i]==0) return true; return false; }
  // Schreibzugriffe brauchen das Sitzungstoken der lokalen Webseite.
  bool schreibenErlaubt() {
    if (http.header("X-Hydrus-Token") != token) { http.send(403,"text/plain","Seite neu laden"); return false; }
    return true;
  }
  static String zitieren(const String &s) {
    String aus="\"";
    for(size_t i=0;i<s.length();++i) {
      const uint8_t c=s[i];
      if(c=='"'||c=='\\') { aus+='\\'; aus+=char(c); }
      else if(c<32) { char b[7]; snprintf(b,sizeof(b),"\\u%04x",c); aus+=b; }
      else aus+=char(c);
    }
    return aus+'"';
  }
  void statusSenden() {
    http.sendHeader("Cache-Control","no-store");
    http.setContentLength(CONTENT_LENGTH_UNKNOWN); http.send(200,"application/json","");
    http.sendContent("{\"boot\":"+String(verlauf.startkennung)+",\"speicher\":{\"bereit\":"+String(verlauf.bereit?"true":"false")+",\"bytes\":"+String(verlauf.bytes())+",\"fehler\":"+zitieren(verlauf.fehler)+"},\"laufzeit_ms\":"+String(millis())+",\"wlan\":{\"verbunden\":"+
      String(WiFi.status()==WL_CONNECTED?"true":"false")+",\"ssid\":"+zitieren(zugang.ssid)+",\"ip\":"+zitieren(adresse())+
      ",\"ap\":\"192.168.4.1\"},\"status\":"+zitieren(status)+",\"pakete\":[");
    bool komma=false;
    for(auto &p:daten) if(p.json.length()) {
      if(komma) http.sendContent(","); komma=true;
      http.sendContent("{\"seq\":"+String(p.folge)+",\"alter_ms\":"+String(uint32_t(millis()-p.zeit))+
        ",\"anzahl\":"+String(p.anzahl)+",\"paket\":"+p.json+"}");
    }
    http.sendContent("],\"scans\":["); komma=false;
    for(auto &s:scans) if(s.length()) { if(komma) http.sendContent(","); komma=true; http.sendContent(s); }
    JsonDocument zusatz;Geraete.json(zusatz["zaehler"].to<JsonArray>());Auswertung.json(zusatz["analyse"].to<JsonArray>());zusatz["verbrauch_fehler"]=Auswertung.fehler;
    zusatz["ereignisse_revision"]=ereignisse.revision;zusatz["ereignisse_fehler"]=ereignisse.fehler;zusatz["mitteilung_status"]=Handy.meldung;
    String ergaenzung;serializeJson(zusatz,ergaenzung);
    http.sendContent("],"+ergaenzung.substring(1)); http.sendContent("");
  }
};
