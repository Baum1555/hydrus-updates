#pragma once
#include <Arduino.h>
#include <Preferences.h>
#include "WlanZugang.h"

// Das individuelle Passwort liegt im NVS und uebersteht Firmware-Updates.
class AccesspointZugang {
 public:
  static bool gueltig(const String &passwort) {
    if(passwort.length()<8 || passwort.length()>63)return false;
    for(char c:passwort)if((unsigned char)c<32 || (unsigned char)c>126)return false;
    return true;
  }
  String laden() {
    Preferences nvs;
    if(!nvs.begin("hydrus-ap",true))return WLAN_PASSWORT;
    String wert=nvs.getString("passwort");nvs.end();
    return gueltig(wert)?wert:String(WLAN_PASSWORT);
  }
  bool speichern(const String &passwort) {
    if(!gueltig(passwort))return false;
    Preferences nvs;if(!nvs.begin("hydrus-ap",false))return false;
    bool ok=nvs.putString("passwort",passwort)==passwort.length();nvs.end();return ok;
  }
};
