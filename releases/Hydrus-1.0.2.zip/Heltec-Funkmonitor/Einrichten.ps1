﻿# Automatische Einrichtung fuer Windows. Keine Administratorrechte erforderlich.
param([switch]$NurFunktionen)
$ErrorActionPreference = 'Stop'

function Python-Pruefen([string]$Datei, [string[]]$Vorsatz = @()) {
    if (-not $Datei -or $Datei -like '*WindowsApps*') { return $null }
    # 64-Bit-Python pruefen; Qt wird getrennt installiert.
    $probe = 'import sys,struct; assert (3,10) <= sys.version_info[:2] < (3,15) and struct.calcsize(chr(80)) == 8; print(sys.executable)'
    try {
        $ausgabe = & $Datei @Vorsatz -c $probe 2>> $script:Protokoll
        if ($LASTEXITCODE -eq 0 -and $ausgabe) { return [string](@($ausgabe)[-1]) }
    } catch { Add-Content -LiteralPath $script:Protokoll -Value $_ }
    return $null
}

function Python-Suchen {
    $kandidaten = @()
    foreach ($zweig in @('HKCU:\Software\Python\PythonCore', 'HKLM:\Software\Python\PythonCore', 'HKLM:\Software\WOW6432Node\Python\PythonCore')) {
        foreach ($schluessel in @(Get-ChildItem $zweig -ErrorAction SilentlyContinue)) {
            $ort = Get-Item ($schluessel.PSPath + '\InstallPath') -ErrorAction SilentlyContinue
            if ($ort) { $kandidaten += Join-Path ($ort.GetValue('')) 'python.exe' }
        }
    }
    foreach ($befehl in @(Get-Command python.exe -All -ErrorAction SilentlyContinue)) { $kandidaten += $befehl.Source }
    foreach ($kandidat in ($kandidaten | Select-Object -Unique)) {
        if (Test-Path -LiteralPath $kandidat) {
            $gefunden = Python-Pruefen $kandidat
            if ($gefunden) { return $gefunden }
        }
    }
    $starter = Get-Command py.exe -ErrorAction SilentlyContinue
    if ($starter) { return Python-Pruefen $starter.Source @('-3') }
    return $null
}

function Python-Installieren {
    # Festgelegte offizielle Version mit veroeffentlichter SHA-256-Pruefsumme.
    $version = '3.13.15'
    $architektur = $env:PROCESSOR_ARCHITECTURE
    if ($env:PROCESSOR_ARCHITEW6432) { $architektur = $env:PROCESSOR_ARCHITEW6432 }
    switch ($architektur) {
        'ARM64' { $endung = '-arm64'; $soll = 'c252c676087c49e6b94e95a273536b78921c28a5fc9f86d15d25392328247249' }
        'AMD64' { $endung = '-amd64'; $soll = 'edec09c4853aeae9ac36efb8c9f95b6b8e2fee65eee56d9767a8b7c69c574403' }
        'x86' { throw 'Diese Oberflaeche benoetigt 64-Bit-Windows.' }
        default { throw "Nicht unterstuetzte Windows-Architektur: $architektur" }
    }
    $datei = Join-Path $script:Arbeitsordner "python-$version$endung.exe"
    $url = "https://www.python.org/ftp/python/$version/python-$version$endung.exe"
    Write-Host 'Ein passendes 64-Bit-Python fehlt. Lade den offiziellen Installer ...'
    [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
    Invoke-WebRequest -UseBasicParsing -Uri $url -OutFile $datei -TimeoutSec 180
    if ((Get-FileHash -LiteralPath $datei -Algorithm SHA256).Hash -ne $soll) {
        throw 'Die Pruefsumme des Python-Downloads stimmt nicht. Installation abgebrochen.'
    }
    $signatur = Get-AuthenticodeSignature -LiteralPath $datei
    if ($signatur.Status -ne 'Valid' -or $signatur.SignerCertificate.Subject -notmatch 'Python Software Foundation') {
        throw 'Die Signatur des Python-Installers konnte nicht bestaetigt werden.'
    }
    Write-Host 'Installiere Python und pip fuer dein Windows-Benutzerkonto ...'
    $installationslog = Join-Path $script:Arbeitsordner 'python-installation.log'
    $argumente = '/quiet InstallAllUsers=0 Include_tcltk=1 Include_pip=1 Include_test=0 Include_launcher=0 PrependPath=0 /log "' + $installationslog + '"'
    $prozess = Start-Process -FilePath $datei -ArgumentList $argumente -WindowStyle Hidden -Wait -PassThru
    if ($prozess.ExitCode -notin @(0, 3010)) { throw "Python-Installation fehlgeschlagen (Code $($prozess.ExitCode)). Details: $installationslog" }
    $python = Python-Suchen
    if (-not $python) {
        throw "Python ist nach der Installation noch nicht nutzbar. Windows ggf. neu starten; Details: $installationslog"
    }
    return $python
}

function Funkmonitor-Starten {
    $script:Arbeitsordner = Join-Path ([Environment]::GetFolderPath('LocalApplicationData')) 'Hydrus-Funkmonitor'
    [void](New-Item -ItemType Directory -Force -Path $script:Arbeitsordner)
    $script:Protokoll = Join-Path $script:Arbeitsordner 'startprotokoll.txt'
    Set-Content -LiteralPath $script:Protokoll -Value "Hydrus-Funkmonitor $(Get-Date)"
    # Fremde Python-Umgebungen beeinflussen diesen Start nicht.
    $env:PYTHONHOME = $null
    $env:PYTHONPATH = $null
    $env:TCL_LIBRARY = $null
    $env:TK_LIBRARY = $null
    $env:PYTHONUTF8 = '1'
    $env:PYTHONIOENCODING = 'utf-8'
    foreach ($datei in @('programm_starten.py', 'desktop.py', 'pc_updates.py', 'updatepaket.py', 'update-public.pem', 'empfangsdaten.py', 'dashboard.html', 'funkmonitor.py', 'funkdiagnose.py', 'messwerte.py', 'wlanverbindung.py', 'bibliotheken\serial\__init__.py')) {
        if (-not (Test-Path -LiteralPath (Join-Path $PSScriptRoot $datei))) { throw "Datei fehlt: $datei. Bitte das gesamte ZIP entpacken." }
    }
    Write-Host 'Pruefe Python und die Fensterbibliothek ...'
    $python = Python-Suchen
    if (-not $python) { $python = Python-Installieren }
    # Abhaengigkeiten liegen lokal auf diesem Rechner, niemals in einer kopierten venv.
    $kennung = & $python -c 'import sys; print(sys.version_info.major,sys.version_info.minor,sep=chr(46))'
    $pakete = Join-Path $script:Arbeitsordner ("qt-" + $kennung)
    $env:PYTHONPATH = $pakete
    $ErrorActionPreference = 'Continue'
    & $python -c 'from PySide6.QtWebEngineWidgets import QWebEngineView; from PySide6.QtWebChannel import QWebChannel; import cryptography' 2>> $script:Protokoll
    $qtFehlt = $LASTEXITCODE -ne 0
    $ErrorActionPreference = 'Stop'
    if ($qtFehlt) {
        Write-Host 'Installiere PySide6 und Qt. Beim ersten Start werden etwa 250 MB heruntergeladen ...'
        $ErrorActionPreference = 'Continue'
        & $python -m ensurepip --upgrade >> $script:Protokoll 2>&1
        & $python -m pip install --disable-pip-version-check --timeout 60 --retries 2 --target $pakete --upgrade 'PySide6>=6.8,<7' 'cryptography>=44,<51' >> $script:Protokoll 2>&1
        $qtFehler = $LASTEXITCODE
        $ErrorActionPreference = 'Stop'
        if ($qtFehler -ne 0) { throw "Qt-Installation fehlgeschlagen. Internet pruefen. Details: $script:Protokoll" }
    }
    Write-Host 'Oeffne den Wassermonitor ...' 
    $ErrorActionPreference = 'Continue'
    & $python -u (Join-Path $PSScriptRoot 'programm_starten.py') >> $script:Protokoll 2>&1
    $startFehler = $LASTEXITCODE
    $ErrorActionPreference = 'Stop'
    if ($startFehler -ne 0) { throw "Programmstart fehlgeschlagen. Details: $script:Protokoll" }
}

if (-not $NurFunktionen) {
    try { Funkmonitor-Starten } catch {
        Write-Host "FEHLER: $_" -ForegroundColor Red
        if ($script:Protokoll) { Add-Content -LiteralPath $script:Protokoll -Value $_; Write-Host "Protokoll: $script:Protokoll" }
        exit 1
    }
}
