# Lokale Reset-Korrektur 1.0.1 · Build 2026092602

Regressionstest bildet den zuvor übersehenen LittleFS-Initialisierungszustand nach: format() vor begin() scheitert, korrigierte Reihenfolge besteht. Fehlerstufen werden getrennt gemeldet; bei Boot-Resetfehler startet der signierte Wiederherstellungs-Webserver. Firmware vollständig gebaut und gelinkt. Noch nicht an Hardware geprüft. Nicht veröffentlicht.

# Prüfstand Version 1.0 · Build 2026092601

- Vollständiger Firmware-Build und Link: Espressif 3.3.12, RadioLib 7.7.1, ArduinoJson 7.4.2; erzeugtes ESP32-S3-Image.
- Tatsächliche Tasten-/OLED-Klassen mit simulierten GPIOs und Zeit: Einzel-/Doppeldruck, 3 Sekunden, 10-Sekunden-Grenze, getrennte Reset-Bestätigung, Ablauf ohne Bestätigung, Prellen, Zeitüberlauf und Warnanzeige.
- Tatsächliche Speicherklassen mit simuliertem NVS/Dateisystem: leerer Start, Übernahme alter AP-Passwörter, AP-Name und Passwort gemeinsam speichern, ungültige Eingaben, Schreibfehler, Reset-Auftrag, Formatierungs-/NVS-Löschfehler und erneute Ausführung, leere Daten nach Reset.
- PySide6-Weboberfläche auf 430 Pixeln: AP-Namen ändern ohne Passwortänderung, Namenslänge in UTF-8-Bytes, Passwortregeln/Wiederholung, Sitzungstoken und Serverfehler.
- Veröffentlichungspakete werden auf Signatur, Prüfsumme, Firmwaregröße, persönliche Zählerkennungen und private Signaturschlüssel geprüft.

Noch offen: echte PRG-Taste, OLED, gleichzeitiger Funkbetrieb, Werksreset mit realem Flash/Stromunterbrechung, OTA auf Hardware und Heimnetz/AP-Wechsel am Gerät. Simulation und Compilerprüfungen ersetzen diese Tests nicht.
