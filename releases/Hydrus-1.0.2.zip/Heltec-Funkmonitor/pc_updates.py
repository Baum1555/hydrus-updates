"""Signierte PC-Updates in einen neuen Ordner installieren; laufende Version bleibt erhalten."""
import json
import shutil
import tempfile
import urllib.request
from pathlib import Path, PurePosixPath
from zipfile import ZipFile
from PySide6.QtCore import QThread, Signal
from updatepaket import manifest_pruefen, paket_pruefen, https_url, BereitsAktuell


class NurHttps(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        https_url(newurl)
        return super().redirect_request(req, fp, code, msg, headers, newurl)


def laden(url, datei=None, grenze=10000, fortschritt=None):
    opener = urllib.request.build_opener(NurHttps())
    with opener.open(https_url(url), timeout=20) as r:
        if r.status != 200:
            raise ValueError('Download fehlgeschlagen')
        try: laenge = int(r.headers.get("Content-Length", 0))
        except (ValueError, TypeError): laenge = 0
        gesamt, teile = 0, []
        while block := r.read(65536):
            gesamt += len(block)
            if gesamt > grenze:
                raise ValueError('Download zu groß')
            if fortschritt:
                fortschritt(min(100, gesamt / laenge * 100) if laenge > 0 else None)
            if datei:
                datei.write(block)
            else:
                teile.append(block)
        return b''.join(teile)


def installieren(paket, public, basis, erwartet=None):
    meta, offset = paket_pruefen(paket, public, 'pc')
    if erwartet is not None and meta != erwartet:
        raise ValueError('Update entspricht nicht der angekündigten Version')
    # Keine Dateien der laufenden Version überschreiben. Rückkehr bleibt möglich.
    ziel = Path(tempfile.mkdtemp(prefix='Hydrus-Update-'+str(meta['build'])+'-', dir=basis)).resolve()
    with tempfile.TemporaryFile() as payload, open(paket,'rb') as f:
        f.seek(offset)
        shutil.copyfileobj(f,payload)
        payload.seek(0)
        with ZipFile(payload) as z:
            if len(z.infolist()) > 5000 or sum(x.file_size for x in z.infolist()) > 100000000:
                raise ValueError('Updatearchiv zu groß')
            for info in z.infolist():
                rel = PurePosixPath(info.filename)
                if rel.is_absolute() or '..' in rel.parts or '\\' in info.filename or ':' in info.filename or (info.external_attr >> 16) & 0o170000 == 0o120000:
                    raise ValueError('Unsicherer Archivpfad')
                if not rel.parts or rel.parts[0] != 'Heltec-Funkmonitor':
                    raise ValueError('Unbekannter Paketaufbau')
                ort = (ziel / info.filename).resolve()
                if not ort.is_relative_to(ziel):
                    raise ValueError('Archivpfad außerhalb des Updateordners')
            z.extractall(ziel)
    app = ziel/'Heltec-Funkmonitor'
    if not (app/'programm_starten.py').is_file() or not (app/'starten.bat').is_file():
        raise ValueError('Programmdateien fehlen')
    return app


class UpdateAufgabe(QThread):
    ergebnis = Signal(dict)
    fortschritt = Signal(dict)

    def __init__(self, aktion, url='', angebot=None, datei=None, parent=None):
        super().__init__(parent)
        self.aktion,self.url,self.angebot,self.datei = aktion,url,angebot,datei

    def phase(self, text, prozent=None):
        self.fortschritt.emit(dict(aktiv=True,text=text,prozent=prozent))

    def run(self):
        try:
            basis = Path(__file__).resolve().parent
            public = (basis/'update-public.pem').read_bytes()
            if self.aktion == 'pruefen':
                meta = manifest_pruefen(laden(self.url), public, 'pc')
                https_url(meta['url'])
                self.ergebnis.emit(dict(typ='angebot',angebot=meta,text='Update verfügbar: '+meta['version']))
            else:
                if self.datei:
                    self.phase("Update wird geprüft und entpackt …")
                    ziel = installieren(self.datei,public,basis.parent)
                else:
                    with tempfile.NamedTemporaryFile(suffix='.hup',delete=False) as f:
                        temporär = Path(f.name)
                        try:
                            self.phase('Download wird gestartet …')
                            laden(self.angebot['url'], f, 50005000, lambda p:self.phase('Update wird heruntergeladen',p))
                            self.phase('Update wird geprüft und entpackt …')
                            f.close()
                            ziel = installieren(temporär,public,basis.parent,self.angebot)
                        finally:
                            f.close()
                            temporär.unlink(missing_ok=True)
                self.ergebnis.emit(dict(typ='installiert',pfad=str(ziel),text='Update geprüft und entpackt'))
        except BereitsAktuell as e:
            self.ergebnis.emit(dict(typ='aktuell',angebot=False,text=str(e)))
        except Exception as e:
            self.ergebnis.emit(dict(typ='fehler',text=str(e) or 'Signaturprüfung fehlgeschlagen'))
