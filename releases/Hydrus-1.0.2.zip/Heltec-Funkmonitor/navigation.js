// Drei Hauptbereiche mit zugehörigen Unterseiten. Bestehende Aktionen und Daten bleiben erhalten.
const navStil=document.createElement('style');navStil.textContent='.bereichTabs{display:flex;flex-wrap:wrap;gap:8px;margin:0 0 20px;justify-content:center}.bereichTabs button.active{background:var(--mint);color:white;border-color:var(--mint)}nav .tabs{display:grid;gap:5px}@media(max-width:700px){nav .tabs{grid-template-columns:repeat(3,minmax(0,1fr))}.bereichTabs{gap:6px}.bereichTabs button{padding:9px 11px;font-size:13px}}';document.head.append(navStil);
function unterseite(id,inhalt){const s=document.createElement('section');s.id=id;s.className='section';for(const el of inhalt)s.append(el);document.querySelector('main').append(s);return s;}
const monitoringKarten=[...$('ueberwachung').children];
unterseite('ereignisse',[monitoringKarten[0]]);unterseite('vergleich',[monitoringKarten[1]]);unterseite('mitteilungen',[monitoringKarten[2]]);
const einstellungenKarten=[...$('einstellungen').children];
unterseite('netzwerk',[einstellungenKarten[3]]);unterseite('sicherungSeite',[einstellungenKarten[1]]);einstellungenKarten[2].remove();
$('einstellungen').id='verwaltung';
const erweitert=unterseite('erweitert',[]);const k=document.createElement('div');k.className='card';k.innerHTML='<h2>Erweiterte Diagnose</h2><div class="row"><button id="diagFunk">Funksuche</button><button id="diagPakete">Funkpakete</button><button id="diagVergleich">Messvergleich</button></div>';erweitert.append(k);
$('diagFunk').onclick=()=>zeigen('diagnose');$('diagPakete').onclick=()=>zeigen('pakete');$('diagVergleich').onclick=()=>zeigen('vergleich');
const gruppen={start:[['start','Messwerte'],['warnungen','Leckwarnung einstellen'],['verwaltung','Zähler verwalten']],historie:[['historie','Messwerte'],['ereignisse','Ereignisse']],einstellungen:[['netzwerk','WLAN'],['mitteilungen','Mitteilungen'],['sicherungSeite','Datensicherung'],['updates','Updates'],['erweitert','Erweiterte Diagnose']]};
const titel={start:'Übersicht',historie:'Verlauf',einstellungen:'Einstellungen'};
// Existierende Hauptknöpfe behalten ihre Listener, überzählige Einträge entfallen.
for(const b of [...document.querySelectorAll('nav [data-tab]')]){if(!gruppen[b.dataset.tab])b.remove();else b.textContent=titel[b.dataset.tab];}
const nav=document.querySelector('nav .tabs');for(const id of ['start','historie','einstellungen'])nav.append(nav.querySelector('[data-tab="'+id+'"]'));
for(const [gruppe,seiten]of Object.entries(gruppen))if(seiten.length>1)for(const[id]of seiten){const leiste=document.createElement('div');leiste.className='bereichTabs';leiste.setAttribute('aria-label',titel[gruppe]);for(const[z,beschriftung]of seiten){const b=document.createElement('button');b.textContent=beschriftung;b.classList.toggle('active',z===id);b.onclick=()=>zeigen(z);leiste.append(b);}$ (id).prepend(leiste);}
const zeigenOhneGruppen=zeigen;
const diagnoseSeiten=['diagnose','pakete','vergleich'];
for(const id of diagnoseSeiten){const b=document.createElement('button');b.textContent='← Erweiterte Diagnose';b.className='below';b.onclick=()=>zeigen('erweitert');$(id).prepend(b);}
zeigen=function(tab){
 if(tab==='ueberwachung')tab='ereignisse';if(tab==='einstellungen')tab='netzwerk';
 zeigenOhneGruppen(tab);
 const gruppe=diagnoseSeiten.includes(tab)?'einstellungen':Object.keys(gruppen).find(g=>gruppen[g].some(([id])=>id===tab))||'start';
 $('seitentitel').textContent=titel[gruppe];for(const b of document.querySelectorAll('nav [data-tab]'))b.classList.toggle('active',b.dataset.tab===gruppe);
 if(tab==='ereignisse')ereignisseLaden();
 if(tab==='warnungen'){warnAuswahl();if(geraeteListe.some(g=>g.id===wahl)&&$('warnZaehler').value!==wahl){$('warnZaehler').value=wahl;warnAnzeigen();}}
 if(tab==='netzwerk'&&!wlanSchonGesucht)wlanSuchen();
};
// Die Warnseite und die Messwertübersicht verwenden denselben ausgewählten Zähler.
$('warnZaehler').addEventListener('change',()=>{wahl=$('warnZaehler').value;localStorage.setItem('hydrus-kennung',wahl);auswahl();aktualisieren();});
const warnLink=document.createElement('button');warnLink.type='button';warnLink.textContent='Leckwarnung einstellen';warnLink.onclick=()=>{warnAuswahl();const id=$('geraetAuswahl').value;if(id){wahl=id;auswahl();$('warnZaehler').value=id;warnAnzeigen();}zeigen('warnungen');};$('geraeteForm').append(warnLink);
zeigen('start');
