// Warnungen bleiben auf jeder Seite sichtbar, auch für andere gespeicherte Zähler.
const bewegungStil=document.createElement('style');bewegungStil.textContent=`
.leckKarten{display:grid;gap:12px;margin-bottom:20px}.leckKarte{border:1px solid #efb4a7;border-left:5px solid #bb4932;background:#fff3ee;color:#6d291d;border-radius:16px;padding:20px}.leckKarte h2{color:#8e3222;margin:0}.leckKopf{display:flex;gap:12px;align-items:center}.leckSymbol{font-size:24px}.leckKarte p{margin:10px 0}.leckZahlen{display:flex;gap:24px;flex-wrap:wrap;margin:14px 0}.leckZahlen strong{display:block;font-size:22px}.leckZahlen small{font-size:12px}.leckKarte button{background:#fff8f5;color:#782b20;border-color:#e4b9ae}.leckKarte[data-alt=true]{border-color:#d7bf85;background:#fff7e5;color:#72551a}.srNur{position:absolute;width:1px;height:1px;overflow:hidden;clip-path:inset(50%)}
button{transition:background-color .18s,border-color .18s,box-shadow .18s}button:active:not(:disabled){transform:translateY(1px)}input:focus-visible,select:focus-visible,button:focus-visible{outline:3px solid #51b9ab;outline-offset:3px}.section.active{animation:ansichtEin .22s ease-out}.badge{transition:background-color .25s,color .25s}.leckSymbol{animation:warnAtmen 1.8s ease-in-out 3}
@keyframes ansichtEin{from{opacity:0;transform:translateY(7px)}to{opacity:1;transform:none}}@keyframes warnAtmen{50%{transform:scale(1.12)}}
@media(prefers-reduced-motion:reduce){*,*::before,*::after{animation:none!important;transition:none!important}button:active:not(:disabled){transform:none}}
`;document.head.append(bewegungStil);
const leckBereich=document.createElement('div');leckBereich.id='leckKarten';leckBereich.className='leckKarten hidden';document.querySelector('main header').after(leckBereich);
const leckAnsage=document.createElement('div');leckAnsage.className='srNur';leckAnsage.setAttribute('role','alert');document.body.append(leckAnsage);
const leckAnsichten=new Map();let leckSignatur='';
function leckAktualisieren(){
 const vorhanden=new Set(),meldungen=[];const zahl=x=>Number.isFinite(x)?x.toLocaleString('de-DE',{maximumFractionDigits:2}):'—';
 for(const [id,a]of geraeteStatus){
  if(!a.leckverdacht)continue;vorhanden.add(id);const g=geraeteListe.find(g=>g.id===id),name=g?.name||a.name||id;
  const alter=Number(a.alter_s||0)+Math.max(0,(Date.now()-a.empfangen)/1000),alt=!online||a.empfang_fehlt||alter>(g?.empfang_sekunden||a.empfang_sekunden||600);
  let v=leckAnsichten.get(id);if(!v){const el=document.createElement('article');el.className='leckKarte';el.innerHTML='<div class="leckKopf"><span class="leckSymbol" aria-hidden="true">⚠</span><h2>Leckverdacht</h2></div><p class="leckName"></p><div class="leckZahlen"><div><strong class="leckFluss"></strong><small>Zuletzt gemeldeter Durchfluss</small></div><div><strong class="leckZeit"></strong><small>Gemeldeter Dauerverbrauch</small></div></div><p class="leckHinweis"></p><div class="row"><button class="leckAnsehen">Zähler ansehen</button><button class="leckRegeln">Warneinstellungen öffnen</button></div>';leckBereich.append(el);v={el};leckAnsichten.set(id,v);
   const oeffnen=tab=>{wahl=id;localStorage.setItem('hydrus-kennung',id);auswahl();aktualisieren();zeigen(tab);};el.querySelector('.leckAnsehen').onclick=()=>oeffnen('start');el.querySelector('.leckRegeln').onclick=()=>oeffnen('warnungen');
  }
  const text=(klasse,t)=>{const e=v.el.querySelector(klasse);if(e.textContent!==t)e.textContent=t;};v.el.dataset.alt=String(alt);
  text('h2',alt?'Leckverdacht · Status nicht aktuell':'Leckverdacht');text('.leckName',name===id?id:name+' · '+id);
  text('.leckFluss',Number.isFinite(a.durchfluss_l_min)?zahl(a.durchfluss_l_min)+' l/min':'Nicht verfügbar');
  text('.leckZeit',Number.isFinite(a.leck_seit_s)?zahl(a.leck_seit_s/60)+' min':'Nicht verfügbar');
  text('.leckHinweis',alt?'Letzter bekannter Zustand. Verbindung und Zählerempfang prüfen.':'Es fließt länger Wasser als eingestellt. Bitte Wasserhähne, Toiletten und Leitungen prüfen.');
  meldungen.push(id+':'+alt);
 }
 for(const[id,v]of leckAnsichten)if(!vorhanden.has(id)){v.el.remove();leckAnsichten.delete(id);}
 leckBereich.classList.toggle('hidden',!vorhanden.size);const signatur=meldungen.sort().join('|');if(signatur!==leckSignatur){leckAnsage.textContent=vorhanden.size?'Leckverdacht bei '+vorhanden.size+' Zähler'+(vorhanden.size===1?'':'n')+'. Bitte prüfen.':leckSignatur?'Keine aktive Leckwarnung mehr.':'';leckSignatur=signatur;}
}
const komfortOhneLeckkarte=komfortAktualisieren;komfortAktualisieren=function(){komfortOhneLeckkarte();leckAktualisieren();};
setInterval(leckAktualisieren,1000);
// Nur tatsächlich geänderte Messwerte kurz hervorheben, keine erfundenen Zwischenwerte.
const reduzierteBewegung=matchMedia('(prefers-reduced-motion: reduce)');
for(const el of document.querySelectorAll('.metric strong')){let letzter=el.textContent;new MutationObserver(()=>{const neu=el.textContent;if(neu===letzter)return;letzter=neu;if(!reduzierteBewegung.matches){for(const a of el.getAnimations())a.cancel();el.animate([{opacity:.55,transform:'translateY(3px)'},{opacity:1,transform:'none'}],{duration:260,easing:'ease-out'});}}).observe(el,{childList:true,characterData:true,subtree:true});}
leckAktualisieren();
