// Empfangsergebnis stammt vom Heltec, nicht aus dem ausgefüllten Schlüsselfeld.
function schluesselAnzeige(g){
 const s=g?.schluessel_pruefung;
 if(!g)return ['Noch keinen Zähler ausgewählt','off'];
 if(s==='UNVERSCHLUESSELT')return ['Unverschlüsseltes Telegramm · kein Schlüssel erforderlich',''];
 if(s?.includes('NICHT_UNTERSTUETZT'))return ['Zählervariante noch nicht unterstützt · Schlüssel nicht beurteilbar','warn'];
 if(!g.schluessel_vorhanden)return ['Kein Schlüssel gespeichert','off'];
 if(s==='ENTSCHLUESSELT')return ['Erfolgreich entschlüsselt · letztes geprüftes Telegramm',''];
 if(s==='REAL_DATA_DEKODIERT')return ['Diehl Real Data dekodiert · Prüfsumme stimmt',''];
 if(['ENTSCHLUESSELUNG_FEHLGESCHLAGEN','AUTHENTIFIZIERUNG_FEHLGESCHLAGEN','REAL_DATA_PRUEFSUMME_FALSCH'].includes(s))return ['Entschlüsselung fehlgeschlagen · Schlüssel und Zählerzuordnung prüfen','warn'];
 if(['SCHLUESSELFORMAT_UNGUELTIG','SCHLUESSEL_UNGUELTIG'].includes(s))return ['Schlüsselformat ungültig · 32 Hex-Zeichen erforderlich','warn'];
 if(['SCHLUESSEL_FEHLT','REAL_DATA_SCHLUESSEL_FEHLT'].includes(s))return ['Kein passender Schlüssel für die Telegrammkennung','warn'];
 if(!s)return ['Schlüssel gespeichert · Prüfstatus vom Heltec noch nicht verfügbar','off'];
 if(s==='WARTE_AUF_PAKET')return ['Schlüssel gespeichert · warte auf neues Funkpaket','off'];
 return ['Telegramm nicht auswertbar · '+s,'warn'];
}
function schluesselStatusAktualisieren(){
 const g=geraeteListe.find(x=>x.id===$('geraetAuswahl').value);
 const [text,klasse]=schluesselAnzeige(g);
 $('keyStatus').textContent=text;$('keyStatus').className='badge '+klasse;
 const k=geraeteListe.find(x=>x.id===wahl),[t,c]=schluesselAnzeige(k);
 $('schluesselUebersicht').textContent=t;
 $('schluesselUebersicht').className='badge '+c;
 $('schluesselUebersicht').classList.toggle('hidden',!k);
}
const schluesselKarte=document.createElement('p');schluesselKarte.id='schluesselUebersicht';
schluesselKarte.setAttribute('role','status');$('start').prepend(schluesselKarte);
$('keyStatus').setAttribute('role','status');
const schluesselAltAnzeigen=geraetAnzeigen;
geraetAnzeigen=function(){schluesselAltAnzeigen();schluesselStatusAktualisieren();};
const schluesselAltStatus=komfortStatus;
komfortStatus=function(j){schluesselAltStatus(j);schluesselStatusAktualisieren();};
const schluesselAltAktualisieren=aktualisieren;
aktualisieren=function(){schluesselAltAktualisieren();schluesselStatusAktualisieren();};
schluesselStatusAktualisieren();
