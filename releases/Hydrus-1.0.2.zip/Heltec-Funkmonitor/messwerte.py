"""Lokale Auswertung selbstbeschreibender M-Bus-Datensätze (DIF/VIF).

Keine Schlüssel am PC nötig: Nutzdaten kommen vom Arduino über USB.
Unbekannte Einheiten/Erweiterungen bleiben Rohdaten; keine geratenen Messwerte.
"""
import math
import struct
from datetime import date, datetime
from decimal import Decimal

ZUSTAENDE = {
    "REAL_DATA_DEKODIERT": "Diehl Real Data dekodiert · kurze Prüfsumme erfüllt, nicht authentifiziert · am Display prüfen",
    "REAL_DATA_SCHLUESSEL_FEHLT": "Diehl Real Data · Schlüssel für diese Kennung fehlt",
    "REAL_DATA_PRUEFSUMME_FALSCH": "Diehl Real Data · Schlüssel oder Format passt nicht (Prüfsumme falsch)",
    "REAL_DATA_FORMAT_NICHT_UNTERSTUETZT": "Diehl Real Data · diese Telegrammvariante wird noch nicht ausgewertet",
    "DIEHL_REAL_DATA": "Diehl Real Data · ältere Firmware liefert nur Rohdaten · Heltec aktualisieren",
    "SCHLUESSEL_UNGUELTIG": "Schlüsseleintrag ungültig oder doppelt",
    "ROHDATEN": "Rohdaten · ältere Firmware",
    "UNVERSCHLUESSELT": "Unverschlüsselt",
    "ENTSCHLUESSELT": "Entschlüsselt",
    "SCHLUESSEL_FEHLT": "AES-Schlüssel fehlt im Arduino",
    "SCHLUESSELFORMAT_UNGUELTIG": "Schlüsseleintrag ungültig oder doppelt",
    "ENTSCHLUESSELUNG_FEHLGESCHLAGEN": "Entschlüsselung fehlgeschlagen · Schlüssel/Format prüfen",
    "AUTHENTIFIZIERUNG_FEHLGESCHLAGEN": "MAC-Prüfung fehlgeschlagen · Schlüssel/Telegramm prüfen",
    "KOPF_UNGUELTIG": "Telegrammkopf unvollständig oder ungültig",
    "AES_FEHLER": "AES-Berechnung fehlgeschlagen",
    "VERSCHLUESSELTE_LAENGE_UNGUELTIG": "Verschlüsselte Datenlänge nicht unterstützt",
    "ELL_PRUEFSUMME_FALSCH": "Prüfsumme der Link-Schicht falsch",
    "ELL_VERSCHLUESSELUNG_NICHT_UNTERSTUETZT": "ELL-Verschlüsselung noch nicht unterstützt",
    "AFL_VARIANTE_NICHT_UNTERSTUETZT": "AFL-Variante/Fragmentierung noch nicht unterstützt",
    "TRANSPORTFORMAT_NICHT_UNTERSTUETZT": "Transportformat noch nicht unterstützt",
    "SICHERHEITSMODUS_NICHT_UNTERSTUETZT": "Verschlüsselungsmodus noch nicht unterstützt",
    "MODUS7_VARIANTE_NICHT_UNTERSTUETZT": "OMS-7-Variante noch nicht unterstützt",
    "INHALTSFORMAT_NICHT_UNTERSTUETZT": "Kompaktes/anderes Inhaltsformat noch nicht unterstützt",
    "DEMO": "DEMO · simulierte Messwerte",
}


def zahl_lesen(daten, kodierung):
    """DIF-Zahlen lesen; BCD-Fehler und nicht endliche Fließkommazahlen ablehnen."""
    if kodierung in (1, 2, 3, 4, 6, 7):
        return Decimal(int.from_bytes(daten, "little", signed=True))
    if kodierung == 5:
        wert = struct.unpack("<f", daten)[0]
        if not math.isfinite(wert):
            raise ValueError("Ungültige Fließkommazahl")
        return Decimal(str(wert))
    if kodierung in (9, 10, 11, 12, 14):
        ziffern = daten[::-1].hex()
        vorzeichen = -1 if ziffern.startswith("f") else 1
        if vorzeichen < 0:
            ziffern = ziffern[1:]
        if any(zeichen not in "0123456789" for zeichen in ziffern):
            raise ValueError("Ungültige BCD-Zahl")
        return Decimal(vorzeichen * int(ziffern))
    raise ValueError("Datentyp noch nicht als Zahl unterstützt")


def datum_lesen(daten):
    """M-Bus-Datum mit Jahrhundertkonvention 2000; Sonder-/Platzhalterwerte ablehnen."""
    if len(daten) == 4:
        if daten[0] & 0x80:
            raise ValueError("Datum/Uhrzeit als ungültig markiert")
        datum = datum_lesen(daten[2:])
        stunde, minute = daten[1] & 31, daten[0] & 63
        datetime.fromisoformat(f"{datum}T{stunde:02}:{minute:02}:00")
        return f"{datum} {stunde:02}:{minute:02}"
    if len(daten) != 2:
        raise ValueError("Datumsformat nicht unterstützt")
    tag, monat = daten[0] & 31, daten[1] & 15
    jahr = ((daten[0] >> 5) & 7) | ((daten[1] >> 1) & 120)
    if jahr > 99:
        raise ValueError("Reserviertes Jahr/Platzhalterdatum")
    return date(2000 + jahr, monat, tag).isoformat()


def einheit_lesen(vif, erweiterungen):
    """Name, Einheit und Zehnerpotenz. Erweiterungen nie stillschweigend ignorieren."""
    basis = vif & 127
    if erweiterungen:
        if basis == 0x7D and erweiterungen == [0x17]:
            return "Fehlerflags (Rohbits)", "Hex", None
        if basis == 0x7D and erweiterungen == [0x74]:
            return "Batterie-Restlaufzeit", "Tage", 0
        if basis == 0x7D and erweiterungen == [0x08]:
            return "Übertragungszähler", "", 0
        if basis == 0x7D and len(erweiterungen) == 1 and 0x2C <= erweiterungen[0] <= 0x2F:
            return "Zeit seit letzter Auslesung", ["s", "min", "h", "Tage"][erweiterungen[0] & 3], 0
        if erweiterungen in ([0x3B], [0x3C]) and 0x10 <= basis <= 0x17:
            return ("Vorwärtsvolumen" if erweiterungen[0] == 0x3B else "Rückwärtsvolumen"), "m³", basis - 0x16
        # Alle anderen Erweiterungen können die Bedeutung verändern.
        return None
    gruppen = [
        (0x00, 0x07, "Energie", "Wh", -3), (0x08, 0x0F, "Energie", "J", 0),
        (0x10, 0x17, "Volumen", "m³", -6), (0x18, 0x1F, "Masse", "kg", -3),
        (0x28, 0x2F, "Leistung", "W", -3), (0x30, 0x37, "Leistung", "J/h", 0),
        (0x38, 0x3F, "Durchfluss", "m³/h", -6), (0x40, 0x47, "Durchfluss", "m³/min", -7),
        (0x48, 0x4F, "Durchfluss", "m³/s", -9), (0x50, 0x57, "Massenfluss", "kg/h", -3),
        (0x58, 0x5B, "Vorlauftemperatur", "°C", -3), (0x5C, 0x5F, "Rücklauftemperatur", "°C", -3),
        (0x60, 0x63, "Temperaturdifferenz", "K", -3), (0x64, 0x67, "Externe Temperatur", "°C", -3),
        (0x68, 0x6B, "Druck", "bar", -3),
    ]
    for anfang, ende, name, einheit, exponent in gruppen:
        if anfang <= basis <= ende:
            return name, einheit, exponent + basis - anfang
    if 0x20 <= basis <= 0x27:
        return ("Betriebsdauer" if basis >= 0x24 else "Einschaltdauer"), ["s", "min", "h", "Tage"][basis & 3], 0
    if basis in (0x6C, 0x6D):
        return "Datum" if basis == 0x6C else "Datum/Uhrzeit", "", None
    return None


def datensaetze_lesen(hextext):
    """Alle abgrenzbaren Felder erhalten, auch unbekannte. Rückgabe: Felder, Hinweise."""
    daten = bytes.fromhex(hextext)
    if len(daten) > 256:
        raise ValueError("Nutzdaten zu lang")
    felder, hinweise = [], []
    stelle = 0
    laengen = {0: 0, 1: 1, 2: 2, 3: 3, 4: 4, 5: 4, 6: 6, 7: 8,
               8: 0, 9: 1, 10: 2, 11: 3, 12: 4, 14: 6}
    while stelle < len(daten):
        anfang = stelle
        dif = daten[stelle]
        stelle += 1
        if dif == 0x2F:  # Füllbytes sind keine Datensätze.
            continue
        feld = dict(bezeichnung="Unbekanntes Feld", wert="—", einheit="", funktion="",
                    speicher=0, tarif=0, untereinheit=0, dif_vif="", rohwert="", hinweis="")
        try:
            if dif & 15 == 15:
                feld.update(bezeichnung="Herstellerspezifischer Rest", rohwert=daten[anfang:].hex().upper(),
                            hinweis="Nicht interpretiert; separater Herstellerdecoder erforderlich.")
                felder.append(feld)
                hinweise.append("Herstellerspezifische Daten vorhanden")
                break
            speicher, tarif, geraet = (dif >> 6) & 1, 0, 0
            vorher, nummer = dif, 0
            while vorher & 0x80:
                if nummer >= 10 or stelle >= len(daten):
                    raise ValueError("DIFE-Kette unvollständig/zu lang")
                vorher = daten[stelle]
                stelle += 1
                speicher |= (vorher & 15) << (1 + 4 * nummer)
                tarif |= ((vorher >> 4) & 3) << (2 * nummer)
                geraet |= ((vorher >> 6) & 1) << nummer
                nummer += 1
            if stelle >= len(daten):
                raise ValueError("VIF fehlt")
            vif = daten[stelle]
            stelle += 1
            if vif & 127 == 0x7C:
                raise ValueError("Text-VIF noch nicht unterstützt; Rest bleibt Rohdaten")
            erweiterungen, vorher = [], vif
            while vorher & 0x80:
                if stelle >= len(daten) or len(erweiterungen) >= 10:
                    raise ValueError("VIFE-Kette unvollständig/zu lang")
                vorher = daten[stelle]
                erweiterungen.append(vorher & 127)
                stelle += 1
            kopfende = stelle
            kodierung = dif & 15
            if kodierung == 13:
                if stelle >= len(daten):
                    raise ValueError("Variable Datenlänge fehlt")
                lvar = daten[stelle]
                stelle += 1
                if lvar <= 0xBF:
                    laenge = lvar
                elif lvar <= 0xEF:
                    laenge = lvar & 15
                else:
                    raise ValueError("Variable Fließkomma-/Sonderlänge noch nicht unterstützt")
            else:
                laenge = laengen[kodierung]
            if stelle + laenge > len(daten):
                raise ValueError("Datensatz abgeschnitten")
            wertbytes = daten[stelle:stelle + laenge]
            stelle += laenge
            feld.update(funktion=["Momentanwert", "Maximum", "Minimum", "Wert im Fehlerzustand"][(dif >> 4) & 3],
                        speicher=speicher, tarif=tarif, untereinheit=geraet,
                        dif_vif=daten[anfang:kopfende].hex().upper(), rohwert=wertbytes.hex().upper())
            einheit = einheit_lesen(vif, erweiterungen)
            if einheit is None:
                feld["hinweis"] = "Einheit/Erweiterung nicht interpretiert"
            else:
                feld["bezeichnung"], feld["einheit"], exponent = einheit
                try:
                    if feld["einheit"] == "Hex":
                        feld["wert"] = "0x" + wertbytes[::-1].hex().upper()
                        feld["hinweis"] = "Bedeutung der einzelnen Bits herstellerabhängig"
                    elif vif & 127 in (0x6C, 0x6D):
                        if kodierung != (2 if vif & 127 == 0x6C else 4):
                            raise ValueError("Abweichender Datums-Datentyp")
                        feld["wert"] = datum_lesen(wertbytes)
                    else:
                        if feld["bezeichnung"] in ("Übertragungszähler", "Batterie-Restlaufzeit") and kodierung in (1, 2, 3, 4, 6, 7):
                            zahl = Decimal(int.from_bytes(wertbytes, "little", signed=False))
                        else:
                            zahl = zahl_lesen(wertbytes, kodierung)
                        feld["wert"] = format(zahl * (Decimal(10) ** exponent), "f")
                except (ValueError, struct.error) as fehler:
                    feld["hinweis"] = str(fehler)
            felder.append(feld)
        except (ValueError, KeyError) as fehler:
            hinweise.append(str(fehler))
            feld.update(bezeichnung="Nicht auswertbarer Rest", rohwert=daten[anfang:].hex().upper(), hinweis=str(fehler))
            felder.append(feld)
            break
    return felder, hinweise


def paket_auswerten(paket):
    """Messfelder nur bei ausdrücklich erfolgreicher Firmware-Auswertung interpretieren."""
    zustand = paket.get("auswertung", "ROHDATEN")
    meldung = ZUSTAENDE.get(zustand, "Unbekannter Auswertungsstatus: " + zustand[:80])
    if zustand == "ENTSCHLUESSELT":
        if paket.get("sicherheitsmodus") == 7 and not paket.get("authentifiziert"):
            return [], "Modus 7 ohne bestätigte MAC-Prüfung · keine Messwertauswertung"
        meldung += " · MAC geprüft" if paket.get("authentifiziert") else " · ohne MAC-Authentifizierung"
    if zustand not in ("UNVERSCHLUESSELT", "ENTSCHLUESSELT", "DEMO", "REAL_DATA_DEKODIERT"):
        return [], meldung
    try:
        felder, hinweise = datensaetze_lesen(paket.get("nutzdaten_hex", ""))
    except ValueError as fehler:
        return [], meldung + " · " + str(fehler)
    if hinweise:
        if zustand == 'REAL_DATA_DEKODIERT':
            return [], meldung + ' · Datenstruktur unplausibel: ' + '; '.join(hinweise)
        meldung += " · " + "; ".join(hinweise)
    elif not felder:
        meldung += " · keine Messfelder übertragen"
    elif any(feld["hinweis"] for feld in felder):
        meldung += " · einige Felder nur als Rohdaten"
    return felder, meldung
