"""Nicht blockierender lokaler TCP-Datenkanal zum ESP32-Accesspoint."""
import errno
import ipaddress
import select
import socket
import time


class WlanVerbindung:
    def __init__(self, adresse='192.168.4.1', port=8765):
        adresse = str(ipaddress.IPv4Address(adresse.strip()))
        if type(port) is not int or not 1 <= port <= 65535:
            raise ValueError('Ungültiger WLAN-Datenport')
        self.port = f'{adresse}:{port}'
        self.bereit = False
        self.geschlossen = False
        self.sendepuffer = bytearray()
        self.frist = time.monotonic() + 4
        self.letztes_senden = time.monotonic()
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        try:
            self.sock.setblocking(False)
            self.sock.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
            ergebnis = self.sock.connect_ex((adresse, port))
            if ergebnis == 0:
                self.bereit = True
            elif ergebnis not in (errno.EINPROGRESS, errno.EWOULDBLOCK, errno.EALREADY, 10035, 10036, 10037):
                raise OSError(ergebnis, 'WLAN-Verbindung konnte nicht aufgebaut werden')
        except Exception:
            self.sock.close()
            raise

    def _pflegen(self):
        if self.geschlossen:
            raise OSError('WLAN-Verbindung ist geschlossen')
        if not self.bereit:
            _, schreiben, fehler = select.select([], [self.sock], [self.sock], 0)
            if schreiben or fehler:
                nummer = self.sock.getsockopt(socket.SOL_SOCKET, socket.SO_ERROR)
                if nummer:
                    raise OSError(nummer, 'ESP32 nicht erreichbar. PC mit HYDRUS-Monitor verbinden und IP/Port prüfen.')
                self.bereit = True
            elif time.monotonic() > self.frist:
                raise OSError('WLAN-Verbindungsaufbau abgelaufen. PC mit dem ESP32-WLAN verbinden.')
        if self.bereit and self.sendepuffer:
            try:
                anzahl = self.sock.send(self.sendepuffer)
                if anzahl == 0:
                    raise OSError('WLAN-Verbindung unterbrochen')
                del self.sendepuffer[:anzahl]
                self.letztes_senden = time.monotonic()
            except (BlockingIOError, InterruptedError):
                pass
            if self.sendepuffer and time.monotonic() - self.letztes_senden > 3:
                raise OSError('WLAN-Senden abgelaufen')

    def read(self, anzahl):
        self._pflegen()
        if not self.bereit:
            return b''
        try:
            daten = self.sock.recv(anzahl)
        except (BlockingIOError, InterruptedError):
            return b''
        if not daten:
            raise OSError('ESP32 hat die WLAN-Datenverbindung getrennt. Erneut verbinden.')
        return daten

    def write(self, daten):
        self._pflegen()
        if not self.bereit:
            raise OSError('WLAN-Verbindung wird noch aufgebaut')
        if len(self.sendepuffer) + len(daten) > 4096:
            raise OSError('Zu viele ausstehende WLAN-Befehle')
        if not self.sendepuffer:
            self.letztes_senden = time.monotonic()
        self.sendepuffer.extend(daten)
        self._pflegen()
        return len(daten)

    def close(self):
        self.geschlossen = True
        self.bereit = False
        self.sock.close()
        self.sendepuffer.clear()
