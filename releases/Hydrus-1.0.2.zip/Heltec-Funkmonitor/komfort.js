// Gemeinsame Funktionen für Handy und PySide6. Namen, Schlüssel und Warnregeln liegen im Heltec.
let geraeteKonfigGeladen=false;
let geraeteListe=[],geraeteStatus=new Map(),verbrauchDaten=new Map(),statistikGeladen=false;
const berlin=new Intl.DateTimeFormat('sv-SE',{timeZone:'Europe/Berlin',year:'numeric',month:'2-digit',day:'2-digit'});
function kalendertag(d,offset){let [y,m,t]=berlin.format(d).split('-').map(Number);return new Date(Date.UTC(y,m-1,t+offset,12));}
function tagnummer(d){return Number(berlin.format(d).replaceAll('-',''))}
function komfortStatus(j){
  if(j.wlan?.ap_name!==undefined){if(!$('apName').dataset.bearbeitet)$('apName').value=j.wlan.ap_name;$('apAdresse').textContent=j.wlan.ap_name+' · 192.168.4.1';}
  if(j.zaehler){geraeteKonfigGeladen=true;geraeteListe=j.zaehler;geraeteAuswahl();auswahl();}
  for(const a of j.analyse||[])geraeteStatus.set(a.id,{...a,empfangen:Date.now()});
  if(j.verbrauch_fehler)melden(j.verbrauch_fehler);
  if(!statistikGeladen){statistikGeladen=true;statistikLaden();}
  komfortAktualisieren();
}
function statistikLesen(text){
  verbrauchDaten.clear();
  for(const z of text.split('\n'))try{
    if(!z.trim())continue;let d=JSON.parse(z);
    if(d.typ==='aktuell'){for(const a of d.werte||[])geraeteStatus.set(a.id,{...a,empfangen:Date.now()});continue;}
    if(!['tage','stunden'].includes(d.typ)||!Number.isFinite(d.m3)||d.m3<0)continue;
    let k=d.typ+':'+d.id+':'+d.periode,alt=verbrauchDaten.get(k);
    if(!alt||d.bis>=alt.bis)verbrauchDaten.set(k,d);
  }catch(e){/* Abgebrochene letzte Flash-Zeile überspringen. */}
  auswahl();komfortAktualisieren();
}
async function statistikLaden(){try{
  if(pc){if(bridge)bridge.statistikLaden($('adresse').value);return;}
  let r=await fetch('/api/statistik',{cache:'no-store',signal:AbortSignal.timeout(30000)});
  if(!r.ok)throw Error('Verbrauch nicht erreichbar');statistikLesen(await r.text());
}catch(e){melden(e.message)}}
function perioden(id,typ){let m=new Map();for(const d of verbrauchDaten.values())if(d.id===id&&d.typ===typ)m.set(d.periode,d.m3);
  let a=geraeteStatus.get(id);if(a?.zeit){if(typ==='tage')m.set(a.tag,a.tag_m3);else m.set(a.stunde,a.stunde_m3);}return m;}
function verbrauchWert(id,n,einheit){wert(id,Number.isFinite(n)?n:null,einheit);if(Number.isFinite(n)&&n>0)$(id).prepend(document.createTextNode('≥ '));}
function komfortAktualisieren(){
  let jetzt=new Date(),heute=tagnummer(jetzt),vorher=kalendertag(jetzt,-1),gestern=tagnummer(vorher),monat=Math.floor(heute/100),tage=perioden(wahl,'tage');
  verbrauchWert('heute',tage.has(heute)?tage.get(heute)*1000:null,'l');
  let bekannt=[...tage].filter(([t])=>Math.floor(t/100)===monat&&t<=heute);
  verbrauchWert('monat',bekannt.length?bekannt.reduce((s,[t,v])=>s+v,0):null,'m³');
  $('gestern').textContent='Gestern: '+(tage.has(gestern)?'≥ '+(tage.get(gestern)*1000).toLocaleString('de-DE',{maximumFractionDigits:1})+' l':'—');
  let a=geraeteStatus.get(wahl),g=geraeteListe.find(x=>x.id===wahl),o=zaehler.get(wahl),warn=[];
  let alter=a?Number(a.alter_s||0)+(Date.now()-a.empfangen)/1000:o?(Date.now()-o.zeit)/1000:0;
  if(!online)warn.push('Verbindung getrennt');
  if(alter>(g?.empfang_sekunden||a?.empfang_sekunden||600)||a?.empfang_fehlt)warn.push('Kein Zählerempfang');
  else if(a?.leckverdacht)warn.push('Leckverdacht · anhaltender Durchfluss');
  if(a?.zaehler_ruecksprung)warn.push('Zählerstand zurückgesetzt');
  $('alarm').textContent=warn.join(' · ');$('alarm').classList.toggle('hidden',!warn.length);
  verbrauchZeichnen(tage,jetzt);
}
function verbrauchZeichnen(tage,jetzt){
  let typ=$('zeitraum').value,werte=[],labels=[];
  if(typ==='tag'){
    const stunden=perioden(wahl,'stunden'),heute=tagnummer(jetzt);
    for(let h=Math.floor(jetzt.getTime()/3600000)-25;h<=Math.floor(jetzt.getTime()/3600000);h++){
      let d=new Date(h*3600000);if(tagnummer(d)!==heute)continue;
      werte.push(stunden.has(h)?stunden.get(h)*1000:null);labels.push(new Intl.DateTimeFormat('de-DE',{timeZone:'Europe/Berlin',hour:'2-digit'}).format(d));
    }
  }else{
    let anzahl=typ==='woche'?7:Number(berlin.format(jetzt).slice(-2));
    for(let i=anzahl-1;i>=0;i--){let d=kalendertag(jetzt,-i),tag=tagnummer(d);werte.push(tage.has(tag)?tage.get(tag)*1000:null);labels.push(String(tag%100));}
  }
  let svg=$('verbrauchGrafik');svg.replaceChildren();let max=Math.max(1,...werte.filter(Number.isFinite)),breite=820/Math.max(1,werte.length);
  function el(tag,attr,text){let e=document.createElementNS(svg.namespaceURI,tag);for(const[k,v]of Object.entries(attr))e.setAttribute(k,v);if(text!==undefined)e.textContent=text;return e;}
  svg.append(el('text',{x:20,y:15},'Liter'));
  werte.forEach((v,i)=>{let x=40+i*breite,hoehe=v===null?0:120*v/max;
    let balken=el('rect',{x,y:145-hoehe,width:Math.max(2,breite-5),height:Math.max(2,hoehe),fill:v===null?'#b6c5c1':'#168e80'});
    balken.append(el('title',{},labels[i]+': '+(v===null?'keine Daten':v.toLocaleString('de-DE')+' l')));svg.append(balken);
    if(i%Math.ceil(werte.length/12)===0)svg.append(el('text',{x,y:170},labels[i]));
  });
  if(!werte.some(Number.isFinite))svg.append(el('text',{x:330,y:80},'Noch keine Verbrauchsdaten'));
}
const bisherAufnehmen=aufnehmen;
aufnehmen=function(e){if(e.paket?.geraetestatus){let a=e.paket.geraetestatus;geraeteStatus.set(a.id,{...a,empfangen:Date.now()});}bisherAufnehmen(e);komfortAktualisieren();};
const bisherAuswahl=auswahl;
auswahl=function(){
 const ids=geraeteKonfigGeladen?geraeteListe.map(g=>g.id):[...new Set([...geraeteListe.map(g=>g.id),...geraeteStatus.keys(),...zaehler.keys(),wahl].filter(Boolean))];
 if(geraeteKonfigGeladen&&!ids.includes(wahl))wahl=ids[0]||'';
 if(!wahl&&ids.length)wahl=ids[0];$('zaehler').replaceChildren();
 for(const id of ids){const g=geraeteListe.find(g=>g.id===id),a=geraeteStatus.get(id),name=g?.name||a?.name;
  const text=(name&&name!==id?name+' · ':'')+id+(zaehler.has(id)?'':' · wartet auf Empfang');
  $('zaehler').append(new Option(text,id));
 }$('zaehler').value=wahl;
};
const bisherAktualisieren=aktualisieren;
aktualisieren=function(){bisherAktualisieren();komfortAktualisieren();};
// Beim PC-Verbindungsaufbau die im Gerät gespeicherten Summen nachladen.
const bisherVerbindung=verbindung;
verbindung=function(aktiv,text){let vorher=online;bisherVerbindung(aktiv,text);if(pc&&aktiv&&!vorher)statistikLaden();};
$('zeitraum').onchange=komfortAktualisieren;$('statistikNeu').onclick=statistikLaden;

let geraetNeu=false,geraetFormInitialisiert=false,geraetSpeichert=false;
function geraeteAuswahl(){
 const s=$('geraetAuswahl'),alt=s.value,ids=JSON.stringify(geraeteListe);
 if(s.dataset.ids===ids)return;s.dataset.ids=ids;s.replaceChildren();
 for(const g of geraeteListe)s.append(new Option(g.name&&g.name!==g.id?g.name+' · '+g.id:g.id,g.id));
 s.append(new Option('Neuen Zähler anlegen',''));
 s.value=geraetNeu?'':geraeteListe.some(g=>g.id===alt)?alt:geraeteListe[0]?.id||'';
 // Statusabfragen duerfen einen begonnenen Entwurf nicht zuruecksetzen.
 if(!geraetFormInitialisiert){geraetFormInitialisiert=true;geraetAnzeigen();}
 $('geraetHinzufuegen').disabled=geraeteListe.length>=8||geraetSpeichert;
}
function geraetAnzeigen(){
 const g=geraeteListe.find(x=>x.id===$('geraetAuswahl').value);geraetNeu=!g;
 $('geraetId').value=g?.id||'';$('geraetId').readOnly=!!g;
 $('geraetName').value=g?.name||'';$('geraetKey').value='';$('keyLoeschen').checked=false;
 $('keyStatus').textContent=g?.schluessel_vorhanden?'Schlüssel gespeichert · leer lassen zum Beibehalten':'Schlüssel optional · für verschlüsselte Messwerte erforderlich';

 $('geraetSpeichern').textContent=g?'Änderungen speichern':'Zähler hinzufügen';
 $('geraetFormTitel').textContent=g?'Zähler bearbeiten':'Neuen Zähler anlegen';
 if($('geraetLoeschen'))$('geraetLoeschen').classList.toggle('hidden',!g);
 $('geraetMeldung').textContent='';$('geraetAbbrechen').classList.toggle('hidden',!!g);
}
$('geraetAuswahl').onchange=()=>geraetAnzeigen();
$('geraetHinzufuegen').onclick=()=>{if(geraeteListe.length>=8)return;$('geraetAuswahl').value='';geraetAnzeigen();$('geraetId').focus();};
$('geraetAbbrechen').onclick=()=>{$('geraetAuswahl').value=geraeteListe[0]?.id||'';geraetAnzeigen();};
$('geraetZurUebersicht').onclick=()=>{zeigen('start');aktualisieren();};
$('geraeteForm').onsubmit=async e=>{
 e.preventDefault();if(geraetSpeichert)return;if(pc){bridge.webOeffnen($('adresse').value);return;}
 const id=$('geraetId').value.trim().toUpperCase(),name=$('geraetName').value.trim()||id,key=$('geraetKey').value.replace(/\s/g,'');
 if(!/^[0-9A-F]{8}$/.test(id)){$('geraetMeldung').textContent='Bitte die achtstellige Funkkennung eingeben.';return;}
 if(geraetNeu&&geraeteListe.some(g=>g.id===id)){$('geraetMeldung').textContent='Dieser Zähler ist bereits gespeichert. Oben zum Bearbeiten auswählen.';return;}
 if(geraetNeu&&geraeteListe.length>=8){$('geraetMeldung').textContent='Es sind bereits acht Zähler gespeichert.';return;}
 if(key&&!/^[0-9A-Fa-f]{32}$/.test(key)){$('geraetMeldung').textContent='Der AES-Schlüssel muss aus 32 Hex-Zeichen bestehen.';return;}
 const daten={id,name,bereich:'stammdaten',schluessel:key,schluessel_loeschen:$('keyLoeschen').checked?'1':'0',neu:geraetNeu?'1':'0'};
 geraetSpeichert=true;$('geraetSpeichern').disabled=true;$('geraetHinzufuegen').disabled=true;$('geraetAuswahl').disabled=true;
 $('geraetMeldung').textContent='Zähler wird gespeichert …';
 try{
  if(!token)await sitzungLaden();
  const r=await fetch('/api/zaehler',{method:'POST',headers:{'X-Hydrus-Token':token},body:new URLSearchParams(daten),signal:AbortSignal.timeout(15000)});
  const text=await r.text();if(!r.ok)throw Error(text);
  const alt=geraeteListe.find(g=>g.id===id),g={id,name,schluessel_vorhanden:daten.schluessel_loeschen==='1'?false:!!key||!!alt?.schluessel_vorhanden,leck_l_min:alt?.leck_l_min??.1,leck_sekunden:alt?.leck_sekunden??1800,empfang_sekunden:alt?.empfang_sekunden??600,leck_aktiv:alt?.leck_aktiv??true};
  geraeteListe=geraeteListe.filter(x=>x.id!==id);geraeteListe.push(g);geraetNeu=false;geraeteAuswahl();$('geraetAuswahl').value=id;geraetAnzeigen();
  wahl=id;localStorage.setItem('hydrus-kennung',id);auswahl();aktualisieren();
  $('geraetMeldung').textContent='Gespeichert. Der Zähler ist jetzt in der Übersicht auswählbar.';$('geraetZurUebersicht').classList.remove('hidden');
 }catch(err){$('geraetMeldung').textContent=err.message;}
 finally{geraetSpeichert=false;$('geraetSpeichern').disabled=false;$('geraetAuswahl').disabled=false;$('geraetHinzufuegen').disabled=geraeteListe.length>=8;}
};
$('sicherung').onclick=async()=>{if(pc){bridge.webOeffnen($('adresse').value);return;}try{if(!token)await sitzungLaden();let antwort=await Promise.all(['/api/konfiguration','/api/verlauf','/api/statistik'].map(u=>fetch(u,{cache:'no-store',signal:AbortSignal.timeout(30000)})));if(antwort.some(r=>!r.ok))throw Error('Sicherung unvollständig');let [konfiguration,verlauf,statistik]=await Promise.all(antwort.map(r=>r.text()));let daten={schema:2,erstellt:new Date().toISOString(),konfiguration:JSON.parse(konfiguration),verlauf,statistik};let u=URL.createObjectURL(new Blob([JSON.stringify(daten)],{type:'application/json'})),a=document.createElement('a');a.href=u;a.download='hydrus-sicherung-'+new Date().toISOString().slice(0,10)+'.json';a.click();setTimeout(()=>URL.revokeObjectURL(u),1000);}catch(e){melden(e.message)}};
function farbeSetzen(t){document.body.dataset.theme=t;localStorage.setItem('hydrus-farbe',t);}
farbeSetzen(localStorage.getItem('hydrus-farbe')||'hell');$('farbschema').onclick=()=>farbeSetzen(document.body.dataset.theme==='hell'?'dunkel':'hell');
if(pc){$('geraeteForm').classList.add('hidden');let hinweis=document.createElement('button');hinweis.textContent='Zählerverwaltung öffnen';hinweis.onclick=()=>bridge.webOeffnen($('adresse').value);$('geraeteForm').parentElement.append(hinweis);}
geraeteAuswahl();
