// Zusatzwerte stammen ausschliesslich aus dem letzten Paket des gewaehlten Zaehlers.
const zusatzStil=document.createElement('style');zusatzStil.textContent=`.zusatzRaster{grid-template-columns:repeat(4,minmax(0,1fr))}.zusatzRaster strong{font-size:24px;overflow-wrap:anywhere}.zusatzRaster .metric{gap:12px}#geraeteZustand{font-size:18px;hyphens:auto;letter-spacing:0}.zusatzWerte{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:20px}.zusatzWerte small{display:block;color:var(--muted);margin-bottom:6px}.zusatzWerte strong{overflow-wrap:anywhere}.zusatzWarnung{color:var(--warn)}@media(max-width:1100px){.zusatzRaster,.zusatzWerte{grid-template-columns:repeat(2,minmax(0,1fr))}}@media(max-width:400px){.zusatzWerte{grid-template-columns:1fr}}`;
document.head.append(zusatzStil);
function aktuellesZusatzfeld(f){return f.funktion==='Momentanwert'&&f.speicher===0&&f.tarif===0&&f.untereinheit===0;}
function lesbaresZusatzfeld(f){return f.wert!==undefined&&f.wert!==null&&String(f.wert)!=='—'&&(!f.hinweis||f.bezeichnung==='Fehlerflags (Rohbits)');}
function zusatzText(f){const n=Number(f.wert);return (f.einheit==='Hex'||!Number.isFinite(n)?String(f.wert):n.toLocaleString('de-DE',{maximumFractionDigits:6}))+(f.einheit&&f.einheit!=='Hex'?' '+f.einheit:'');}
function zaehlerZusatzdaten(o){
 const f=o?.felder||[],aktuell=f.filter(x=>aktuellesZusatzfeld(x)&&lesbaresZusatzfeld(x));
 const b=feldwert(f,['Batterie-Restlaufzeit']);
 let batterie='—',batterieHinweis='Keine Angabe',status=[],warnung=false;
 if(b&&Number(b.wert)>=0){batterie=zusatzText(b);batterieHinweis=b.einheit==='Tage'?'≈ '+(Number(b.wert)/365.25).toLocaleString('de-DE',{maximumFractionDigits:1})+' Jahre':'';}
 // Standard-Transportstatus: kein Prozentwert und keine herstellerspezifischen Alarmannahmen.
 const s=o?.p.zaehlerstatus,hatStatus=Number.isInteger(s)&&s>=0&&s<=255;
 if(hatStatus){
   if(s&4){status.push('Batteriewarnung');batterieHinweis='Batteriewarnung';warnung=true;}
   if(s&8){status.push('Dauerhafter Fehler');warnung=true;}
   if(s&16){status.push('Vorübergehender Fehler');warnung=true;}
   if(s&3){status.push('Anwendungsstatus '+(s&3));warnung=true;}
   if(s&224){status.push('Herstellerstatus');warnung=true;}
 }
 const flags=aktuell.filter(x=>x.bezeichnung==='Fehlerflags (Rohbits)'&&/^0x[0-9a-f]+$/i.test(x.wert));
 if(flags.some(x=>BigInt(x.wert)!==0n)){status.push('Fehlerflags gesetzt');warnung=true;}
 const statusText=status.length?status.join(' · '):(hatStatus||flags.length?'Keine Fehlermeldung':'Keine Angabe');
 const roh=[...(hatStatus?['Status 0x'+s.toString(16).padStart(2,'0').toUpperCase()]:[]),...flags.map(x=>'Fehlerflags '+x.wert)].join(' · ');
 return {batterie,batterieHinweis,statusText,roh,warnung,
 weitere:aktuell.filter(x=>!['Volumen','Durchfluss','Vorlauftemperatur','Externe Temperatur','Batterie-Restlaufzeit','Fehlerflags (Rohbits)'].includes(x.bezeichnung)),
 register:f.filter(x=>lesbaresZusatzfeld(x)&&!aktuellesZusatzfeld(x))};
}
function zusatzAktualisieren(){
 const o=zaehler.get(wahl),d=zaehlerZusatzdaten(o),f=o?.felder||[];
 $('batterie').textContent=d.batterie;$('batterieHinweis').textContent=d.batterieHinweis;
 const umgebung=feldwert(f,['Externe Temperatur']);wert('umgebung',umgebung?Number(umgebung.wert):null,'°C');
 $('geraeteZustand').textContent=d.statusText;$('geraeteZustand').classList.toggle('zusatzWarnung',d.warnung);$('statusHinweis').textContent=d.roh;
 const alter=o?Math.max(0,Math.floor((Date.now()-o.zeit)/1000)):null;
 $('zusatzAlter').textContent=alter===null?'Noch keine Daten':!online?'Verbindung getrennt':alter>120?'Letztes Telegramm · '+alter+' s alt':'Letztes Telegramm · '+alter+' s';
 $('zusatzAlter').className='badge '+(!online||alter===null||alter>120?'warn':'');
 $('zusatzWerte').replaceChildren();
 for(const x of d.weitere){const box=document.createElement('div'),titel=document.createElement('small'),wert=document.createElement('strong');titel.textContent=x.bezeichnung;wert.textContent=zusatzText(x);box.append(titel,wert);$('zusatzWerte').append(box);}
 $('zusatzLeer').classList.toggle('hidden',!!d.weitere.length);
 $('registerWerte').replaceChildren();
 for(const x of d.register){const teile=[x.funktion];if(x.speicher)teile.push('Speicher '+x.speicher);if(x.tarif)teile.push('Tarif '+x.tarif);if(x.untereinheit)teile.push('Gerät '+x.untereinheit);zeile($('registerWerte'),[x.bezeichnung,zusatzText(x),teile.join(' · ')]);}
 $('registerKarte').classList.toggle('hidden',!d.register.length);
}
zusatzAktualisieren();
