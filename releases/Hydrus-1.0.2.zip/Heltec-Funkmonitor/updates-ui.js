// Fortschritt bleibt auch beim Wechsel des Tabs erhalten.
let updateLaeuft=false,updateAngebotVorhanden=false;
const updateStil=document.createElement('style');
updateStil.textContent=`#updateFortschritt{margin:16px 0}#updateBalken{width:100%;height:14px;accent-color:var(--accent,#087f80)}.updateWarten{display:inline-block;width:14px;height:14px;border:2px solid #a6cccc;border-top-color:#087f80;border-radius:50%;animation:updateDrehen 1s linear infinite;margin-right:8px;vertical-align:middle}@keyframes updateDrehen{to{transform:rotate(360deg)}}@media(prefers-reduced-motion:reduce){.updateWarten{animation:none}}`;
document.head.append(updateStil);
$('updateStatus').insertAdjacentHTML('afterend','<div id="updateFortschritt" class="hidden" role="status" aria-live="polite"><span id="updateSpinner" class="updateWarten"></span><span id="updatePhase"></span><progress id="updateBalken" max="100" aria-label="Updatefortschritt"></progress></div>');
function updateFortschritt(aktiv,text,prozent=null){
  updateLaeuft=aktiv;
  $('updates').setAttribute('aria-busy',String(aktiv));
  $('updateFortschritt').classList.toggle('hidden',!aktiv&&prozent===null);
  $('updateSpinner').classList.toggle('hidden',!aktiv||prozent!==null);
  $('updatePhase').textContent=text+(prozent!==null?' · '+Math.round(prozent)+' %':'');
  if(prozent===null)$('updateBalken').removeAttribute('value');else $('updateBalken').value=Math.max(0,Math.min(100,prozent));
  for(const id of ['updatePruefen','updateQuelle','updateDateiPc','updateDateiSenden','updateDatei','updateNeustart'])$(id).disabled=aktiv;
  $('updateInstallieren').disabled=aktiv||!updateAngebotVorhanden;
}
function updateAnzeige(d){
  if(d.version)$('updateVersion').textContent='Version '+d.version;
  const text=d.meldung||d.text||'Bereit';$('updateStatus').textContent=text;
  if(d.url!==undefined)$('updateUrl').value=d.url;
  if(d.server!==undefined)$('updateUrl').value=d.server;
  if(d.angebot!==undefined)updateAngebotVorhanden=!!d.angebot;
  if(d.pfad)$('updateNeustart').classList.remove('hidden');
  if(d.aktiv===true)updateFortschritt(true,text,Number.isFinite(d.prozent)?d.prozent:null);
  else updateFortschritt(false,text,d.fertig||d.pfad?100:null);
}
function updateFehler(e){updateFortschritt(false,'');$('updateStatus').textContent=e.message||String(e);melden(e.message||String(e));}
async function updateAnfrage(pfad,body){
  if(!token)await sitzungLaden();
  let r=await fetch(pfad,{method:'POST',headers:{'X-Hydrus-Token':token},body,signal:AbortSignal.timeout(180000)});
  if(!r.ok)throw Error(await r.text());
  if((r.headers.get('content-type')||'').includes('json'))updateAnzeige(await r.json());else {const text=await r.text();updateAnzeige({text});}
}
const vorherZeigen=zeigen;
zeigen=function(tab){vorherZeigen(tab);if(tab==='updates'&&!pc&&!updateLaeuft)fetch('/api/update',{cache:'no-store'}).then(r=>{if(!r.ok)throw Error('Heltec nicht erreichbar');return r.json()}).then(d=>{if(!updateLaeuft)updateAnzeige(d)}).catch(e=>{if(!updateLaeuft)updateFehler(e)});};
$('updatePruefen').onclick=async()=>{if(updateLaeuft)return;updateFortschritt(true,'Suche nach Updates …');try{if(pc){bridge.updatePruefen($('updateUrl').value);return;}await updateAnfrage('/api/update/pruefen',new URLSearchParams());}catch(e){updateFehler(e)}};
$('updateInstallieren').onclick=async()=>{if(updateLaeuft||!confirm('Update installieren?'))return;updateFortschritt(true,'Update wird heruntergeladen, geprüft und installiert …');try{if(pc){bridge.updateInstallieren();return;}await updateAnfrage('/api/update/installieren',new URLSearchParams());}catch(e){updateFehler(e)}};
$('updateNeustart').onclick=()=>bridge.updateStarten();
$('updateDateiPc').onclick=()=>{if(!updateLaeuft)bridge.updateDatei()};
// Der Browser meldet echte Upload-Bytes. Danach ist die Geräteprüfung unbestimmt.
function updateDateiUebertragen(body){return new Promise((resolve,reject)=>{
  const x=new XMLHttpRequest();x.open('POST','/api/update/datei');x.setRequestHeader('X-Hydrus-Token',token);x.timeout=180000;
  x.upload.onprogress=e=>updateFortschritt(true,'Übertragung zum Heltec',e.lengthComputable&&e.total?Math.min(100,e.loaded/e.total*100):null);
  x.upload.onload=()=>updateFortschritt(true,'Firmware wird geprüft und abgeschlossen …');
  x.onload=()=>{if(x.status<200||x.status>=300){reject(Error(x.responseText||'Installation fehlgeschlagen'));return;}try{updateAnzeige(JSON.parse(x.responseText));resolve()}catch(e){reject(Error('Ungültige Update-Antwort'))}};
  x.onerror=()=>reject(Error('Verbindung unterbrochen. Gerätestatus vor erneutem Installieren prüfen.'));
  x.ontimeout=()=>reject(Error('Keine Antwort. Gerätestatus vor erneutem Installieren prüfen.'));
  x.onabort=()=>reject(Error('Übertragung abgebrochen'));x.send(body);
})}
$('updateDateiForm').onsubmit=async e=>{e.preventDefault();if(updateLaeuft)return;let f=$('updateDatei').files[0];if(!f||!confirm('Firmware installieren und Heltec neu starten?'))return;updateFortschritt(true,'Übertragung wird vorbereitet …');try{if(!token)await sitzungLaden();let b=new FormData();b.append('datei',f);await updateDateiUebertragen(b);}catch(e){updateFehler(e)}};
$('updateQuelle').onclick=async()=>{if(updateLaeuft)return;updateFortschritt(true,pc?'Suche nach Updates …':'Update-Server wird gespeichert …');try{if(pc){bridge.updatePruefen($('updateUrl').value);return;}await updateAnfrage('/api/update/quelle',new URLSearchParams({url:$('updateUrl').value,ca:$('updateCa').value}));}catch(e){updateFehler(e)}};
if(pc){$('updateDateiForm').classList.add('hidden');$('caGruppe').classList.add('hidden');}else{$('updateDateiPc').classList.add('hidden');}
