# HYDRUS Wassermonitor

Wasserzähler mit einem Heltec V3 per Funk auslesen und Messwerte, Verbrauchsverlauf und Leckwarnungen im Browser oder PC-Programm anzeigen. Unterstützt die im Programm implementierten OMS- und Diehl-Real-Data-Varianten; verschlüsselte Daten benötigen den passenden Zählerschlüssel.

Start am PC: starten.bat. Arduino-Code: Hydrus_Heltec_V3/Hydrus_Heltec_V3.ino.

Hinweise zum Schlüsselstatus: SCHLUESSEL-STATUS.txt.
