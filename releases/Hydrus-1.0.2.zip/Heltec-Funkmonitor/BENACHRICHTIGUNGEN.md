# Handy-Mitteilungen einrichten

1. ntfy-App auf dem Handy einrichten und Benachrichtigungen erlauben.
2. Ein eigenes Thema abonnieren. Auf einem öffentlichen Server einen langen zufälligen Namen verwenden oder ein durch Zugriffsregeln geschütztes Thema nutzen. Wer ein ungeschütztes Thema kennt, kann dessen Meldungen lesen.
3. Heltec-Webseite → Überwachung → Handy-Mitteilungen. Server (standardmäßig https://ntfy.sh) und dasselbe Thema eintragen. Falls der Server es verlangt, Zugriffstoken eintragen. Aktiv einschalten und speichern.
4. Testnachricht senden. Die Auslieferung erfolgt spätestens beim nächsten Versandversuch, normalerweise innerhalb einer Minute bei bestehender Internetverbindung. Am Handy den tatsächlichen Eingang prüfen.

Versendet werden Zählername und Ereignistext, keine AES-Schlüssel, WLAN-Passwörter oder vollständigen Messreihen. Die Daten verlassen dabei das Heimnetz und gehen an den eingerichteten ntfy-Server. HTTPS prüft öffentliche Stammzertifikate. Für eigene private CA ist diese ntfy-Anbindung nicht eingerichtet.

Leckverdacht, Empfangsausfall und Wiederherstellung werden gemeldet. Höchstens ein Versandversuch pro Minute. Bis zu acht Nachrichten werden im Gerätespeicher vorgemerkt und nach Neustart erneut versucht. Ist die Warteschlange voll, werden weitere Nachrichten verworfen und dies angezeigt; der lokale Ereignisverlauf bleibt davon unabhängig. Beim Ausschalten oder Wechsel des Empfängers wird die Warteschlange geleert. Bei Übertragungsabbrüchen sind doppelte Nachrichten möglich.

„Vom Nachrichtendienst angenommen“ bestätigt die Serverantwort, nicht die Anzeige am Handy. Handy-Energiesparen, Betriebssystem und Dienst können Mitteilungen verzögern. Selbst gehostetes ntfy benötigt für zeitnahe iOS-Zustellung eine passende Push-Anbindung. Empfangsausfälle des WLANs/Internets kann der Heltec erst nach Wiederverbindung melden. Keine garantierte Sicherheitsalarmierung.

Dokumentation: https://docs.ntfy.sh/publish/ und https://docs.ntfy.sh/subscribe/phone/
