"""Zeigt Wireless-M-Bus-Telegramme eines ESP32 am Windows-PC an.

Start: python funkmonitor.py
USB-Unterstützung installieren: python -m pip install pyserial

Die Firmware prüft den Funkrahmen. Dieses Programm verarbeitet dessen
USB-Ausgabe. Entschlüsselte Nutzdaten werden lokal als Messfelder angezeigt. Eigene Bezeichner
und Kommentare sind deutsch; feste Bibliotheksaufrufe bleiben unverändert.
"""
import csv
import json
import re
import tkinter as tk
from datetime import datetime
from tkinter import filedialog, messagebox, ttk
from messwerte import paket_auswerten
from funkdiagnose import Funkdiagnose, frequenz_befehl, kennung_korrigieren
from wlanverbindung import WlanVerbindung

# Die WLAN-Verbindung funktioniert auch ohne pyserial.
try:
    import serial
    from serial.tools import list_ports
except ImportError:
    serial = None
VERBINDUNGSFEHLER = (OSError, ValueError) + ((serial.SerialException,) if serial else ())

MAXIMALE_PAKETE = 5000
PAKETKENNUNG = "WMBUS "
# Manche seriellen Ausgaben enthalten unsichtbare Terminal-Farbcodes.
ANSI_FARBCODES = re.compile(r"\x1b\[[0-?]*[ -/]*[@-~]")


def paket_lesen(zeile):
    """Nur ausdrücklich markierte Empfängerdaten zählen als Pakete, keine Startmeldungen."""
    zeile = ANSI_FARBCODES.sub("", zeile)
    position = zeile.find(PAKETKENNUNG)
    if position < 0:
        return None
    try:
        # Vor der Paketkennung dürfen Zeitstempel und sonstige Logtexte stehen.
        daten = json.loads(zeile[position + len(PAKETKENNUNG):])
        if not isinstance(daten, dict):
            return None
        rohdaten = daten.get("hex", "")
        if not isinstance(rohdaten, str):
            return None
        rohdaten = re.sub(r"\s+", "", rohdaten).upper()
        # Zwei Hexzeichen beschreiben genau ein Byte. Ungültige Daten ignorieren.
        if not rohdaten or len(rohdaten) % 2 or not re.fullmatch(r"[0-9A-F]+", rohdaten):
            return None
        if len(rohdaten) > 8192:
            return None
        rssi = daten.get("rssi")
        if isinstance(rssi, bool) or (rssi is not None and
                (not isinstance(rssi, (int, float)) or not -200 <= rssi <= 30)):
            return None
        nutzdaten = daten.get("nutzdaten_hex", "")
        if not isinstance(nutzdaten, str) or len(nutzdaten) > 512 or len(nutzdaten) % 2 or (nutzdaten and not re.fullmatch(r"[0-9a-fA-F]+", nutzdaten)):
            return None
        for feldname, minimum, maximum in [("sicherheitsmodus", -1, 31), ("zaehlerstatus", -1, 255)]:
            wert = daten.get(feldname, -1)
            if type(wert) is not int or not minimum <= wert <= maximum:
                return None
        if type(daten.get("authentifiziert", False)) is not bool:
            return None
        frequenz = daten.get('frequenz_hz')
        if frequenz is not None and (type(frequenz) is not int or not 863000000 <= frequenz <= 870000000):
            return None
        if type(daten.get('crc_geprueft', False)) is not bool:
            return None
        return kennung_korrigieren({"hex": rohdaten, "rssi": rssi,
                "format": str(daten.get('format', ''))[:8],
                "frequenz_hz": frequenz, "crc_geprueft": daten.get('crc_geprueft', False),
                "auswertung": str(daten.get("auswertung", "ROHDATEN"))[:100],
                "nutzdaten_hex": nutzdaten.upper(),
                "sicherheitsmodus": daten.get("sicherheitsmodus", -1),
                "zaehlerstatus": daten.get("zaehlerstatus", -1),
                "authentifiziert": daten.get("authentifiziert", False),
                "transportkennung": str(daten.get("transportkennung", ""))[:80],
                # Alte englische Feldnamen bleiben für frühere Firmware lesbar.
                "zaehlerkennung": str(daten.get("zaehlerkennung", daten.get("meter_id", "")))[:80],
                "modus": str(daten.get("modus", daten.get("mode", "")))[:16]})
    except (ValueError, TypeError):
        return None


class Funkmonitor:
    """Verwaltet Fenster, USB/WLAN-Verbindung und CSV-Speicherung."""

    def __init__(self, fenster):
        # Alle Änderungen an der Oberfläche laufen in derselben Ereignisschleife.
        self.fenster = fenster
        self.usb_verbindung = None
        # Gemeinsame Schnittstelle für den bisherigen USB- und den neuen WLAN-Kanal.
        self.empfangsquelle = 'USB'
        self.wlan_aufbau = False
        self.empfangspuffer = bytearray()
        self.datensaetze = {}
        self.auswertungen = {}
        self.paketanzahl = 0
        fenster.title("Funkmonitor · ESP32 / Wireless M-Bus")
        fenster.geometry("1050x690")
        fenster.minsize(800, 500)
        fenster.protocol("WM_DELETE_WINDOW", self.beenden)
        gestaltung = ttk.Style(fenster)
        gestaltung.theme_use("clam")
        gestaltung.configure("Treeview", rowheight=27)
        rahmen = ttk.Frame(fenster, padding=16)
        rahmen.pack(fill="both", expand=True)
        ttk.Label(rahmen, text="Funkmonitor", font=("Segoe UI", 23, "bold")).pack(anchor="w")
        ttk.Label(rahmen, text="Lokaler Empfang über USB oder ESP32-WLAN · Zählerschlüssel bleiben im Arduino").pack(anchor="w", pady=(0, 14))
        bedienleiste = ttk.Frame(rahmen)
        bedienleiste.pack(fill="x")
        self.verbindungsart = tk.StringVar(value='USB')
        ttk.Combobox(bedienleiste, textvariable=self.verbindungsart, values=['USB', 'WLAN'], state='readonly', width=7).pack(side='left', padx=(0, 8))
        ttk.Label(bedienleiste, text="USB-Port:").pack(side="left")
        self.anschlussname = tk.StringVar()
        self.anschlussauswahl = ttk.Combobox(bedienleiste, textvariable=self.anschlussname, width=13)
        self.anschlussauswahl.pack(side="left", padx=6)
        ttk.Button(bedienleiste, text="Suchen", command=self.anschluesse_suchen).pack(side="left")
        ttk.Label(bedienleiste, text="Baud:").pack(side="left", padx=(12, 4))
        self.baudratenauswahl = ttk.Combobox(bedienleiste, values=[115200, 9600, 57600, 230400], width=9)
        self.baudratenauswahl.set("115200")
        self.baudratenauswahl.pack(side="left")
        self.verbindungsknopf = ttk.Button(bedienleiste, text="Verbinden", command=self.verbinden)
        self.verbindungsknopf.pack(side="left", padx=6)
        wlanleiste = ttk.Frame(rahmen)
        wlanleiste.pack(fill='x', pady=(8, 0))
        self.wlan_adresse = tk.StringVar(value='192.168.4.1')
        self.wlan_port = tk.StringVar(value='8765')
        ttk.Label(wlanleiste, text='WLAN-IP:').pack(side='left')
        ttk.Entry(wlanleiste, textvariable=self.wlan_adresse, width=15).pack(side='left', padx=5)
        ttk.Label(wlanleiste, text='Port:').pack(side='left')
        ttk.Entry(wlanleiste, textvariable=self.wlan_port, width=6).pack(side='left', padx=5)
        ttk.Label(wlanleiste, text='PC zuerst mit „HYDRUS-Monitor“ verbinden · kein Internet.').pack(side='left', padx=8)
        self.status = tk.StringVar(value="Nicht verbunden")
        ttk.Label(rahmen, textvariable=self.status, font=("Segoe UI", 11, "bold")).pack(anchor="w", pady=(15, 4))
        self.statistiktext = tk.StringVar(value="Noch keine Pakete")
        ttk.Label(rahmen, textvariable=self.statistiktext).pack(anchor="w", pady=(0, 10))
        register = ttk.Notebook(rahmen)
        register.pack(fill="both", expand=True)
        paketregister = ttk.Frame(register)
        protokollregister = ttk.Frame(register)
        messregister = ttk.Frame(register)
        register.add(paketregister, text="Funkpakete")
        register.add(messregister, text="Messwerte des ausgewählten Pakets")
        register.add(protokollregister, text="Verbindungsprotokoll")
        diagnoseregister = ttk.Frame(register)
        register.add(diagnoseregister, text="Funksuche / Diagnose")
        self.diagnose = Funkdiagnose(diagnoseregister, self.befehl_senden)
        self.messwertstatus = tk.StringVar(value="Ein Paket in der Paketliste auswählen. Fehlende Werte werden nicht als Null dargestellt.")
        ttk.Label(messregister, textvariable=self.messwertstatus, wraplength=930).pack(fill="x", pady=8)
        messspalten = ("feld", "wert", "einheit", "funktion", "speicher", "tarif", "geraet", "hinweis")
        self.messwerttabelle = ttk.Treeview(messregister, columns=messspalten, show="headings")
        for name, titel, breite in zip(messspalten,
                ["Messfeld", "Wert", "Einheit", "Funktion", "Speicher", "Tarif", "Untereinheit", "Hinweis"],
                [150, 120, 65, 100, 60, 45, 70, 210]):
            self.messwerttabelle.heading(name, text=titel)
            self.messwerttabelle.column(name, width=breite, minwidth=35)
        messrollbalken = ttk.Scrollbar(messregister, command=self.messwerttabelle.yview)
        self.messwerttabelle.configure(yscrollcommand=messrollbalken.set)
        messrollbalken.pack(side="right", fill="y")
        self.messwerttabelle.pack(fill="both", expand=True)
        ttk.Label(messregister, text="Historische Werte behalten ihre Speichernummer. Unbekannte Felder stehen mit Rohdaten in den Paketdetails.", wraplength=900).pack(fill="x", pady=6)
        spalten = ("quelle", "zeit", "rssi", "kennung", "laenge", "hex", "modus")
        self.pakettabelle = ttk.Treeview(paketregister, columns=spalten, show="headings", selectmode="browse")
        self.pakettabelle.configure(displaycolumns=("quelle", "zeit", "modus", "rssi", "kennung", "laenge", "hex"))
        for spaltenname, beschriftung, breite in zip(spalten,
                ["Quelle", "Empfangen am PC", "RSSI (dBm)", "Zählerkennung*", "Bytes", "Rohdaten (Hex)", "Modus"],
                [60, 170, 85, 115, 50, 300, 60]):
            self.pakettabelle.heading(spaltenname, text=beschriftung)
            self.pakettabelle.column(spaltenname, width=breite, minwidth=40)
        rollbalken = ttk.Scrollbar(paketregister, orient="vertical", command=self.pakettabelle.yview)
        self.pakettabelle.configure(yscrollcommand=rollbalken.set)
        rollbalken.pack(side="right", fill="y")
        self.pakettabelle.pack(fill="both", expand=True)
        self.pakettabelle.bind("<<TreeviewSelect>>", self.paket_auswaehlen)
        self.protokollfeld = tk.Text(protokollregister, height=12, wrap="word", state="disabled", font=("Consolas", 10))
        protokollrollbalken = ttk.Scrollbar(protokollregister, command=self.protokollfeld.yview)
        self.protokollfeld.configure(yscrollcommand=protokollrollbalken.set)
        protokollrollbalken.pack(side="right", fill="y")
        self.protokollfeld.pack(fill="both", expand=True)
        ttk.Label(rahmen, text="Ausgewähltes Paket · *Kennung nur, wenn die Empfänger-Firmware sie liefert").pack(anchor="w", pady=(10, 3))
        self.detailfeld = tk.Text(rahmen, height=4, wrap="word", state="disabled", font=("Consolas", 10))
        self.detailfeld.pack(fill="x")
        fussleiste = ttk.Frame(rahmen)
        fussleiste.pack(fill="x", pady=(10, 0))
        ttk.Button(fussleiste, text="Pakete als CSV speichern", command=self.csv_speichern).pack(side="left")
        ttk.Button(fussleiste, text="Messwerte als CSV speichern", command=self.messwerte_speichern).pack(side="left", padx=6)
        ttk.Button(fussleiste, text="Anzeige leeren", command=self.anzeige_leeren).pack(side="left", padx=8)
        ttk.Label(fussleiste, text="Die letzten 5.000 Pakete bleiben im Speicher.").pack(side="right")
        self.anschluesse_suchen()
        fenster.after(50, self.usb_abfragen)

    def anschluesse_suchen(self):
        """Verfügbare COM-Anschlüsse auflisten; keinen davon automatisch öffnen."""
        anschluesse = [anschluss.device for anschluss in list_ports.comports()] if serial else []
        self.anschlussauswahl["values"] = anschluesse
        if anschluesse and self.anschlussname.get() not in anschluesse:
            self.anschlussname.set(anschluesse[0])

    def verbinden(self):
        """USB oder WLAN öffnen oder die vorhandene Verbindung trennen."""
        if self.usb_verbindung:
            self.trennen()
            return
        if self.verbindungsart.get() == 'WLAN':
            try:
                verbindung = WlanVerbindung(self.wlan_adresse.get(), int(self.wlan_port.get()))
            except VERBINDUNGSFEHLER as fehler:
                messagebox.showerror('WLAN-Verbindung fehlgeschlagen', str(fehler))
                return
            self.anzeige_leeren()
            self.usb_verbindung = verbindung
            self.empfangsquelle = 'WLAN'
            self.wlan_aufbau = True
            self.empfangspuffer.clear()
            self.verbindungsknopf.configure(text='Trennen')
            self.status.set(f'WLAN-Verbindung zu {verbindung.port} wird aufgebaut …')
            return
        if serial is None:
            messagebox.showinfo("USB-Unterstützung fehlt", "Einmal installieren:\npython -m pip install pyserial\n\nDanach das Programm neu starten. WLAN funktioniert auch ohne diese Bibliothek. Mit starten.bat wird die mitgelieferte USB-Bibliothek verwendet.")
            return
        try:
            baud = int(self.baudratenauswahl.get())
            if baud <= 0 or not self.anschlussname.get().strip():
                raise ValueError("Bitte USB-Port und gültige Baudrate auswählen.")
            # timeout=0 verhindert, dass das Fenster beim Warten auf USB einfriert.
            neue_verbindung = serial.Serial(port=None, baudrate=baud, timeout=0, write_timeout=0.3)
            # Steuerleitungen nicht absichtlich zum Zurücksetzen des ESP32 nutzen.
            neue_verbindung.dtr = False
            neue_verbindung.rts = False
            neue_verbindung.port = self.anschlussname.get().strip()
            neue_verbindung.open()
        except (ValueError, OSError, serial.SerialException) as fehler:
            messagebox.showerror("Verbindung fehlgeschlagen", str(fehler))
            return
        self.anzeige_leeren()
        self.usb_verbindung = neue_verbindung
        self.empfangsquelle = 'USB'
        self.wlan_aufbau = False
        self.empfangspuffer.clear()
        self.status.set(f"USB verbunden: {neue_verbindung.port} · Warte auf Empfängerpakete")
        self.verbindungsknopf.configure(text="Trennen")

    def trennen(self):
        """USB-Port beziehungsweise WLAN-Verbindung freigeben."""
        if self.usb_verbindung:
            self.usb_verbindung.close()
        self.usb_verbindung = None
        self.wlan_aufbau = False
        self.empfangspuffer.clear()
        self.verbindungsknopf.configure(text="Verbinden")
        self.status.set("Nicht verbunden · Vorhandene Pakete bleiben sichtbar")
        self.diagnose.aktuell.set('Verbindung getrennt · angezeigte Diagnosewerte sind frühere Beobachtungen.')

    def befehl_senden(self, befehl):
        """Nur die vier vorgesehenen Empfangsbefehle senden, niemals Funk aussenden."""
        if not self.usb_verbindung:
            messagebox.showinfo('Funksuche', 'Zuerst den ESP32 über USB oder WLAN verbinden.')
            return False
        try:
            if befehl not in ('SCAN', 'STOP', 'TC'):
                if not befehl.startswith('FREQ ') or frequenz_befehl(str(int(befehl[5:]) / 1000000)) != befehl:
                    raise ValueError('Ungültiger Empfangsbefehl')
            daten = (befehl + '\n').encode('ascii')
            if self.usb_verbindung.write(daten) != len(daten):
                raise OSError('Befehl konnte nicht vollständig übertragen werden.')
            self.protokoll_ergaenzen('PC → ESP32: ' + befehl)
            self.diagnose.status('PC: ' + befehl)
            return True
        except VERBINDUNGSFEHLER as fehler:
            messagebox.showerror('Empfangsbefehl fehlgeschlagen', str(fehler))
            return False

    def usb_abfragen(self):
        """Alle 50 ms neue Bytes holen und vollständige Zeilen verarbeiten."""
        if self.usb_verbindung:
            try:
                self.empfangspuffer.extend(self.usb_verbindung.read(16384))
                if self.wlan_aufbau and self.usb_verbindung.bereit:
                    self.wlan_aufbau = False
                    self.status.set(f'WLAN verbunden: {self.usb_verbindung.port} · Warte auf Empfängerpakete')
                zeilenanzahl = 0
                # USB und TCP können ein Telegramm auf mehrere Lesevorgänge verteilen.
                # Unvollständige Zeilen bleiben deshalb im Empfangspuffer stehen.
                while b"\n" in self.empfangspuffer and zeilenanzahl < 200:
                    zeile, _, rest = self.empfangspuffer.partition(b"\n")
                    self.empfangspuffer = bytearray(rest)
                    self.zeile_verarbeiten(zeile.decode("utf-8", errors="replace").rstrip(), self.empfangsquelle)
                    zeilenanzahl += 1
                # Fehlerhafte Ausgaben dürfen nicht unbegrenzt Speicher belegen.
                if len(self.empfangspuffer) > 131072:
                    self.empfangspuffer.clear()
                    self.protokoll_ergaenzen("[Hinweis: Überlange Empfangsdaten ohne verarbeitbaren Zeilenabschluss verworfen.]")
            except VERBINDUNGSFEHLER as fehler:
                self.trennen()
                self.status.set(f"{self.empfangsquelle}-Verbindung unterbrochen: {fehler}")
        self.fenster.after(50, self.usb_abfragen)

    def protokoll_ergaenzen(self, zeile):
        """Auch Startmeldungen anzeigen; sehr alte Protokollzeilen entfernen."""
        self.protokollfeld.configure(state="normal")
        self.protokollfeld.insert("end", zeile + "\n")
        if int(self.protokollfeld.index("end-1c").split(".")[0]) > 1500:
            self.protokollfeld.delete("1.0", "201.0")
        self.protokollfeld.see("end")
        self.protokollfeld.configure(state="disabled")

    def zeile_verarbeiten(self, zeile, quelle):
        """Geprüfte Empfangsdatensätze unabhängig von der Zählernummer anzeigen."""
        zeile = ANSI_FARBCODES.sub("", zeile)
        self.protokoll_ergaenzen(zeile)
        if quelle in ('USB', 'WLAN'):
            self.diagnose.status(zeile)
        paket = paket_lesen(zeile)
        if paket is None:
            return
        self.paketanzahl += 1
        zeitstempel = datetime.now().astimezone().isoformat(timespec="seconds")
        self.diagnose.paket(paket, quelle, zeitstempel)
        datensatz = (quelle, zeitstempel, paket["rssi"] if paket["rssi"] is not None else "",
                  paket["zaehlerkennung"], len(paket["hex"]) // 2, paket["hex"], paket["modus"])
        schluessel = str(self.paketanzahl)
        self.datensaetze[schluessel] = datensatz
        felder, auswertungsstatus = paket_auswerten(paket)
        self.auswertungen[schluessel] = (paket, felder, auswertungsstatus)
        self.pakettabelle.insert("", "end", iid=schluessel, values=datensatz)
        if len(self.datensaetze) > MAXIMALE_PAKETE:
            aeltester = next(iter(self.datensaetze))
            del self.datensaetze[aeltester]
            del self.auswertungen[aeltester]
            self.pakettabelle.delete(aeltester)
        self.pakettabelle.see(schluessel)
        self.statistiktext.set(f"{self.paketanzahl} Pakete seit Start dieser Sitzung · Letztes Paket: {zeitstempel} · RSSI: {datensatz[2]} dBm")
        # Die Anzeige bleibt bewusst paketbezogen: keine alten Werte mit neuen vermischen.
        self.pakettabelle.selection_set(schluessel)
        self.paket_auswaehlen()

    def paket_auswaehlen(self, _ereignis=None):
        """Die vollständigen Hexdaten der angeklickten Tabellenzeile anzeigen."""
        auswahl = self.pakettabelle.selection()
        if auswahl and auswahl[0] in self.datensaetze:
            datensatz = self.datensaetze[auswahl[0]]
            paket, felder, zustand = self.auswertungen[auswahl[0]]
            self.diagnose.details(paket)
            self.messwertstatus.set(f"{datensatz[0]} · {datensatz[1]} · Zähler {paket['transportkennung'] or datensatz[3]} · {zustand}")
            for eintrag in self.messwerttabelle.get_children():
                self.messwerttabelle.delete(eintrag)
            for feld in felder:
                self.messwerttabelle.insert("", "end", values=tuple(feld[name] for name in
                    ("bezeichnung", "wert", "einheit", "funktion", "speicher", "tarif", "untereinheit", "hinweis")))
            self.detailfeld.configure(state="normal")
            self.detailfeld.delete("1.0", "end")
            self.detailfeld.insert("end", f"{datensatz[0]} | {datensatz[1]} | {datensatz[4]} Bytes | Modus: {datensatz[6]}\n{datensatz[5]}")
            modus = str(paket['sicherheitsmodus']) if paket['sicherheitsmodus'] >= 0 else "unbekannt"
            if paket.get('adressformat') == 'Diehl Real Data':
                modus = 'kein normaler OMS-Modus (Diehl Real Data)'
            statusbyte = f"0x{paket['zaehlerstatus']:02X}" if paket['zaehlerstatus'] >= 0 else "nicht übertragen"
            self.detailfeld.insert("end", f"\n{zustand} | Sicherheitsmodus: {modus} | Zählerstatus (Rohbyte): {statusbyte}\nNutzdaten: {paket['nutzdaten_hex']}\n")
            for feld in felder:
                self.detailfeld.insert("end", f"{feld['bezeichnung']}: {feld['wert']} {feld['einheit']} | DIF/VIF {feld['dif_vif']} | Rohwert {feld['rohwert']} | {feld['hinweis']}\n")
            self.detailfeld.configure(state="disabled")

    def anzeige_leeren(self):
        """Pakete und Protokoll dieser Sitzung aus dem Arbeitsspeicher entfernen."""
        for schluessel in self.pakettabelle.get_children():
            self.pakettabelle.delete(schluessel)
        self.datensaetze.clear()
        self.auswertungen.clear()
        self.diagnose.leeren()
        for eintrag in self.messwerttabelle.get_children():
            self.messwerttabelle.delete(eintrag)
        self.messwertstatus.set("Noch kein Paket ausgewählt")
        self.paketanzahl = 0
        self.statistiktext.set("Noch keine Pakete")
        for anzeigefeld in (self.detailfeld, self.protokollfeld):
            anzeigefeld.configure(state="normal")
            anzeigefeld.delete("1.0", "end")
            anzeigefeld.configure(state="disabled")

    def csv_speichern(self):
        """Sichtbare Paketdaten mit deutscher Excel-tauglicher Trennung speichern."""
        if not self.datensaetze:
            messagebox.showinfo("Export", "Noch keine Pakete vorhanden.")
            return
        dateipfad = filedialog.asksaveasfilename(defaultextension=".csv", initialfile="funkpakete.csv",
                                          filetypes=[("CSV-Dateien", "*.csv")])
        if dateipfad:
            try:
                with open(dateipfad, "w", encoding="utf-8-sig", newline="") as ausgabedatei:
                    csv_schreiber = csv.writer(ausgabedatei, delimiter=";")
                    csv_schreiber.writerow(["Quelle", "PC-Zeit", "RSSI_dBm", "Zaehlerkennung", "Bytes", "Hex", "Modus"])
                    for datensatz in self.datensaetze.values():
                        # Textwerte sollen beim Öffnen in Excel keine Formeln auslösen.
                        csv_schreiber.writerow(["'" + wert if isinstance(wert, str) and wert.startswith(("=", "+", "-", "@")) else wert for wert in datensatz])
            except OSError as fehler:
                messagebox.showerror("Export fehlgeschlagen", str(fehler))

    def beenden(self):
        """Zeitgeber stoppen, Verbindung freigeben und anschließend das Fenster schließen."""
        self.trennen()
        self.fenster.destroy()

    def messwerte_speichern(self):
        """Alle vorhandenen Messfelder mit Paketzeit, Kennung und Auswertungsstatus exportieren."""
        if not self.datensaetze:
            messagebox.showinfo("Export", "Noch keine Pakete vorhanden.")
            return
        pfad = filedialog.asksaveasfilename(defaultextension=".csv", initialfile="messwerte.csv",
                                          filetypes=[("CSV-Dateien", "*.csv")])
        if not pfad:
            return
        try:
            with open(pfad, "w", encoding="utf-8-sig", newline="") as datei:
                schreiben = csv.writer(datei, delimiter=";")
                schreiben.writerow(["Quelle", "PC-Zeit", "Transportkennung", "Auswertung", "Sicherheitsmodus", "MAC_geprueft", "Zaehlerstatus_Rohbyte",
                                    "Messfeld", "Wert", "Einheit", "Funktion", "Speicher", "Tarif", "Untereinheit", "DIF_VIF", "Rohwert", "Hinweis"])
                for nummer, datensatz in self.datensaetze.items():
                    paket, felder, zustand = self.auswertungen[nummer]
                    # Auch Pakete ohne Messwerte bleiben als Statuszeile nachvollziehbar.
                    for feld in felder or [{}]:
                        werte = [datensatz[0], datensatz[1], paket['transportkennung'] or datensatz[3], zustand,
                                 paket['sicherheitsmodus'], paket['authentifiziert'], paket['zaehlerstatus']] + [feld.get(name, "") for name in
                                 ("bezeichnung", "wert", "einheit", "funktion", "speicher", "tarif", "untereinheit", "dif_vif", "rohwert", "hinweis")]
                        schreiben.writerow(["'" + wert if isinstance(wert, str) and wert.startswith(("=", "+", "-", "@")) else wert for wert in werte])
        except OSError as fehler:
            messagebox.showerror("Export fehlgeschlagen", str(fehler))


if __name__ == "__main__":
    hauptfenster = tk.Tk()
    Funkmonitor(hauptfenster)
    hauptfenster.mainloop()
