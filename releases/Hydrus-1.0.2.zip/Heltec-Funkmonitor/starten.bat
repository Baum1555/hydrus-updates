@echo off
setlocal
title Hydrus-Funkmonitor einrichten und starten
if not exist "%~dp0Einrichten.ps1" goto fehlt
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Einrichten.ps1"
if errorlevel 1 goto fehler
exit /b 0
:fehlt
echo Bitte zuerst das gesamte ZIP entpacken. Einrichten.ps1 fehlt.
:fehler
echo.
echo Einrichtung oder Start fehlgeschlagen. Bitte die Fehlermeldung oben beachten.
pause
exit /b 1
