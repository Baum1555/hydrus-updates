"""Startet die lokale PySide6-Oberfläche."""
from pathlib import Path
import sys
import traceback
sys.path.insert(0, str(Path(__file__).resolve().parent / "bibliotheken"))
if __name__ == "__main__":
    try:
        from desktop import starten
        sys.exit(starten())
    except Exception:
        traceback.print_exc()
        sys.exit(1)
