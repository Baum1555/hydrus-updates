#pragma once
#include <stdint.h>
// Intern verdrahteter SX1262 auf Heltec WiFi LoRa 32 V3 / V3.2.
// Kein externer CC1101 und keine Verbindungskabel zum Funkchip nötig.
// Nicht für Heltec V2, Wireless Stick oder V4 übernehmen.
constexpr uint8_t PIN_AUSWAHL = 8;    // SX1262 NSS
constexpr uint8_t PIN_TAKT = 9;       // SPI SCK
constexpr uint8_t PIN_SENDEN = 10;   // SPI MOSI, keine Funkaussendung
constexpr uint8_t PIN_LESEN = 11;    // SPI MISO
constexpr uint8_t PIN_RESET = 12;    // SX1262 NRESET
constexpr uint8_t PIN_BUSY = 13;     // SX1262 BUSY
constexpr uint8_t PIN_MELDUNG = 14;  // SX1262 DIO1
constexpr float TCXO_SPANNUNG = 1.8f;
// SSD1306-OLED (128 x 64 Pixel). Vext ist LOW-aktiv.
constexpr uint8_t PIN_OLED_SDA = 17;
constexpr uint8_t PIN_OLED_SCL = 18;
constexpr uint8_t PIN_OLED_RESET = 21;
constexpr uint8_t PIN_OLED_STROM = 36;
constexpr uint8_t OLED_ADRESSE = 0x3C;

// Eingebaute PRG-Taste, gegen Masse geschaltet.
constexpr uint8_t PIN_PRG = 0;
