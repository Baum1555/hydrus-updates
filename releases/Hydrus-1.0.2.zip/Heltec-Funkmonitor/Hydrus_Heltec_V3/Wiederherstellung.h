#pragma once
#include <Arduino.h>
#include <ArduinoJson.h>
#include <WiFi.h>
#include <WebServer.h>
#include "AccesspointZugang.h"
#include "FirmwareUpdate.h"

// Nach einem Resetfehler bleiben WLAN und signierte Datei-Updates erreichbar.
// Keine Zähler-, Journal- oder Funkdienste starten: alte Daten nicht zurückschreiben.
class Wiederherstellung {
 public:
  bool aktiv=false;
  bool starten(const char *grund){
    aktiv=true;fehler=grund;
    AccesspointZugang zugang;WiFi.persistent(false);WiFi.mode(WIFI_AP);
    WiFi.softAPConfig(IPAddress(192,168,4,1),IPAddress(192,168,4,1),IPAddress(255,255,255,0));
    const String name=zugang.nameLaden(),passwort=zugang.laden();
    const bool ok=WiFi.softAP(name.c_str(),passwort.c_str());
    char zufall[17];snprintf(zufall,sizeof(zufall),"%08lx%08lx",(unsigned long)esp_random(),(unsigned long)esp_random());token=zufall;
    const char *header[]={"X-Hydrus-Token"};http.collectHeaders(header,1);
    http.on("/",HTTP_GET,[this](){http.sendHeader("Cache-Control","no-store");http.send_P(200,"text/html; charset=utf-8",seite);});
    http.on("/status",HTTP_GET,[this](){JsonDocument d;d["token"]=token;d["fehler"]=fehler;d["meldung"]=update.meldung;String s;serializeJson(d,s);http.sendHeader("Cache-Control","no-store");http.send(200,"application/json",s);});
    http.on("/erneut",HTTP_POST,[this](){if(!erlaubt())return;if(Update.isRunning()){http.send(409,"text/plain","Update laeuft");return;}http.send(200,"text/plain","Neustart und erneuter Resetversuch");neustart=millis()+1000;});
    http.on("/update",HTTP_POST,[this](){if(!erlaubt())return;http.send(update.fertig?200:400,"text/plain; charset=utf-8",update.meldung);},[this](){
      auto &u=http.upload();
      if(u.status==UPLOAD_FILE_START){uploadErlaubt=http.header("X-Hydrus-Token")==token;if(uploadErlaubt)update.anfang();}
      if(!uploadErlaubt)return;
      if(u.status==UPLOAD_FILE_WRITE)update.daten(u.buf,u.currentSize);
      if(u.status==UPLOAD_FILE_END)update.ende();
      if(u.status==UPLOAD_FILE_ABORTED)update.abbrechen("Upload abgebrochen");
    });
    http.begin();return ok;
  }
  void pflegen(){http.handleClient();update.pflegen();if(neustart&&int32_t(millis()-neustart)>=0)ESP.restart();}
 private:
  WebServer http{80};FirmwareUpdate update;String fehler,token;bool uploadErlaubt=false;uint32_t neustart=0;
  bool erlaubt(){if(http.header("X-Hydrus-Token")!=token){http.send(403,"text/plain","Seite neu laden");return false;}return true;}
  static constexpr const char *seite=R"RESET(<!doctype html><html lang="de"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>HYDRUS Wiederherstellung</title><style>body{font:16px system-ui;background:#eff5f4;color:#173b44;max-width:640px;margin:40px auto;padding:20px}button,input{font:inherit;padding:12px;max-width:100%;box-sizing:border-box}button{background:#087f78;color:white;border:0;border-radius:8px}p{line-height:1.6}</style><h1>Wiederherstellung</h1><p>Der Werksreset wurde nicht abgeschlossen.</p><p id="grund"></p><button id="erneut">Reset erneut versuchen</button><h2>Firmware aktualisieren</h2><form id="formular"><input id="datei" type="file" accept=".hup" required><p><button>Update-Datei installieren</button></p></form><p id="meldung" role="status"></p><script>let token='';const m=document.getElementById('meldung');fetch('/status',{cache:'no-store'}).then(r=>r.json()).then(d=>{token=d.token;document.getElementById('grund').textContent=d.fehler}).catch(()=>m.textContent='Seite neu laden');async function senden(url,body){if(!token){m.textContent='Seite neu laden';return}document.querySelectorAll('button').forEach(b=>b.disabled=true);m.textContent='Bitte warten …';try{const r=await fetch(url,{method:'POST',headers:{'X-Hydrus-Token':token},body});m.textContent=await r.text()}catch(e){m.textContent='Verbindung unterbrochen. Nach dem Neustart erneut verbinden.'}finally{document.querySelectorAll('button').forEach(b=>b.disabled=false)}}document.getElementById('erneut').onclick=()=>senden('/erneut');document.getElementById('formular').onsubmit=e=>{e.preventDefault();const b=new FormData();b.append('datei',document.getElementById('datei').files[0]);senden('/update',b)};</script></html>)RESET";
};
