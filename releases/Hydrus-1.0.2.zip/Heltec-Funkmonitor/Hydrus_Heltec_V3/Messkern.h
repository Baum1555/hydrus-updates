#pragma once
#include <cmath>
#include <cstdint>
#include <cstring>
struct Grundwerte { double volumen=NAN,fluss=NAN; };
// Momentanwerte ohne Speicher-/Tarif-/Geräteauswahl. Erst nach erfolgreicher Entschlüsselung aufrufen.
inline Grundwerte grundwerte(const uint8_t *a,size_t n) {
  Grundwerte r;size_t i=0;
  while(i<n) {
    uint8_t d=a[i++];if(d==0x2F)continue;if((d&15)==15)return {};
    bool aktuell=(d&0x70)==0;uint8_t alt=d;int count=0;
    while(alt&128){if(i>=n||++count>10)return {};alt=a[i++];if(alt&127)aktuell=false;}
    if(i>=n)return {};uint8_t v=a[i++];alt=v;count=0;
    while(alt&128){if(i>=n||++count>10)return {};alt=a[i++];aktuell=false;}
    const uint8_t k=d&15;static const int lens[]={0,1,2,3,4,4,6,8,0,1,2,3,4,-1,6,-1};
    int l=lens[k];if(l<0 || i+l>n)return {};
    double wert=NAN;
    if(aktuell && !(v&128) && l) {
      if(k==5){float f;memcpy(&f,a+i,4);wert=f;}
      else if(k<=7){uint64_t u=0;for(int j=l-1;j>=0;--j)u=(u<<8)|a[i+j];
        if(a[i+l-1]&128){uint64_t maske=l==8?UINT64_MAX:((uint64_t(1)<<(l*8))-1);wert=-double(((~u)&maske)+1);}else wert=double(u);}
      else if(k>=9){wert=0;double faktor=1;for(int j=0;j<l;++j){uint8_t b=a[i+j];if((b&15)>9||(b>>4)>9){wert=NAN;break;}wert+=(b&15)*faktor+(b>>4)*faktor*10;faktor*=100;}}
      if(std::isfinite(wert)&&wert>=0) {
        if(v>=0x10&&v<=0x17)r.volumen=wert*pow(10,int(v)-0x16);
        if(v>=0x38&&v<=0x3F)r.fluss=wert*pow(10,int(v)-0x3E)*1000/60;
        if(v>=0x40&&v<=0x47)r.fluss=wert*pow(10,int(v)-0x47)*1000;
        if(v>=0x48&&v<=0x4F)r.fluss=wert*pow(10,int(v)-0x51)*60000;
      }
    }
    i+=l;
  }
  return r;
}
