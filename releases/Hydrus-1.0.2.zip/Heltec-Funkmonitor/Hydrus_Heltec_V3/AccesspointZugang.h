#pragma once
#include <Arduino.h>
#include <Preferences.h>
#include "WlanZugang.h"

// Name und Passwort gemeinsam speichern: kein halbfertiges Zugangspaar bei Stromausfall.
class AccesspointZugang {
  struct Zugang {char name[33]={};char passwort[64]={};};
  Zugang lesen(){
    Zugang z{};Preferences nvs;
    if(nvs.begin("hydrus-ap",true)){
      if(nvs.getBytesLength("zugang")==sizeof(z))nvs.getBytes("zugang",&z,sizeof(z));
      else {String alt=nvs.getString("passwort");if(gueltig(alt))strlcpy(z.passwort,alt.c_str(),sizeof(z.passwort));}
      nvs.end();
    }
    z.name[32]=0;z.passwort[63]=0;
    if(!nameGueltig(z.name))strlcpy(z.name,WLAN_NAME,sizeof(z.name));
    if(!gueltig(z.passwort))strlcpy(z.passwort,WLAN_PASSWORT,sizeof(z.passwort));
    return z;
  }
 public:
  static bool gueltig(const String &s){if(s.length()<8||s.length()>63)return false;for(char c:s)if((unsigned char)c<32||(unsigned char)c>126)return false;return true;}
  static bool nameGueltig(const String &s){
    if(!s.length()||s.length()>32)return false;
    bool sichtbar=false;for(char c:s){if((unsigned char)c<32||(unsigned char)c==127)return false;if(c!=' ')sichtbar=true;}
    return sichtbar;
  }
  String laden(){return String(lesen().passwort);}
  String nameLaden(){return String(lesen().name);}
  bool speichern(const String &passwort){return speichern(nameLaden(),passwort);}
  bool speichern(const String &name,const String &passwort){
    if(!nameGueltig(name)||!gueltig(passwort))return false;
    Zugang z{};strlcpy(z.name,name.c_str(),sizeof(z.name));strlcpy(z.passwort,passwort.c_str(),sizeof(z.passwort));
    Preferences nvs;if(!nvs.begin("hydrus-ap",false))return false;
    bool ok=nvs.putBytes("zugang",&z,sizeof(z))==sizeof(z);nvs.end();return ok;
  }
};
