#pragma once
// Reine Suchparameter und Befehlsprüfung, unabhängig von der Hardware testbar.
#include <stdint.h>
#include <stddef.h>
#include <string.h>
namespace FunkSuche {
constexpr uint32_t STANDARD_HZ = 868950000;
constexpr uint32_t UNTERGRENZE_HZ = 863000000;
constexpr uint32_t OBERGRENZE_HZ = 870000000;
constexpr uint32_t SCHRITT_HZ = 100000;
constexpr size_t PUNKTE = (OBERGRENZE_HZ - UNTERGRENZE_HZ) / SCHRITT_HZ + 1;
constexpr uint8_t DURCHGAENGE = 4;
enum class Art : uint8_t { EMPFANG, SCAN };
struct Auftrag { Art art; uint32_t frequenz; };

inline uint32_t frequenz(size_t punkt) { return UNTERGRENZE_HZ + punkt * SCHRITT_HZ; }
inline bool befehlLesen(const char *text, Auftrag &auftrag) {
  if (!strcmp(text, "SCAN")) { auftrag = {Art::SCAN, STANDARD_HZ}; return true; }
  if (!strcmp(text, "STOP") || !strcmp(text, "TC")) {
    auftrag = {Art::EMPFANG, STANDARD_HZ}; return true;
  }
  if (strncmp(text, "FREQ ", 5)) return false;
  // Genau neun Dezimalziffern: weder Überlauf noch nachgestellte Befehle zulassen.
  if (strlen(text + 5) != 9) return false;
  uint32_t wert = 0;
  for (size_t index = 5; index < 14; ++index) {
    if (text[index] < '0' || text[index] > '9') return false;
    wert = wert * 10 + text[index] - '0';
  }
  if (wert < UNTERGRENZE_HZ || wert > OBERGRENZE_HZ) return false;
  auftrag = {Art::EMPFANG, wert};
  return true;
}
}
