#pragma once
// Begrenztes Flash-Journal: letzter Empfang alle fünf Minuten je eigenem Zähler.
// Keine Schlüssel/Zugangsdaten im Journal, nur dieselben Pakete wie in der Anzeige.
#include <LittleFS.h>
#include <time.h>
#include "ZaehlerSchluessel.h"

class VerlaufSpeicher {
 public:
  String fehler;
  bool (*zulaessig)(const String&)=nullptr;
  uint32_t startkennung = 0;
  bool bereit = false;
  void starten() {
    startkennung = esp_random();
    // Niemals automatisch formatieren: vorhandene Messdaten bleiben bei Fehlern erhalten.
    bereit = LittleFS.begin(false);
    if (!bereit) { fehler="Speicher nicht eingerichtet. Unter WLAN & Speicher initialisieren."; return; }
    fehler="";
    suchen();
  }
  bool initialisieren() {
    // Nur bei fehlgeschlagenem Mount, mit ausdrücklicher Bestätigung im Webportal.
    if (bereit) return false;
    if (!LittleFS.format()) { fehler="Formatieren fehlgeschlagen"; return false; }
    starten(); return bereit;
  }
  void merken(const String &id, const String &json) {
    bool eigen=false;
    for(const auto &s:ZAEHLER_SCHLUESSEL) if(id==s.kennung) eigen=true;
    if(zulaessig)eigen=zulaessig(id);
    if(!eigen || json.length()>4096) return;
    for(auto &p:puffer) if(p.id==id || !p.id.length()) {
      p.id=id; p.json=json; p.empfang=millis(); p.zeit=time(nullptr);
      p.neu=true; return;
    }
  }
  void pflegen() {
    if(!bereit) return;
    for(auto &p:puffer) if(p.neu && (!p.geschrieben || uint32_t(millis()-p.zuletzt)>=300000)) {
      const String datensatz="{\"boot\":"+String(startkennung)+",\"laufzeit_ms\":"+String(p.empfang)+
        ",\"zeit\":"+(p.zeit>1700000000?String((unsigned long)p.zeit):String("null"))+
        ",\"paket\":"+p.json+"}";
      if(schreiben(datensatz)) { p.neu=false; p.geschrieben=true; p.zuletzt=millis(); }
      else { p.zuletzt=millis(); p.geschrieben=true; } // Bei Fehlern nicht in enger Schleife schreiben.
    }
  }
  size_t bytes() { size_t n=0; for(size_t i=0;i<anzahl;++i) { File f=LittleFS.open(pfad(nummern[i]),"r"); if(f)n+=f.size(); } return n; }
  void senden(WebServer &http) {
    if(!bereit) { http.send(503,"text/plain",fehler); return; }
    http.sendHeader("Cache-Control","no-store");
    http.sendHeader("Content-Disposition","attachment; filename=hydrus-verlauf.jsonl");
    http.setContentLength(CONTENT_LENGTH_UNKNOWN);
    http.send(200,"application/x-ndjson","");
    char block[1024];
    for(size_t i=0;i<anzahl;++i) {
      File f=LittleFS.open(pfad(nummern[i]),"r");
      if(!f) continue;
      while(f.available()) { const size_t n=f.readBytes(block,sizeof(block)); if(!n)break; http.sendContent(block,n); }
      http.sendContent("\n"); // Unvollständiges Ende niemals mit nächster Datei verbinden.
    }
    http.sendContent("");
  }
 private:
  struct Empfang { String id,json; uint32_t empfang=0,zuletzt=0; time_t zeit=0; bool neu=false,geschrieben=false; } puffer[8];
  uint32_t nummern[8]={}; size_t anzahl=0;
  static String pfad(uint32_t n) { return "/verlauf-"+String(n)+".jsonl"; }
  void suchen() {
    anzahl=0;
    File wurzel=LittleFS.open("/");
    for(File f=wurzel.openNextFile();f;f=wurzel.openNextFile()) {
      String name=f.name(); if(name.startsWith("/"))name.remove(0,1);
      if(!name.startsWith("verlauf-") || !name.endsWith(".jsonl"))continue;
      String z=name.substring(8,name.length()-6); bool gueltig=z.length()>0 && z.length()<10;
      for(size_t i=0;i<z.length();++i)if(z[i]<'0'||z[i]>'9')gueltig=false;
      if(!gueltig)continue;
      uint32_t n=z.toInt(); if(!n)continue;
      if(anzahl<8) nummern[anzahl++]=n;
      else if(n>nummern[0]) { LittleFS.remove(pfad(nummern[0])); nummern[0]=n; }
      else { LittleFS.remove(pfad(n)); continue; }
      for(size_t i=0;i<anzahl;++i)for(size_t j=i+1;j<anzahl;++j)if(nummern[j]<nummern[i]) { uint32_t t=nummern[i];nummern[i]=nummern[j];nummern[j]=t; }
    }
  }
  bool schreiben(const String &text) {
    uint32_t n=anzahl?nummern[anzahl-1]:1;
    File alt=LittleFS.open(pfad(n),"r");
    const bool drehen=alt && alt.size()+text.length()+2>65536; alt.close();
    if(drehen)++n;
    if(!anzahl || drehen) {
      // Platz vor dem Anlegen freigeben; höchstens ein ältestes Segment entfällt.
      if(anzahl==8) {
        if(!LittleFS.remove(pfad(nummern[0]))) { fehler="Altes Segment konnte nicht entfernt werden"; return false; }
        for(size_t i=1;i<anzahl;++i)nummern[i-1]=nummern[i]; --anzahl;
      }
      nummern[anzahl++]=n;
    }
    File f=LittleFS.open(pfad(n),"a");
    if(!f) { fehler="Verlauf konnte nicht geöffnet werden"; return false; }
    // Vorheriger Schreibvorgang kann durch Stromausfall abgebrochen sein.
    const String zeile="\n"+text+"\n";
    bool ok=f.print(zeile)==zeile.length(); f.flush(); f.close();
    fehler=ok?"":"Speicher voll oder Schreibfehler"; return ok;
  }
};
