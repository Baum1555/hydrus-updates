#pragma once
// Gemeinsame USB-/WLAN-Ausgabe und Befehlsprüfung.
void paketAusgeben(const Empfangsmeldung &meldung) {
  const auto &telegramm = meldung.telegramm;
  char hex[Funktelegramm::MAX_NUTZBYTES * 2 + 1];
  const char ziffern[] = "0123456789ABCDEF";
  for (size_t stelle = 0; stelle < telegramm.laenge; ++stelle) {
    hex[stelle * 2] = ziffern[telegramm.daten[stelle] >> 4];
    hex[stelle * 2 + 1] = ziffern[telegramm.daten[stelle] & 15];
  }
  hex[telegramm.laenge * 2] = '\0';
  // Standardadresse oder besondere Diehl-Real-Data-Anordnung anhand des Kopfes.
  // Die optionale OMS-Transportadresse wird anschliessend separat ermittelt.
  const auto kopf = ZaehlerAdresse::lesen(telegramm.daten, telegramm.laenge);
  const char *kennung = kopf.kennung;
  // Entschlüsselung läuft hier außerhalb der zeitkritischen Funk-Empfangsaufgabe.
  // Der Schlüssel selbst wird niemals über USB oder WLAN ausgegeben.
  ZaehlerSchluessel schluesselListe[8];Geraete.liste(schluesselListe);
  const auto auswertung = Oms::auswerten(telegramm.daten, telegramm.laenge,
      schluesselListe, 8);
  Geraete.pruefergebnis(auswertung.kennung[0]?auswertung.kennung:kennung,auswertung.zustand);
  Grundwerte werte;
  if(!strcmp(auswertung.zustand,"REAL_DATA_DEKODIERT")||!strcmp(auswertung.zustand,"UNVERSCHLUESSELT")||(!strcmp(auswertung.zustand,"ENTSCHLUESSELT")&&(auswertung.sicherheitsmodus!=7||auswertung.authentifiziert)))werte=grundwerte(auswertung.daten,auswertung.laenge);
  Auswertung.empfangen(kennung,werte);
  JsonDocument meta;Auswertung.json(meta.to<JsonArray>());String geraetestatus="null";
  for(JsonObject o:meta.as<JsonArray>())if(String(o["id"].as<const char*>())==kennung){geraetestatus="";serializeJson(o,geraetestatus);break;}
  char nutzdaten[513];
  for (size_t stelle = 0; stelle < auswertung.laenge; ++stelle) {
    nutzdaten[stelle * 2] = ziffern[auswertung.daten[stelle] >> 4];
    nutzdaten[stelle * 2 + 1] = ziffern[auswertung.daten[stelle] & 15];
  }
  nutzdaten[auswertung.laenge * 2] = '\0';
  Ausgabe.printf("WMBUS {\"hex\":\"%s\",\"rssi\":%d,\"modus\":\"%c1\",\"zaehlerkennung\":\"%s\",\"format\":\"%c\","
                "\"auswertung\":\"%s\",\"sicherheitsmodus\":%d,\"transportkennung\":\"%s\","
                "\"zaehlerstatus\":%d,\"authentifiziert\":%s,\"nutzdaten_hex\":\"%s\",\"frequenz_hz\":%lu,\"crc_geprueft\":true,\"geraetestatus\":%s}\n",
                hex, meldung.signalstaerke, telegramm.modus, kennung, telegramm.format,
                auswertung.zustand, auswertung.sicherheitsmodus, auswertung.kennung,
                auswertung.zaehlerstatus, auswertung.authentifiziert ? "true" : "false", nutzdaten,
                static_cast<unsigned long>(meldung.frequenz),geraetestatus.c_str());
}

void befehleLesen(Stream &eingang, BefehlsPuffer &puffer) {
  // Begrenzter Zeilenpuffer. Zu lange Eingaben vollständig bis Zeilenende verwerfen.
  auto &zeile = puffer.zeile;
  auto &laenge = puffer.laenge;
  auto &ueberlang = puffer.ueberlang;
  for (int schritt = 0; schritt < 64 && eingang.available(); ++schritt) {
    char zeichen = eingang.read();
    if (zeichen == '\r') continue;
    if (zeichen == '\n') {
      zeile[laenge] = 0;
      FunkSuche::Auftrag auftrag;
      bool gut = empfaengerBereit && befehlswarteschlange && !ueberlang && FunkSuche::befehlLesen(zeile, auftrag) &&
                 xQueueSend(befehlswarteschlange, &auftrag, 0) == pdTRUE;
      Ausgabe.println(gut ? "ANTWORT Auftrag angenommen; Umsetzung folgt in der Empfangsaufgabe."
                         : "ANTWORT Befehl ungueltig oder Warteschlange voll.");
      laenge = 0; ueberlang = false;
    } else if (laenge + 1 < sizeof(zeile) && !ueberlang) zeile[laenge++] = zeichen;
    else ueberlang = true;
  }
}
