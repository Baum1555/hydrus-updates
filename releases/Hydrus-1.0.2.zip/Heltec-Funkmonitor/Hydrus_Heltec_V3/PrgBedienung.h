#pragma once
#include <stdint.h>

// Entprellte Gesten ohne delay(). Zeitdifferenzen funktionieren auch beim millis()-Überlauf.
class PrgBedienung {
 public:
  enum Aktion { Keine, Kurz, Doppelt, Lang, Werkreset };
  void starten(bool pegel, uint32_t jetzt) {
    roh=stabil=pegel; wechsel=jetzt; druck=false; wartet=false; langGemeldet=false;resetGemeldet=false;
  }
  Aktion pflegen(bool pegel, uint32_t jetzt) {
    if(pegel!=roh){roh=pegel;wechsel=jetzt;}
    if(roh!=stabil && uint32_t(jetzt-wechsel)>=35){
      stabil=roh;
      if(!stabil){druck=true;gedrueckt=jetzt;langGemeldet=false;resetGemeldet=false;}
      else if(druck){
        druck=false;
        // Ein abgebrochenes Halten ist kein kurzer Tastendruck.
        if(!langGemeldet && uint32_t(jetzt-gedrueckt)<600){
          if(wartet && uint32_t(gedrueckt-losgelassen)<=350){wartet=false;return Doppelt;}
          wartet=true;losgelassen=jetzt;
        }else wartet=false;
      }
    }
    if(druck && uint32_t(jetzt-gedrueckt)>=600)wartet=false;
    if(druck && !langGemeldet && uint32_t(jetzt-gedrueckt)>=3000){
      langGemeldet=true;return Lang;
    }
    if(druck && !resetGemeldet && uint32_t(jetzt-gedrueckt)>=10000){resetGemeldet=true;return Werkreset;}
    // Erst nach Ablauf des Doppelklickfensters den Zähler wechseln.
    if(wartet && !druck && roh && uint32_t(jetzt-losgelassen)>350){wartet=false;return Kurz;}
    return Keine;
  }
  bool fortschritt(uint32_t jetzt) const {return druck && !langGemeldet && uint32_t(jetzt-gedrueckt)>=600;}
  uint8_t prozent(uint32_t jetzt) const {uint32_t dauer=uint32_t(jetzt-gedrueckt);return dauer>=3000?100:uint8_t(dauer/30);}
  bool istLosgelassen() const {return !druck && stabil && roh;}
  bool resetFortschritt(uint32_t jetzt) const {return druck && !resetGemeldet && uint32_t(jetzt-gedrueckt)>=4000;}
  uint8_t resetProzent(uint32_t jetzt) const {uint32_t d=uint32_t(jetzt-gedrueckt);return d>=10000?100:uint8_t(d/100);}
 private:
  bool roh=true,stabil=true,druck=false,wartet=false,langGemeldet=false,resetGemeldet=false;
  uint32_t wechsel=0,gedrueckt=0,losgelassen=0;
};
