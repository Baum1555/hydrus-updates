#pragma once
// Lokale OMS-Auswertung nach OMS Vol. 2: keine WLAN-/ESPHome-Abhängigkeit.
// Unterstützt unfragmentierte TPL-Telegramme mit CI 72/7A/78, Modus 0/5/7.
// Modus 7: KDF=1, Schlüssel-ID=0, AFL mit 8-Byte-CMAC, Prüfung VOR Entschlüsselung.
// Andere Varianten werden ausdrücklich gemeldet und niemals als Klartext ausgegeben.
#include <stdint.h>
#include <stddef.h>
#include <string.h>
#include <stdio.h>
#include "mbedtls/aes.h"
#include "Funktelegramm.h"
#include "ZaehlerSchluessel.h"
#include "ZaehlerAdresse.h"

namespace Oms {
struct Auswertung {
  const char *zustand = "KOPF_UNGUELTIG";
  int sicherheitsmodus = -1;
  int zaehlerstatus = -1;
  bool authentifiziert = false;
  char kennung[9] = {};
  uint8_t daten[256] = {};
  size_t laenge = 0;
};

inline int hexZiffer(char zeichen) {
  if (zeichen >= '0' && zeichen <= '9') return zeichen - '0';
  if (zeichen >= 'a' && zeichen <= 'f') return zeichen - 'a' + 10;
  if (zeichen >= 'A' && zeichen <= 'F') return zeichen - 'A' + 10;
  return -1;
}

// Rückgabe: 0 = fehlt, 1 = gefunden, -1 = ungültig/mehrdeutig konfiguriert.
inline int schluesselSuchen(const char *kennung, const ZaehlerSchluessel *liste,
                            size_t anzahl, uint8_t *schluessel) {
  const char *text = nullptr;
  for (size_t index = 0; index < anzahl; ++index) {
    if (strcmp(kennung, liste[index].kennung) != 0) continue;
    if (text != nullptr) return -1;
    text = liste[index].aesHex;
  }
  if (!text || !text[0]) return 0;
  if (strlen(text) != 32) return -1;
  for (size_t index = 0; index < 16; ++index) {
    int oben = hexZiffer(text[2 * index]), unten = hexZiffer(text[2 * index + 1]);
    if (oben < 0 || unten < 0) return -1;
    schluessel[index] = static_cast<uint8_t>((oben << 4) | unten);
  }
  return 1;
}

inline void verdoppeln(const uint8_t *quelle, uint8_t *ziel) {
  // CMAC-Unterschlüssel nach RFC 4493: Linksverschiebung im GF(2^128).
  uint8_t uebertrag = 0;
  for (int index = 15; index >= 0; --index) {
    uint8_t wert = quelle[index];
    ziel[index] = static_cast<uint8_t>((wert << 1) | uebertrag);
    uebertrag = wert >> 7;
  }
  if (uebertrag) ziel[15] ^= 0x87;
}

inline bool cmac(const uint8_t *schluessel, const uint8_t *daten, size_t laenge,
                 uint8_t *pruefwert) {
  mbedtls_aes_context aes;
  mbedtls_aes_init(&aes);
  uint8_t nullblock[16] = {}, erster[16], zweiter[16], laufend[16] = {};
  bool gut = mbedtls_aes_setkey_enc(&aes, schluessel, 128) == 0 &&
             mbedtls_aes_crypt_ecb(&aes, MBEDTLS_AES_ENCRYPT, nullblock, erster) == 0;
  if (gut) {
    verdoppeln(erster, erster);
    verdoppeln(erster, zweiter);
    size_t bloecke = (laenge + 15) / 16;
    if (!bloecke) bloecke = 1;
    for (size_t block = 0; block < bloecke && gut; ++block) {
      uint8_t eingabe[16] = {};
      size_t offset = block * 16;
      size_t rest = laenge > offset ? laenge - offset : 0;
      size_t kopieren = rest < 16 ? rest : 16;
      if (kopieren) memcpy(eingabe, daten + offset, kopieren);
      if (block + 1 == bloecke) {
        bool voll = kopieren == 16;
        if (!voll) eingabe[kopieren] = 0x80;
        for (int index = 0; index < 16; ++index) eingabe[index] ^= voll ? erster[index] : zweiter[index];
      }
      for (int index = 0; index < 16; ++index) eingabe[index] ^= laufend[index];
      gut = mbedtls_aes_crypt_ecb(&aes, MBEDTLS_AES_ENCRYPT, eingabe, laufend) == 0;
    }
    if (gut) memcpy(pruefwert, laufend, 16);
  }
  mbedtls_aes_free(&aes);
  return gut;
}

inline bool cbcEntschluesseln(const uint8_t *schluessel, uint8_t *iv,
                              const uint8_t *quelle, size_t laenge, uint8_t *ziel) {
  mbedtls_aes_context aes;
  mbedtls_aes_init(&aes);
  bool gut = mbedtls_aes_setkey_dec(&aes, schluessel, 128) == 0;
  if (gut) gut = mbedtls_aes_crypt_cbc(&aes, MBEDTLS_AES_DECRYPT, laenge, iv, quelle, ziel) == 0;
  mbedtls_aes_free(&aes);
  return gut;
}

inline void kennungLesen(const uint8_t *adresse, char *ziel) {
  snprintf(ziel, 9, "%02X%02X%02X%02X", adresse[3], adresse[2], adresse[1], adresse[0]);
}

// Diehl Real Data verwendet einen LFSR-Datenstrom, nicht OMS-AES-CBC.
// Verfahrensreferenz: wmbusmeters/src/manufacturer_specificities.cc
// Nur explizit hinterlegte Schluessel verwenden; keine Standardschluessel versuchen.
inline uint32_t wortGrossEndian(const uint8_t *p) {
  return (uint32_t(p[0]) << 24) | (uint32_t(p[1]) << 16) | (uint32_t(p[2]) << 8) | p[3];
}

inline Auswertung realDataAuswerten(const uint8_t *paket, size_t laenge,
                                   const ZaehlerSchluessel *liste, size_t anzahl) {
  Auswertung ergebnis;
  const auto kopf = ZaehlerAdresse::lesen(paket, laenge);
  memcpy(ergebnis.kennung, kopf.kennung, sizeof(ergebnis.kennung));
  ergebnis.zustand = "REAL_DATA_FORMAT_NICHT_UNTERSTUETZT";
  // Alarmtelegramme (CI 71) nicht wie normale Messwerttelegramme interpretieren.
  if (!kopf.realData || paket[10] != 0x7A || laenge <= 15) return ergebnis;
  uint8_t schluessel[16] = {};
  const int gefunden = schluesselSuchen(ergebnis.kennung, liste, anzahl, schluessel);
  if (gefunden != 1) {
    ergebnis.zustand = gefunden == 0 ? "REAL_DATA_SCHLUESSEL_FEHLT" : "SCHLUESSEL_UNGUELTIG";
    return ergebnis;
  }
  // Wie in der Referenz: XOR der ersten beiden 32-Bit-Woerter des Schluessels.
  uint32_t registerwert = wortGrossEndian(schluessel) ^ wortGrossEndian(schluessel + 4);
  memset(schluessel, 0, sizeof(schluessel));
  // Originale Funkadresse benutzen, noch vor der Diehl-Adressumordnung.
  registerwert ^= wortGrossEndian(paket + 2) ^ wortGrossEndian(paket + 6) ^ wortGrossEndian(paket + 10);
  uint32_t summe = 0;
  const size_t inhaltslaenge = laenge - 15;
  for (size_t stelle = 0; stelle < inhaltslaenge; ++stelle) {
    for (uint8_t bit = 0; bit < 8; ++bit) {
      const uint32_t neu = ((registerwert >> 1) ^ (registerwert >> 2) ^
                            (registerwert >> 11) ^ (registerwert >> 31)) & 1u;
      registerwert = (registerwert << 1) | neu;
    }
    ergebnis.daten[stelle] = paket[15 + stelle] ^ static_cast<uint8_t>(registerwert);
    summe += ergebnis.daten[stelle];
  }
  // Diese kurze Pruefsumme ist KEINE kryptografische Authentifizierung!
  if ((summe & 0xEFu) != (paket[14] & 0xEFu)) {
    memset(ergebnis.daten, 0, sizeof(ergebnis.daten));
    ergebnis.zustand = "REAL_DATA_PRUEFSUMME_FALSCH";
    return ergebnis;
  }
  ergebnis.laenge = inhaltslaenge;
  ergebnis.zustand = "REAL_DATA_DEKODIERT";
  return ergebnis;
}

inline Auswertung auswerten(const uint8_t *paket, size_t laenge,
                            const ZaehlerSchluessel *liste, size_t anzahl) {
  Auswertung ergebnis;
  if (laenge < 11 || laenge > 256 || paket[0] + 1u != laenge) return ergebnis;
  const auto kopf = ZaehlerAdresse::lesen(paket, laenge);
  if (kopf.realData) {
    return realDataAuswerten(paket, laenge, liste, anzahl);
  }
  uint8_t adresse[8]; // Hersteller (2), Identnummer (4), Version, Medium.
  memcpy(adresse, paket + 2, 8);
  kennungLesen(adresse + 2, ergebnis.kennung);
  size_t stelle = 10;
  // Erweiterte Link-Schicht: unverschlüsselte ELL I bis IV unterstützen.
  if (paket[stelle] >= 0x8C && paket[stelle] <= 0x8F) {
    uint8_t ell = paket[stelle++];
    size_t kopflaenge = 2 + ((ell == 0x8E || ell == 0x8F) ? 8 : 0);
    if (stelle + kopflaenge >= laenge) return ergebnis;
    stelle += kopflaenge;
    if (ell == 0x8D || ell == 0x8F) {
      if (stelle + 6 >= laenge) return ergebnis;
      if ((paket[stelle + 3] >> 5) != 0) {
        ergebnis.zustand = "ELL_VERSCHLUESSELUNG_NICHT_UNTERSTUETZT"; return ergebnis;
      }
      stelle += 4;
      uint16_t soll = paket[stelle] | (uint16_t(paket[stelle + 1]) << 8);
      stelle += 2;
      if (Funktelegramm::pruefsumme(paket + stelle, laenge - stelle) != soll) {
        ergebnis.zustand = "ELL_PRUEFSUMME_FALSCH"; return ergebnis;
      }
    }
  }

  bool afl = false;
  uint8_t zaehler[4] = {}, mac[8] = {};
  if (paket[stelle] == 0x90) {
    // Bewusst nur vollständige Einzeltelegramme, keine Fragment-Zusammensetzung.
    if (stelle + 17 >= laenge) return ergebnis;
    if (paket[stelle + 1] != 15 || paket[stelle + 2] != 0 ||
        paket[stelle + 3] != 0x2C || paket[stelle + 4] != 0x25) {
      ergebnis.zustand = "AFL_VARIANTE_NICHT_UNTERSTUETZT"; return ergebnis;
    }
    memcpy(zaehler, paket + stelle + 5, 4);
    memcpy(mac, paket + stelle + 9, 8);
    stelle += 17;
    afl = true;
  }

  const size_t transportanfang = stelle;
  uint8_t ci = paket[stelle++];
  uint8_t zugriff = 0;
  uint16_t konfiguration = 0;
  if (ci == 0x72) {
    if (stelle + 12 > laenge) return ergebnis;
    // Beim langen Header zählt die Transportadresse statt der Funkadapteradresse.
    memcpy(adresse, paket + stelle + 4, 2);
    memcpy(adresse + 2, paket + stelle, 4);
    memcpy(adresse + 6, paket + stelle + 6, 2);
    kennungLesen(adresse + 2, ergebnis.kennung);
    stelle += 8;
  } else if (ci != 0x7A && ci != 0x78) {
    ergebnis.zustand = "TRANSPORTFORMAT_NICHT_UNTERSTUETZT"; return ergebnis;
  }
  if (ci != 0x78) {
    if (stelle + 4 > laenge) return ergebnis;
    zugriff = paket[stelle];
    ergebnis.zaehlerstatus = paket[stelle + 1];
    konfiguration = paket[stelle + 2] | (uint16_t(paket[stelle + 3]) << 8);
    stelle += 4;
  }
  int modus = (konfiguration >> 8) & 31;
  ergebnis.sicherheitsmodus = modus;
  // Der Inhaltsindex (Bits 0..2) ändert nicht die DIF/VIF-Codierung.
  // Andere Padding-Verfahren und das reservierte Zählergrößenbit bleiben offen.
  if (modus == 7 && (konfiguration & 0x2008)) {
    ergebnis.zustand = "INHALTSFORMAT_NICHT_UNTERSTUETZT"; return ergebnis;
  }
  if (modus == 0) {
    if (afl) { ergebnis.zustand = "AFL_VARIANTE_NICHT_UNTERSTUETZT"; return ergebnis; }
    ergebnis.zustand = "UNVERSCHLUESSELT";
    ergebnis.laenge = laenge - stelle;
    memcpy(ergebnis.daten, paket + stelle, ergebnis.laenge);
    return ergebnis;
  }
  if (modus != 5 && modus != 7) {
    ergebnis.zustand = "SICHERHEITSMODUS_NICHT_UNTERSTUETZT"; return ergebnis;
  }
  if (modus == 7) {
    if (stelle >= laenge) return ergebnis;
    if (!afl || paket[stelle++] != 0x10) {
      ergebnis.zustand = "MODUS7_VARIANTE_NICHT_UNTERSTUETZT"; return ergebnis;
    }
  } else if (afl) {
    ergebnis.zustand = "AFL_VARIANTE_NICHT_UNTERSTUETZT"; return ergebnis;
  }
  uint8_t schluessel[16] = {}, iv[16] = {};
  int vorhanden = schluesselSuchen(ergebnis.kennung, liste, anzahl, schluessel);
  if (vorhanden != 1) {
    ergebnis.zustand = vorhanden == 0 ? "SCHLUESSEL_FEHLT" : "SCHLUESSELFORMAT_UNGUELTIG";
    return ergebnis;
  }
  if (modus == 5) {
    memcpy(iv, adresse, 8);
    memset(iv + 8, zugriff, 8);
  } else {
    uint8_t ableitung[16], entschluesselung[16], authentifizierung[16], berechnet[16];
    memset(ableitung, 7, 16);
    ableitung[0] = 0;
    memcpy(ableitung + 1, zaehler, 4);
    memcpy(ableitung + 5, adresse + 2, 4);
    if (!cmac(schluessel, ableitung, 16, entschluesselung)) {
      ergebnis.zustand = "AES_FEHLER"; return ergebnis;
    }
    ableitung[0] = 1;
    if (!cmac(schluessel, ableitung, 16, authentifizierung)) {
      ergebnis.zustand = "AES_FEHLER"; return ergebnis;
    }
    uint8_t nachricht[261];
    nachricht[0] = 0x25;
    memcpy(nachricht + 1, zaehler, 4);
    memcpy(nachricht + 5, paket + transportanfang, laenge - transportanfang);
    if (!cmac(authentifizierung, nachricht, 5 + laenge - transportanfang, berechnet)) {
      ergebnis.zustand = "AES_FEHLER"; return ergebnis;
    }
    uint8_t unterschied = 0;
    for (int index = 0; index < 8; ++index) unterschied |= mac[index] ^ berechnet[index];
    if (unterschied) { ergebnis.zustand = "AUTHENTIFIZIERUNG_FEHLGESCHLAGEN"; return ergebnis; }
    ergebnis.authentifiziert = true;
    memcpy(schluessel, entschluesselung, 16);
  }
  size_t bloecke = (konfiguration >> 4) & 15;
  size_t verschluesselt = bloecke == 15 ? laenge - stelle : bloecke * 16;
  // N=0 ist keine Verschlüsselung; diese Sondervariante nicht als entschlüsselt melden.
  if (verschluesselt < 16 || verschluesselt % 16 || stelle + verschluesselt > laenge) {
    ergebnis.zustand = "VERSCHLUESSELTE_LAENGE_UNGUELTIG"; return ergebnis;
  }
  uint8_t klartext[256];
  if (!cbcEntschluesseln(schluessel, iv, paket + stelle, verschluesselt, klartext)) {
    ergebnis.zustand = "AES_FEHLER"; return ergebnis;
  }
  // Modus 5 hat keinen MAC: 2F2F ist nur eine Plausibilitätsprüfung, keine Authentizität.
  if (klartext[0] != 0x2F || klartext[1] != 0x2F) {
    ergebnis.zustand = "ENTSCHLUESSELUNG_FEHLGESCHLAGEN"; return ergebnis;
  }
  memcpy(klartext + verschluesselt, paket + stelle + verschluesselt, laenge - stelle - verschluesselt);
  ergebnis.laenge = laenge - stelle - 2;
  memcpy(ergebnis.daten, klartext + 2, ergebnis.laenge);
  ergebnis.zustand = "ENTSCHLUESSELT";
  return ergebnis;
}
} // Namensraum Oms
