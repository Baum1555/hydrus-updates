#pragma once
#include <Preferences.h>
#include <ArduinoJson.h>
#include "ZaehlerSchluessel.h"

struct Geraet {
  char id[9]={}, name[49]={}, schluessel[33]={};
  float leckLiter=0.1f;
  uint32_t leckSekunden=1800, empfangSekunden=600;
  bool leckAktiv=true;
};
class GeraeteKonfig {
 public:
  Geraet geraete[8];
  void starten() {
    nvs.begin("hydrus-geraete",false);
    if(nvs.getBytesLength("v1")==sizeof(geraete)) { nvs.getBytes("v1",geraete,sizeof(geraete)); }
    else {
      // Neue Geräte und Werksreset beginnen ohne voreingetragene Zähler.
      speichern();
    }
  }
  int finden(const String &id) const {for(int i=0;i<8;++i)if(id==geraete[i].id && id.length())return i;return -1;}
  bool speichern(){return nvs.putBytes("v1",geraete,sizeof(geraete))==sizeof(geraete);}
  bool aendern(const String &id,const String &name,const String &key,bool keyLoeschen,
               float liter,uint32_t dauer,uint32_t empfang,bool aktiv) {
    if(id.length()!=8||name.length()>48||!isfinite(liter)||liter<0.001f||liter>1000||dauer<60||dauer>86400||empfang<30||empfang>86400)return false;
    for(char c:id)if(!isxdigit(c))return false;
    if(key.length() && key.length()!=32)return false;
    for(char c:key)if(!isxdigit(c))return false;
    int i=finden(id);if(i<0)for(int j=0;j<8;++j)if(!geraete[j].id[0]){i=j;break;}
    if(i<0)return false;
    const Geraet alt=geraete[i];auto &g=geraete[i];
    strlcpy(g.id,id.c_str(),9);strlcpy(g.name,name.length()?name.c_str():id.c_str(),49);
    if(keyLoeschen)memset(g.schluessel,0,sizeof(g.schluessel));
    else if(key.length())strlcpy(g.schluessel,key.c_str(),33);
    g.leckLiter=liter;g.leckSekunden=dauer;g.empfangSekunden=empfang;g.leckAktiv=aktiv;
    if(!speichern()){g=alt;return false;}
    // Ein neuer Schlüssel darf keinen alten Entschlüsselungserfolg übernehmen.
    if(strcmp(alt.schluessel,g.schluessel)||strcmp(alt.id,g.id))pruefung[i]="WARTE_AUF_PAKET";
    return true;
  }
  bool loeschen(const String &id){
    const int i=finden(id);if(i<0)return false;
    const Geraet alt=geraete[i];geraete[i]=Geraet{};
    if(!speichern()){geraete[i]=alt;return false;}pruefung[i]="WARTE_AUF_PAKET";return true;
  }
  void liste(ZaehlerSchluessel (&ziel)[8])const{for(size_t i=0;i<8;++i)ziel[i]={geraete[i].id,geraete[i].schluessel};}
  // Nur im RAM: Nach einem Neustart wird der Schlüssel erneut anhand eines Pakets geprüft.
  void pruefergebnis(const char *id,const char *zustand){const int i=finden(String(id));if(i>=0)pruefung[i]=zustand;}
  void json(JsonArray a)const {
    for(const auto &g:geraete)if(g.id[0]){
      JsonObject o=a.add<JsonObject>();o["id"]=g.id;o["name"]=g.name;o["schluessel_vorhanden"]=bool(g.schluessel[0]);
      o["schluessel_pruefung"]=pruefung[&g-geraete];
      o["leck_l_min"]=g.leckLiter;o["leck_sekunden"]=g.leckSekunden;o["empfang_sekunden"]=g.empfangSekunden;o["leck_aktiv"]=g.leckAktiv;
    }
  }
 private:
  const char *pruefung[8]={"WARTE_AUF_PAKET","WARTE_AUF_PAKET","WARTE_AUF_PAKET","WARTE_AUF_PAKET","WARTE_AUF_PAKET","WARTE_AUF_PAKET","WARTE_AUF_PAKET","WARTE_AUF_PAKET"};
  Preferences nvs;
};
inline GeraeteKonfig Geraete;
