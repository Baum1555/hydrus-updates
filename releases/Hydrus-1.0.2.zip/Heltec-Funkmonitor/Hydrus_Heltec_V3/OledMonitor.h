#pragma once
#include "OledAnzeige.h"
#include "Verbrauch.h"
#include "PrgBedienung.h"

// OLED und Taste laufen nur in der Hauptaufgabe. Keine Wartepausen im Betrieb.
class OledMonitor {
 public:
  bool resetBereit=false;
  void resetAbbrechen(){resetBereit=false;resetVorgemerkt=false;seite=Messwerte;sofort=true;}
  void starten(){pinMode(PIN_PRG,INPUT_PULLUP);taste.starten(digitalRead(PIN_PRG),millis());}
  bool pflegen(OledAnzeige &anzeige,const String &ip,bool funkFehler,bool scan,
               bool heimnetz=false,const String &apIp="192.168.4.1",const String &apName="HYDRUS-Monitor"){
    const uint32_t jetzt=millis();
    const auto aktion=taste.pflegen(digitalRead(PIN_PRG),jetzt);
    if(aktion==PrgBedienung::Werkreset){resetVorgemerkt=true;resetFrageSeit=jetzt;sofort=true;}
    if(resetVorgemerkt){
      if(aktion==PrgBedienung::Kurz && uint32_t(jetzt-resetFrageSeit)<20000){resetBereit=true;sofort=true;}
      if(uint32_t(jetzt-resetFrageSeit)>=20000 || aktion==PrgBedienung::Doppelt){resetVorgemerkt=false;seite=Messwerte;sofort=true;}
    }
    if(!resetVorgemerkt && aktion==PrgBedienung::Kurz){weiter();seite=Messwerte;sofort=true;}
    if(aktion==PrgBedienung::Doppelt){seite=seite==Netzwerk?Messwerte:Netzwerk;sofort=true;}
    if(aktion==PrgBedienung::Lang){seite=Accesspoint;apBeginn=jetzt;sofort=true;}
    // AP-Hilfe blendet sich nach 20 Sekunden aus; das WLAN bleibt unverändert aktiv.
    if(seite==Accesspoint && uint32_t(jetzt-apBeginn)>=20000){seite=Messwerte;sofort=true;}
    const bool resetHalten=taste.resetFortschritt(jetzt);
    const bool halten=taste.fortschritt(jetzt)||resetHalten;
    if(halten!=hielt){sofort=true;hielt=halten;}
    if(!sofort&&uint32_t(jetzt-letzteAnzeige)<(halten?100u:500u))return true;
    sofort=false;letzteAnzeige=jetzt;
    if(auswahl<0||!Geraete.geraete[auswahl].id[0])weiter();
    JsonDocument d;Auswertung.json(d.to<JsonArray>());
    // Aktive Leckwarnungen haben Vorrang. Mehrere betroffene Zähler wechseln alle vier Sekunden.
    int alarm[8],anzahl=0;
    for(JsonObject o:d.as<JsonArray>())if(o["leckverdacht"]|false){int i=Geraete.finden(o["id"].as<String>());if(i>=0&&anzahl<8)alarm[anzahl++]=i;}
    const int index=anzahl?alarm[(jetzt/4000)%anzahl]:auswahl;
    JsonObject zustand;
    if(index>=0)for(JsonObject o:d.as<JsonArray>())if(o["id"].as<String>()==Geraete.geraete[index].id){zustand=o;break;}
    anzeige.leeren();
    String name=index>=0?String(Geraete.geraete[index].name):String("Kein Zaehler");
    if(!name.length()&&index>=0)name=Geraete.geraete[index].id;
    name=anzeigeName(name);
    // Warnung bleibt auch auf den Informationsseiten sichtbar.
    if(resetVorgemerkt){
      anzeige.zeile(0,"WERKSEINSTELLUNGEN?");anzeige.zeile(2,"ALLES LOESCHEN?");
      anzeige.zeile(4,"KURZ PRG: JA");anzeige.zeile(6,"WARTEN: ABBRUCH");
      return anzeige.anzeigen();
    }
    if(resetHalten){
      anzeige.zeile(0,"WERKSRESET");anzeige.zeile(2,"DANACH BESTAETIGEN");
      anzeige.balken(4,taste.resetProzent(jetzt));
      anzeige.zeile(6,"10 SEKUNDEN HALTEN");anzeige.zeile(7,"LOSLASSEN: ABBRUCH");
      return anzeige.anzeigen();
    }
    if(halten){
      anzeige.zeile(0,anzahl?"LECKVERDACHT":"PRG GEDRUECKT HALTEN");
      anzeige.zeile(2,"AP-ADRESSE ANZEIGEN");
      anzeige.balken(4,taste.prozent(jetzt));
      anzeige.zeile(6,"3 SEKUNDEN HALTEN");
      return anzeige.anzeigen();
    }
    if(seite==Netzwerk){
      anzeige.zeile(0,anzahl?"LECKVERDACHT":"NETZWERK");
      anzeige.zeile(2,heimnetz?"HEIMNETZ VERBUNDEN":"HEIMNETZ GETRENNT");
      anzeige.zeile(3,heimnetz?ip.c_str():"--");
      anzeige.zeile(5,"ACCESS POINT");anzeige.zeile(6,apIp.c_str());
      anzeige.zeile(7,"2X PRG: MESSWERTE");
      return anzeige.anzeigen();
    }
    if(seite==Accesspoint){
      anzeige.zeile(0,anzahl?"LECKVERDACHT":"ACCESS POINT");
      anzeige.zeile(2,anzeigeName(apName).c_str());
      anzeige.zeile(4,apIp.c_str());anzeige.zeile(6,"DAUERHAFT AKTIV");
      anzeige.zeile(7,"2X PRG: NETZWERK");
      return anzeige.anzeigen();
    }
    const bool fehlt=index<0||!(zustand["gesehen"]|false)||(zustand["empfang_fehlt"]|false);
    const bool bekannt=!zustand["durchfluss_l_min"].isNull() && isfinite(zustand["durchfluss_l_min"].as<double>());
    anzeige.zeile(0,anzahl?"LECKVERDACHT":name.c_str());
    if(anzahl)anzeige.zeile(1,name.c_str());
    else anzeige.zeile(2,funkFehler?"FUNKFEHLER":scan?"FUNKSUCHE AKTIV":fehlt?"KEIN EMPFANG":!bekannt?"KEIN DURCHFLUSSWERT":"DURCHFLUSS");
    if(!funkFehler&&!scan&&!fehlt&&bekannt){
      String wert=String(zustand["durchfluss_l_min"].as<double>(),3);
      while(wert.endsWith("0")&&wert.indexOf('.')<int(wert.length())-2)wert.remove(wert.length()-1);
      wert.replace('.',',');
      if(wert.length()<=10)anzeige.gross(3,wert.c_str());else anzeige.zeile(3,wert.c_str());
      anzeige.zeile(5,"L/MIN");
    }else anzeige.gross(3,"--");
    const String adresse="IP: "+ip;anzeige.zeile(7,adresse.c_str());
    return anzeige.anzeigen();
  }
 private:
  enum Seite { Messwerte, Netzwerk, Accesspoint };
  Seite seite=Messwerte;PrgBedienung taste;
  int auswahl=-1;bool sofort=true,hielt=false,resetVorgemerkt=false;
  uint32_t letzteAnzeige=0,apBeginn=0,resetFrageSeit=0;
  void weiter(){for(int n=1;n<=8;++n){int i=(auswahl+n+8)%8;if(Geraete.geraete[i].id[0]){auswahl=i;return;}}auswahl=-1;}
  static String anzeigeName(String text){
    text.replace("ä","ae");text.replace("ö","oe");text.replace("ü","ue");text.replace("Ä","Ae");text.replace("Ö","Oe");text.replace("Ü","Ue");text.replace("ß","ss");
    String ascii;for(size_t i=0;i<text.length();++i){unsigned char c=text[i];if(c>=32&&c<127)ascii+=char(c);else if(c>=192)ascii+='?';}
    if(ascii.length()>21)ascii=ascii.substring(0,18)+"...";return ascii;
  }
};
