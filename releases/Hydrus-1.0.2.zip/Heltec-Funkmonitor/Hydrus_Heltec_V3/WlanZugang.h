#pragma once
// Einrichtungs-WLAN. Heimnetz-Zugangsdaten im Webportal speichern.
// WLAN-Passwort und AES-Zählerschlüssel sind voneinander unabhängig.
constexpr char WLAN_NAME[] = "HYDRUS-Monitor";
constexpr char WLAN_PASSWORT[] = "123456789"; // Vor Nutzung nach Wunsch ändern (8–63 Zeichen).
constexpr uint16_t WLAN_DATENPORT = 8765;
// Feste IP: 192.168.4.1; Änderung in WebPortal.h und im PC-Programm abstimmen.
