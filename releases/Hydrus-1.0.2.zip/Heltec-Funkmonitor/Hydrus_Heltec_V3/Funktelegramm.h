#pragma once
// Eigenständige Auswertung der Funkrahmen, ohne Arduino- oder ESPHome-Abhängigkeit.
// Es werden nur Übertragungsfehler geprüft, keine Verbrauchsdaten entschlüsselt.
#include <stddef.h>
#include <stdint.h>
#include <string.h>

namespace Funktelegramm {

constexpr size_t MAX_FUNKBYTES = 512;
constexpr size_t MAX_NUTZBYTES = 256;

struct Empfangsplan {
  char modus;                         // 'T' oder 'C'
  char format;                        // Blockaufteilung 'A' oder 'B'
  size_t funklaenge;                  // Anzahl Bytes nach dem Synchronwort
  size_t rahmenlaenge;                // Dekodierte Länge einschließlich CRC
};

struct Telegramm {
  uint8_t daten[MAX_NUTZBYTES];        // Normalisierter Rahmen ohne Funk-CRC
  size_t laenge;
  char modus;
  char format;
};

// CRC-16/EN-13757: Startwert 0, Polynom 0x3D65, abschließend invertieren.
inline uint16_t pruefsumme(const uint8_t *daten, size_t laenge) {
  uint16_t wert = 0;
  for (size_t stelle = 0; stelle < laenge; ++stelle) {
    wert ^= static_cast<uint16_t>(daten[stelle]) << 8;
    for (uint8_t bit = 0; bit < 8; ++bit) {
      wert = (wert & 0x8000) ? static_cast<uint16_t>((wert << 1) ^ 0x3D65)
                             : static_cast<uint16_t>(wert << 1);
    }
  }
  return static_cast<uint16_t>(~wert);
}

// T1 überträgt jede Vierergruppe von Datenbits als sechs Funkbits.
// Die Zuordnung ist die 3-von-6-Codierung des Wireless-M-Bus-Protokolls.
inline int nibbleAusSymbol(uint8_t symbol) {
  const uint8_t symbole[16] = {
    0x16, 0x0D, 0x0E, 0x0B, 0x1C, 0x19, 0x1A, 0x13,
    0x2C, 0x25, 0x26, 0x23, 0x34, 0x31, 0x32, 0x29
  };
  for (int zahl = 0; zahl < 16; ++zahl) {
    if (symbole[zahl] == symbol) return zahl;
  }
  return -1;
}

inline uint8_t sechsBits(const uint8_t *daten, size_t anfang) {
  uint8_t wert = 0;
  for (size_t bit = anfang; bit < anfang + 6; ++bit) {
    wert = static_cast<uint8_t>((wert << 1) | ((daten[bit / 8] >> (7 - bit % 8)) & 1));
  }
  return wert;
}

inline bool dreiVonSechs(const uint8_t *quelle, size_t quelllaenge,
                        uint8_t *ziel, size_t ziellaenge) {
  if (ziellaenge * 12 > quelllaenge * 8) return false;
  for (size_t stelle = 0; stelle < ziellaenge; ++stelle) {
    const int oben = nibbleAusSymbol(sechsBits(quelle, stelle * 12));
    const int unten = nibbleAusSymbol(sechsBits(quelle, stelle * 12 + 6));
    if (oben < 0 || unten < 0) return false;
    ziel[stelle] = static_cast<uint8_t>((oben << 4) | unten);
  }
  return true;
}

// Aus den ersten drei FIFO-Bytes ergibt sich die erwartete Gesamtlänge.
// C1 besitzt nach 0x543D zusätzlich 0x54 und eine Formatkennung; T1 nicht.
inline bool planErmitteln(const uint8_t *kopf, size_t laenge, Empfangsplan &plan) {
  if (laenge < 3) return false;
  uint8_t laengenfeld = 0;
  if (kopf[0] == 0x54) {
    plan.modus = 'C';
    if (kopf[1] == 0xCD) plan.format = 'A';
    else if (kopf[1] == 0x3D) plan.format = 'B';
    else return false;
    laengenfeld = kopf[2];
  } else {
    plan.modus = 'T';
    plan.format = 'A';
    if (!dreiVonSechs(kopf, laenge, &laengenfeld, 1)) return false;
  }

  if (plan.format == 'A') {
    // Erster Block: zehn Datenbytes. Weitere Blöcke: bis zu 16 Datenbytes.
    // Auf jeden Block folgen zwei CRC-Bytes, die das L-Feld nicht mitzählt.
    const size_t datenlaenge = static_cast<size_t>(laengenfeld) + 1;
    if (datenlaenge < 11) return false;
    const size_t bloecke = 1 + (datenlaenge - 10 + 15) / 16;
    plan.rahmenlaenge = datenlaenge + 2 * bloecke;
  } else {
    // Bei Format B zählt das L-Feld die CRC-Bytes dagegen mit.
    plan.rahmenlaenge = static_cast<size_t>(laengenfeld) + 1;
    if (plan.rahmenlaenge < 13) return false;
  }
  plan.funklaenge = plan.modus == 'T' ? (plan.rahmenlaenge * 3 + 1) / 2
                                     : plan.rahmenlaenge + 2;
  return plan.funklaenge <= MAX_FUNKBYTES;
}

inline bool blockPruefen(const uint8_t *block, size_t datenlaenge) {
  const uint16_t empfangen = (static_cast<uint16_t>(block[datenlaenge]) << 8)
                              | block[datenlaenge + 1];
  return pruefsumme(block, datenlaenge) == empfangen;
}

inline bool dekodieren(const uint8_t *funkdaten, size_t laenge, Telegramm &ergebnis) {
  ergebnis.laenge = 0;
  Empfangsplan plan{};
  if (!planErmitteln(funkdaten, laenge, plan) || laenge != plan.funklaenge) return false;

  uint8_t zwischenablage[MAX_FUNKBYTES];
  if (plan.modus == 'T') {
    if (!dreiVonSechs(funkdaten, laenge, zwischenablage, plan.rahmenlaenge)) return false;
  } else {
    memcpy(zwischenablage, funkdaten + 2, plan.rahmenlaenge);
  }

  size_t gelesen = 0;
  size_t geschrieben = 0;
  if (plan.format == 'A') {
    const size_t datenlaenge = static_cast<size_t>(zwischenablage[0]) + 1;
    while (geschrieben < datenlaenge) {
      const size_t rest = datenlaenge - geschrieben;
      const size_t blocklaenge = gelesen == 0 ? 10 : (rest < 16 ? rest : 16);
      if (gelesen + blocklaenge + 2 > plan.rahmenlaenge ||
          geschrieben + blocklaenge > MAX_NUTZBYTES ||
          !blockPruefen(zwischenablage + gelesen, blocklaenge)) return false;
      memcpy(ergebnis.daten + geschrieben, zwischenablage + gelesen, blocklaenge);
      gelesen += blocklaenge + 2;
      geschrieben += blocklaenge;
    }
  } else {
    // Format B: ein Block bis 128 Bytes inklusive CRC, gegebenenfalls ein zweiter.
    while (gelesen < plan.rahmenlaenge) {
      const size_t rest = plan.rahmenlaenge - gelesen;
      const size_t blockgesamt = gelesen == 0 && rest > 128 ? 128 : rest;
      if (blockgesamt < 3) return false;
      const size_t blocklaenge = blockgesamt - 2;
      if (geschrieben + blocklaenge > MAX_NUTZBYTES ||
          !blockPruefen(zwischenablage + gelesen, blocklaenge)) return false;
      memcpy(ergebnis.daten + geschrieben, zwischenablage + gelesen, blocklaenge);
      gelesen += blockgesamt;
      geschrieben += blocklaenge;
    }
  }
  if (gelesen != plan.rahmenlaenge || geschrieben < 11) return false;
  ergebnis.daten[0] = static_cast<uint8_t>(geschrieben - 1);
  ergebnis.laenge = geschrieben;
  ergebnis.modus = plan.modus;
  ergebnis.format = plan.format;
  return true;
}

} // Namensraum Funktelegramm

// Datentypen für die Übergabe zwischen Empfangsaufgabe und USB-Ausgabe.
// Im Header definiert, damit der Arduino-Vorprozessor sie vor allen Funktionen kennt.
enum class Ergebnisart : uint8_t {
  PAKET, UNGUELTIGER_KOPF, PRUEFSUMMENFEHLER, FIFO_UEBERLAUF,
  ZEITUEBERSCHREITUNG, SPI_FEHLER, SUCHPUNKT, FUNKSTATUS, ZU_LANG
};

struct Empfangsmeldung {
  Funktelegramm::Telegramm telegramm;
  int16_t signalstaerke;
  Ergebnisart art;
  uint32_t frequenz = 868950000;
  int16_t mittelwert = 0;
  uint8_t durchgang = 0;  // 0 = normaler Empfang, 1..4 = Aktivitätsscan.
};
