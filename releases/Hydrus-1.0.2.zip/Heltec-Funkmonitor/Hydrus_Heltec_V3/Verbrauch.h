#pragma once
#include <LittleFS.h>
#include <ArduinoJson.h>
#include <time.h>
#include "GeraeteKonfig.h"
#include "Messkern.h"

// Kleine persistente Zählerzustände; abgeschlossene Stunden/Tage separat vom Rohdatenring.
class Verbrauch {
 public:
  String fehler;
  void starten(){nvs.begin("hydrus-verbr",false);if(nvs.getBytesLength("v1")==sizeof(dauer))nvs.getBytes("v1",dauer,sizeof(dauer));}
  void empfangen(const char *id,Grundwerte werte) {
    int i=Geraete.finden(id);if(i<0)return;
    const auto &g=Geraete.geraete[i];auto &l=live[i];auto &p=dauer[i];uint32_t ms=millis();
    bool luecke=!l.gesehen||uint32_t(ms-l.letzter)>g.empfangSekunden*1000;
    l.gesehen=true;l.letzter=ms;
    // Nach Neustart, Empfangslücke oder fehlendem Durchfluss beginnt die Dauer neu.
    if(!g.leckAktiv||!std::isfinite(werte.fluss)||werte.fluss<g.leckLiter){l.laeuft=false;l.leck=false;}
    else {if(luecke||!l.laeuft){l.beginn=ms;l.laeuft=true;}l.leck=uint32_t(ms-l.beginn)>=g.leckSekunden*1000;}
    l.fluss=werte.fluss;
    time_t jetzt=time(nullptr);if(jetzt<1700000000||!std::isfinite(werte.volumen))return;
    tm lokal{};localtime_r(&jetzt,&lokal);uint32_t tag=(lokal.tm_year+1900)*10000+(lokal.tm_mon+1)*100+lokal.tm_mday;
    uint32_t stunde=uint32_t(jetzt/3600);
    if(strcmp(p.id,id)){p=Persistent{};strlcpy(p.id,id,9);}
    if(p.tag && p.tag!=tag){archiv("tage",p.id,p.tag,p.tagMenge,p.tagStart,p.zeit);p.tagMenge=0;}
    if(p.stunde && p.stunde!=stunde){archiv("stunden",p.id,p.stunde,p.stundenMenge,p.stundenStart,p.zeit);p.stundenMenge=0;}
    const bool folge=p.zeit && jetzt>p.zeit && uint64_t(jetzt-p.zeit)<=g.empfangSekunden && werte.volumen>=p.stand;
    if(folge){double delta=werte.volumen-p.stand;if(tag==p.tag)p.tagMenge+=delta;if(stunde==p.stunde)p.stundenMenge+=delta;}
    if(p.zeit && werte.volumen<p.stand)l.ruecksprung=true;
    if(tag!=p.tag)p.tagStart=jetzt;
    if(stunde!=p.stunde)p.stundenStart=jetzt;
    p.tag=tag;p.stunde=stunde;p.zeit=jetzt;p.stand=werte.volumen;
    geaendert=true;
  }
  void pflegen(){
    if(geaendert && (!gesichert || uint32_t(millis()-letzteSicherung)>=300000)) {
      if(nvs.putBytes("v1",dauer,sizeof(dauer))!=sizeof(dauer))fehler="Verbrauch konnte nicht gesichert werden";
      else {geaendert=false;gesichert=true;}
      letzteSicherung=millis();
    }
  }
  void neuBewerten(int i){if(i>=0&&i<8)live[i]=Live{};}
  void json(JsonArray a)const {
    for(int i=0;i<8;++i){const auto &g=Geraete.geraete[i];if(!g.id[0])continue;const auto &l=live[i];const auto &p=dauer[i];
      JsonObject o=a.add<JsonObject>();o["id"]=g.id;o["name"]=g.name;
      o["empfang_sekunden"]=g.empfangSekunden;
      o["leck_aktiv"]=g.leckAktiv;
      if(std::isfinite(l.fluss))o["durchfluss_l_min"]=l.fluss;
      o["gesehen"]=l.gesehen;o["alter_s"]=l.gesehen?uint32_t(millis()-l.letzter)/1000:uint32_t(millis()/1000);
      bool fehlt=(l.gesehen?uint32_t(millis()-l.letzter):millis())>g.empfangSekunden*1000;
      o["empfang_fehlt"]=fehlt;o["leckverdacht"]=l.leck&&!fehlt;o["durchfluss_unbekannt"]=!std::isfinite(l.fluss);
      o["leck_seit_s"]=l.laeuft&&!fehlt?uint32_t(millis()-l.beginn)/1000:0;o["zaehler_ruecksprung"]=l.ruecksprung;
      if(p.zeit&&!strcmp(p.id,g.id)){o["tag"]=p.tag;o["tag_m3"]=p.tagMenge;o["stunde"]=p.stunde;o["stunde_m3"]=p.stundenMenge;o["zeit"]=p.zeit;o["stand"]=p.stand;}
    }
  }
  void senden(WebServer &http){
    http.sendHeader("Cache-Control","no-store");http.setContentLength(CONTENT_LENGTH_UNKNOWN);http.send(200,"application/x-ndjson","");
    JsonDocument d;d["typ"]="aktuell";json(d["werte"].to<JsonArray>());String s;serializeJson(d,s);http.sendContent(s+"\n");
    for(const char *art:{"tage","stunden"})for(int nr:{1,0}){File f=LittleFS.open(pfad(art,nr),"r");if(!f)continue;char b[1024];while(f.available()){size_t n=f.readBytes(b,sizeof(b));if(!n)break;http.sendContent(b,n);}http.sendContent("\n");}
    http.sendContent("");
  }
 private:
  struct Persistent{char id[9]={};uint32_t tag=0,stunde=0;int64_t zeit=0,tagStart=0,stundenStart=0;double stand=0,tagMenge=0,stundenMenge=0;} dauer[8];
  struct Live{bool gesehen=false,laeuft=false,leck=false,ruecksprung=false;uint32_t letzter=0,beginn=0;double fluss=NAN;} live[8];
  Preferences nvs;uint32_t letzteSicherung=0;bool geaendert=false,gesichert=false;
  static String pfad(const char *art,int nr){return String("/")+art+"-"+String(nr)+".jsonl";}
  void archiv(const char *art,const char *id,uint32_t periode,double menge,int64_t anfang,int64_t ende){
    JsonDocument d;d["typ"]=art;d["id"]=id;d["periode"]=periode;d["m3"]=menge;d["von"]=anfang;d["bis"]=ende;d["teilweise"]=true;
    String text;serializeJson(d,text);text="\n"+text+"\n";
    String p=pfad(art,0);File f=LittleFS.open(p,"r");size_t groesse=f?f.size():0;f.close();
    const size_t limit=!strcmp(art,"tage")?65536:131072;
    if(groesse+text.length()>limit){String alt=pfad(art,1);if(LittleFS.exists(alt)&&!LittleFS.remove(alt)){fehler="Archivrotation fehlgeschlagen";return;}if(!LittleFS.rename(p,alt)){fehler="Archivrotation fehlgeschlagen";return;}}
    f=LittleFS.open(p,"a");if(!f||f.print(text)!=text.length())fehler="Verbrauchsarchiv nicht beschreibbar";f.close();
  }
};
inline Verbrauch Auswertung;
