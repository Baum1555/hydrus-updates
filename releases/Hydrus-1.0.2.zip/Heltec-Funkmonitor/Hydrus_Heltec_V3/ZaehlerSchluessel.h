#pragma once
// HIER später die vom Versorger erhaltenen AES-Schlüssel eintragen.
// Pro Schlüssel genau 32 Hexzeichen (0-9, A-F), ohne Leerzeichen und ohne 0x.
// Leer lassen, solange kein Schlüssel vorliegt: Der Rohpaketempfang bleibt aktiv.
// Die Kennung muss der vom Programm angezeigten Transportkennung entsprechen.
// Kennung und Schlüssel vorzugsweise in der geschützten Zählerverwaltung eintragen.
// Schlüssel sind Geheimnisse: Diese Datei und die gebaute Firmware nicht weitergeben.

struct ZaehlerSchluessel {
  const char *kennung;
  const char *aesHex;
};

static const ZaehlerSchluessel ZAEHLER_SCHLUESSEL[] = {
  {"", ""} // Öffentliche Updates enthalten keine persönlichen Zählerdaten.
};
