#pragma once
#include <Preferences.h>
#include <LittleFS.h>
#include <nvs_flash.h>

// Der Auftrag übersteht Stromausfälle. Ausführung nur beim Booten vor allen Diensten.
class Werksreset {
 public:
  static const char *fehler(){return meldung;}
  static bool vormerken(){Preferences p;if(!p.begin("hydrus-reset",false))return false;bool ok=p.putBool("offen",true)==1;p.end();return ok;}
  static bool ausstehend(){Preferences p;if(!p.begin("hydrus-reset",true))return false;bool offen=p.getBool("offen",false);p.end();return offen;}
  static bool ausfuehren(){
    // Keine Funk-/Web-/Journalaufgabe darf währenddessen Daten zurückschreiben.
    meldung="";
    // begin setzt den Partitionsnamen auch bei einem nicht lesbaren Dateisystem.
    // Vor dem ersten begin kennt format() seine Zielpartition noch nicht.
    LittleFS.begin(false, "/littlefs", 10, "spiffs");
    LittleFS.end();
    if(!LittleFS.format()){meldung="Messwertspeicher konnte nicht formatiert werden";return false;}
    // Erst nach dem Journal alle NVS-Daten löschen, einschließlich Reset-Auftrag.
    // Erfasst WLAN, AP-Zugang, AES-Schlüssel, Zähler, Verbrauch, Push und Update-Einstellungen.
    if(nvs_flash_erase()!=ESP_OK){meldung="Einstellungen konnten nicht geloescht werden";return false;}
    if(nvs_flash_init()!=ESP_OK){meldung="Einstellungsspeicher konnte nicht gestartet werden";return false;}
    return true;
  }
 private:
  inline static const char *meldung="";
};
