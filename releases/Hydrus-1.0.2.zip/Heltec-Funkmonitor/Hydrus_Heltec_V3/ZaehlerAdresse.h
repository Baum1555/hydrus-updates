#pragma once
// Gemeinsame Adresserkennung fuer USB, WLAN, OLED und OMS-Auswertung.
#include <stdint.h>
#include <stddef.h>
#include <stdio.h>
#include <string.h>

namespace ZaehlerAdresse {
struct Kopf {
  bool gueltig = false;
  bool realData = false;
  char kennung[9] = {};
};
inline Kopf lesen(const uint8_t *daten, size_t laenge) {
  Kopf kopf;
  if (!daten || laenge < 11 || laenge > 256 || daten[0] + 1u != laenge) return kopf;
  const uint16_t hersteller = daten[2] | (static_cast<uint16_t>(daten[3]) << 8);
  char code[4] = {static_cast<char>(64 + ((hersteller >> 10) & 31)),
                  static_cast<char>(64 + ((hersteller >> 5) & 31)),
                  static_cast<char>(64 + (hersteller & 31)), 0};
  const bool diehl = !strcmp(code, "DME") || !strcmp(code, "EWT") ||
                    !strcmp(code, "HYD") || !strcmp(code, "SAP") || !strcmp(code, "SPL");
  // Real Data: Diehl-Hersteller, passendes C-Feld und CI/konfigurationsabhaengige Kennung.
  kopf.realData = diehl && (daten[1] == 0x44 || daten[1] == 0x46) &&
      (daten[10] == 0x71 || (daten[10] == 0x7A && laenge >= 15 && (daten[14] & 0x10)));
  const size_t anfang = kopf.realData ? 6 : 4;
  snprintf(kopf.kennung, sizeof(kopf.kennung), "%02X%02X%02X%02X",
           daten[anfang + 3], daten[anfang + 2], daten[anfang + 1], daten[anfang]);
  kopf.gueltig = true;
  return kopf;
}
}
