#pragma once
#include <Arduino.h>
#include <WiFi.h>
#include <lwip/sockets.h>
#include <errno.h>
#include "WlanZugang.h"
#include "WebPortal.h"

struct BefehlsPuffer {
  char zeile[32] = {};
  size_t laenge = 0;
  bool ueberlang = false;
};

// Nur setup/loop verwenden diese Klasse. Die zeitkritische Funkaufgabe nutzt eine Queue.
class DatenAusgabe : public Print {
 public:
  WebPortal portal;
  WiFiClient netzclient;
  BefehlsPuffer netzbefehl;
  using Print::write;
  bool wlanBereit() const { return apBereit; }

  void starten() {
    portal.starten();
    apBereit = portal.bereit;
    server.begin();
    webzeile.reserve(2048);
    Serial.println("STATUS Webseite: http://192.168.4.1/ ; Heimnetz unter Einstellungen einrichten.");
  }

  size_t write(uint8_t zeichen) override { return write(&zeichen, 1); }
  size_t write(const uint8_t *daten, size_t laenge) override {
    // USB erhält weiterhin jede Zeile, unabhängig vom WLAN-Verbindungszustand.
    Serial.write(daten, laenge);
    for(size_t i=0;i<laenge;++i) {
      if(daten[i]=='\n') {
        if(!webUeberlang) { webzeile.trim(); portal.zeile(webzeile); }
        webzeile=""; webUeberlang=false;
      } else if(!webUeberlang) {
        if(webzeile.length()<4096) webzeile+=char(daten[i]);
        else { webzeile=""; webUeberlang=true; }
      }
    }
    if (netzclient.connected()) {
      if (laenge > sizeof(sendepuffer) - belegt) trennen();
      else {
        if (!belegt) letzterFortschritt = millis();
        memcpy(sendepuffer + belegt, daten, laenge);
        belegt += laenge;
      }
    }
    return laenge;
  }

  void pflegen() {
    portal.pflegen();
    WiFiClient neu = server.accept();
    if (neu) {
      if (netzclient.connected()) neu.stop(); // Ein PC per WLAN, USB zusätzlich möglich.
      else {
        trennen();
        netzclient = neu;
        netzclient.setNoDelay(true);
        println("STATUS WLAN-Datenverbindung bereit. USB und WLAN empfangen gleichzeitig.");
      }
    }
    if (!netzclient.connected()) { trennen(); return; }
    if (!belegt) return;
    // Nicht blockierend senden: Ein langsamer/verschwundener PC darf USB nicht anhalten.
    size_t menge = belegt < 1460 ? belegt : 1460;
    int gesendet = ::send(netzclient.fd(), sendepuffer, menge, MSG_DONTWAIT);
    if (gesendet > 0) {
      belegt -= gesendet;
      memmove(sendepuffer, sendepuffer + gesendet, belegt);
      letzterFortschritt = millis();
    } else if (gesendet == 0 || (errno != EAGAIN && errno != EWOULDBLOCK && errno != EINTR)) {
      trennen();
    }
    if (belegt && static_cast<uint32_t>(millis() - letzterFortschritt) > 3000) trennen();
  }

 private:
  String webzeile;
  bool webUeberlang=false;
  WiFiServer server{WLAN_DATENPORT};
  bool apBereit = false;
  uint8_t sendepuffer[8192];
  size_t belegt = 0;
  uint32_t letzterFortschritt = 0;
  void trennen() {
    netzclient.stop();
    belegt = 0;
    netzbefehl = BefehlsPuffer{}; // Keine Befehlsreste an einen neuen Client vererben.
  }
};
