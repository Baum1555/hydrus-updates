#pragma once
#include "Funktelegramm.h"

namespace SxRahmen {
// Diese Fassung verwendet den normalen SX1262-Paketmodus mit 255 Empfangsbytes.
// Ein darüber hinausgehender Streaming-Empfänger ist hier nicht implementiert.
constexpr size_t AUFNAHME_BYTES = 255;

inline Ergebnisart auswerten(const uint8_t *daten, size_t anzahl, Funktelegramm::Telegramm &telegramm) {
  Funktelegramm::Empfangsplan plan{};
  if (!Funktelegramm::planErmitteln(daten, anzahl, plan)) return Ergebnisart::UNGUELTIGER_KOPF;
  if (plan.funklaenge > AUFNAHME_BYTES) return Ergebnisart::ZU_LANG;
  if (plan.funklaenge > anzahl) return Ergebnisart::ZEITUEBERSCHREITUNG;
  // Nach einem kurzen Telegramm enthält die feste Aufnahme noch Rauschen.
  // Nur die aus dem Kopf ermittelte Länge geht in Codierungs- und CRC-Prüfung ein.
  return Funktelegramm::dekodieren(daten, plan.funklaenge, telegramm)
      ? Ergebnisart::PAKET : Ergebnisart::PRUEFSUMMENFEHLER;
}
}
