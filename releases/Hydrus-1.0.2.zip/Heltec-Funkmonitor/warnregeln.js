// Die Zusammenfassung beschreibt die eingestellten Regeln, keine Verbrauchsprognose.
const warnStil=document.createElement('style');warnStil.textContent=`.warnEinstellung{min-width:0;border:1px solid var(--line);border-radius:14px;padding:18px;margin:6px 0}.warnEinstellung legend{font-weight:650;padding:0 8px}.warnFelder{display:grid;grid-template-columns:1fr 1fr;gap:16px;margin-top:18px}.warnSchalter{display:flex;align-items:center;gap:10px;color:var(--ink)}.warnZusammenfassung{padding:12px;border-radius:10px;background:var(--bg);margin-bottom:0}.warnEinstellung input[type=number]{width:100%}@media(max-width:500px){.warnFelder{grid-template-columns:1fr}}`;
document.head.append(warnStil);
function warnregelText(){
 const aktiv=$('leckAktiv').checked,fluss=$('leckLiter').valueAsNumber,dauer=$('leckDauer').valueAsNumber,empfang=$('empfangDauer').valueAsNumber;
 const n=x=>x.toLocaleString('de-DE',{maximumFractionDigits:3});
 $('leckLiter').disabled=!aktiv;$('leckDauer').disabled=!aktiv;
 $('leckErklaerung').textContent=!aktiv?'Warnung bei längerem Wasserfluss ausgeschaltet.':!Number.isFinite(fluss)||!Number.isFinite(dauer)||fluss<=0||dauer<=0?'Wassermenge und Dauer eingeben.':'Warnung, wenn mindestens '+n(fluss)+' Liter pro Minute für '+n(dauer)+' Minuten durchgehend gemeldet werden. Die Grenze ist kein Aufschlag auf den aktuellen Durchfluss.';
 $('empfangErklaerung').textContent=Number.isFinite(empfang)&&empfang>0?'Warnung, wenn der Heltec '+n(empfang)+' Minuten lang keine neuen Daten dieses Zählers erhält.':'Wartezeit in Minuten eingeben.';
}
for(const id of ['leckAktiv','leckLiter','leckDauer','empfangDauer'])$(id).addEventListener('input',warnregelText);
// Warnregeln unabhängig von den Stammdaten bearbeiten; Statusabfragen erhalten Entwürfe.
let warnGeladen='',warnBeschaeftigt=false;
function warnAuswahl(){
 const s=$('warnZaehler'),alt=s.value,signatur=JSON.stringify(geraeteListe.map(g=>[g.id,g.name]));
 if(s.dataset.liste!==signatur){s.dataset.liste=signatur;s.replaceChildren();for(const g of geraeteListe)s.append(new Option((g.name!==g.id?g.name+' · ':'')+g.id,g.id));s.value=geraeteListe.some(g=>g.id===alt)?alt:geraeteListe[0]?.id||'';}
 if(warnGeladen!==s.value)warnAnzeigen();
 $('warnLeer').classList.toggle('hidden',!!s.value);$('warnInhalt').classList.toggle('hidden',!s.value);
}
function warnAnzeigen(){
 const g=geraeteListe.find(g=>g.id===$('warnZaehler').value);warnGeladen=g?.id||'';
 $('leckLiter').value=g?.leck_l_min??.1;$('leckDauer').value=(g?.leck_sekunden??1800)/60;$('empfangDauer').value=(g?.empfang_sekunden??600)/60;$('leckAktiv').checked=g?.leck_aktiv??true;
 $('warnMeldung').textContent='';warnregelText();
}
$('warnZaehler').onchange=warnAnzeigen;
const auswahlOhneWarnungen=geraeteAuswahl;geraeteAuswahl=function(){auswahlOhneWarnungen();warnAuswahl();};
$('warnForm').onsubmit=async e=>{
 e.preventDefault();if(warnBeschaeftigt||!$('warnZaehler').value)return;
 const id=$('warnZaehler').value,daten={bereich:'warnungen',id,leck_l_min:$('leckLiter').value,leck_sekunden:Number($('leckDauer').value)*60,empfang_sekunden:Number($('empfangDauer').value)*60,leck_aktiv:$('leckAktiv').checked?'1':'0'};
 warnBeschaeftigt=true;$('warnSpeichern').disabled=true;$('warnZaehler').disabled=true;$('warnMeldung').textContent='Wird gespeichert …';
 try{if(!token)await sitzungLaden();const r=await fetch('/api/zaehler',{method:'POST',headers:{'X-Hydrus-Token':token},body:new URLSearchParams(daten),signal:AbortSignal.timeout(15000)});const text=await r.text();if(!r.ok)throw Error(text);
 const g=geraeteListe.find(g=>g.id===id);if(g)Object.assign(g,{leck_l_min:Number(daten.leck_l_min),leck_sekunden:daten.leck_sekunden,empfang_sekunden:daten.empfang_sekunden,leck_aktiv:daten.leck_aktiv==='1'});
 $('warnMeldung').textContent='Einstellungen gespeichert.';
 }catch(err){$('warnMeldung').textContent=err.message;}finally{warnBeschaeftigt=false;$('warnSpeichern').disabled=false;$('warnZaehler').disabled=false;}
};
if(pc){$('warnForm').classList.add('hidden');$('warnWeb').classList.remove('hidden');$('warnWeb').onclick=()=>bridge.webOeffnen($('adresse').value);}
warnAuswahl();warnregelText();
