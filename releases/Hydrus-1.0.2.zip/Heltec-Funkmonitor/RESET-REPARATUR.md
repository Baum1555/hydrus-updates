# Reset-Korrektur 1.0.1 (lokal)

Wenn Version 1.0 bei „Reset fehlgeschlagen / Neustart: erneut“ stehen bleibt:

1. Heltec per USB mit dem PC verbinden.
2. Dieses Paket entpacken und `Hydrus_Heltec_V3/Hydrus_Heltec_V3.ino` öffnen. Alle Header im selben Ordner lassen.
3. In Arduino das bisherige Heltec-V3-Board, den passenden COM-Port und die bisherige Partitionseinstellung verwenden. Sketch hochladen.
4. Falls keine Upload-Verbindung entsteht: PRG halten, RESET kurz drücken, PRG loslassen und erneut hochladen. PRG beim normalen Neustart nicht gedrückt halten.
5. Beim ersten Start wird der schon bestätigte Reset nachgeholt. Danach WLAN **HYDRUS-Monitor**, Passwort **123456789**, Webseite **http://192.168.4.1/**.

Die HUP-Datei kann die festhängende Version 1.0 nicht über WLAN reparieren: deren Webserver wurde noch nicht gestartet. Für diesen Fall ist einmal USB nötig.

Sollte der Reset auch mit 1.0.1 scheitern, startet eine Wiederherstellungsseite unter 192.168.4.1. Dort lässt sich der Reset erneut versuchen oder eine neuere signierte HUP-Datei installieren. Solange die Einstellungen noch vorhanden sind, gilt der bisher gespeicherte AP-Name samt Passwort. Der genaue Fehler erscheint auf der Webseite und über USB (115200 Baud). Messwert- und Funkdienste bleiben in diesem Modus angehalten.

Ursache: LittleFS erhielt vor dem Formatieren noch keinen Partitionsnamen. Die Korrektur richtet die Partition vor dem Formatieren ein. Regressionstest mit nachgebildetem LittleFS-Verhalten und vollständiger Firmware-Build erfolgreich; noch kein Test an realer Hardware. Diese Korrektur wurde nicht veröffentlicht.
