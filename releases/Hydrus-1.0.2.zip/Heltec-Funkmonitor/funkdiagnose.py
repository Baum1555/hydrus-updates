"""Diagnose ohne Zählerschlüssel: Telegrammkopf, Empfangsfrequenz, Aktivitätsscan."""
import json
from datetime import datetime
from decimal import Decimal, InvalidOperation
try:
    import tkinter as tk
    from tkinter import ttk, filedialog, messagebox
except ImportError:
    tk = None  # Für die PySide6-Oberfläche nicht erforderlich.


def frequenz_befehl(text):
    """MHz-Eingabe exakt in Hz umrechnen; nur den vorgesehenen Bereich zulassen."""
    try:
        hz = Decimal(text.strip().replace(',', '.')) * 1000000
        if not hz.is_finite() or hz != hz.to_integral_value() or not 863000000 <= hz <= 870000000:
            raise ValueError('Bitte eine Frequenz zwischen 863 und 870 MHz eingeben.')
        return f'FREQ {int(hz)}'
    except InvalidOperation as fehler:
        raise ValueError('Bitte eine gültige Frequenz in MHz eingeben.') from fehler


def adresskopf_lesen(hextext):
    """Adresse pro Paket auswerten; Diehl Real Data ordnet das A-Feld anders an."""
    try:
        daten = bytes.fromhex(hextext)
    except (ValueError, TypeError):
        return None
    if len(daten) < 11 or daten[0] + 1 != len(daten):
        return None
    hersteller = int.from_bytes(daten[2:4], 'little')
    teile = [(hersteller >> schieben) & 31 for schieben in (10, 5, 0)]
    code = ''.join(chr(64 + teil) for teil in teile) if all(1 <= teil <= 26 for teil in teile) else f'0x{hersteller:04X}'
    # Diehl: CI 7A mit gesetztem Konfigurationsbit 12 bezeichnet Real Data.
    # CI 71 ist dessen Alarmvariante. Andere Hersteller behalten ihre Anordnung.
    real_data = (code in ('DME', 'EWT', 'HYD', 'SAP', 'SPL') and daten[1] in (0x44, 0x46)
                 and (daten[10] == 0x71 or (daten[10] == 0x7A and len(daten) >= 15 and daten[14] & 0x10 != 0)))
    if real_data:
        kennung, version, medium = daten[6:10][::-1].hex().upper(), daten[4], daten[5]
    else:
        kennung, version, medium = daten[4:8][::-1].hex().upper(), daten[8], daten[9]
    return dict(kennung=kennung, version=version, medium=medium, hersteller=code,
                real_data=real_data, adressformat='Diehl Real Data' if real_data else 'Standardadressierung',
                ci=daten[10])


def kennung_korrigieren(paket):
    """Rohtelegramm unverändert lassen; Anzeige und Export erhalten erkannte Adressen."""
    kopf = adresskopf_lesen(paket['hex'])
    if not kopf or paket.get('auswertung') == 'DEMO':
        return paket
    paket['firmware_zaehlerkennung'] = paket.get('zaehlerkennung', '')
    paket['zaehlerkennung'] = kopf['kennung']
    paket['adressformat'] = kopf['adressformat']
    if kopf['real_data']:
        # Die alte Firmware deutet Prüfsummenbits irrtümlich als OMS-Sicherheitsmodus.
        # Deren Nutzdaten deshalb keinesfalls als bereits entschlüsselt behandeln.
        neue_zustaende = ('REAL_DATA_DEKODIERT', 'REAL_DATA_SCHLUESSEL_FEHLT',
                         'REAL_DATA_PRUEFSUMME_FALSCH', 'REAL_DATA_FORMAT_NICHT_UNTERSTUETZT',
                         'SCHLUESSEL_UNGUELTIG')
        zustand = paket.get('auswertung')
        paket.update(transportkennung=kopf['kennung'], sicherheitsmodus=-1, authentifiziert=False)
        if zustand not in neue_zustaende:
            paket.update(auswertung='DIEHL_REAL_DATA', nutzdaten_hex='')
        elif zustand != 'REAL_DATA_DEKODIERT':
            paket['nutzdaten_hex'] = ''
    return paket


def kopf_lesen(paket):
    """Nur öffentlich lesbare Headerangaben. Die Modellzuordnung bleibt ein Hinweis."""
    kopf = adresskopf_lesen(paket['hex'])
    if not kopf:
        return None
    code, kennung = kopf['hersteller'], kopf['kennung']
    medium = {6: 'Warmwasser', 7: 'Wasser', 0x16: 'Kaltwasser', 0x17: 'Warm-/Kaltwasser'}.get(kopf['medium'], f'Medium 0x{kopf["medium"]:02X}')
    modell = 'Modell nicht zugeordnet'
    if code == 'DME' and kopf['version'] in (0x70, 0x76) and kopf['medium'] in (6, 7, 0x16):
        modell = 'Kennung passt zur HYDRUS-Familie (Modell nicht eindeutig bestätigt)'
    modus = paket.get('modus', '')
    gueltig = paket.get('crc_geprueft') is True and modus in ('T1', 'C1')
    return dict(kennung=kennung, hersteller=code, version=f'0x{kopf["version"]:02X}', medium=medium,
                modell=modell, protokoll=f'Wireless M-Bus {modus[0]} (Uplink)' if gueltig else 'Header erkannt; Funkprüfung nicht bestätigt',
                crc_geprueft=gueltig, transportkennung=kennung if kopf['real_data'] else paket.get('transportkennung', ''),
                sicherheitsmodus=-1 if kopf['real_data'] else paket.get('sicherheitsmodus', -1),
                adressformat=kopf['adressformat'], ci=f'0x{kopf["ci"]:02X}', rahmenformat=paket.get('format', ''))


def status_lesen(zeile):
    """Nur sauber begrenzte Scan-/Statusdaten akzeptieren, keine geratenen Zahlen."""
    for typ in ('SCAN', 'FUNKSTATUS'):
        if not zeile.startswith(typ + ' '):
            continue
        try:
            daten = json.loads(zeile[len(typ) + 1:])
            if not isinstance(daten, dict):
                return None
            if type(daten.get('frequenz_hz')) is not int or not 863000000 <= daten['frequenz_hz'] <= 870000000:
                return None
            for name in (('maximum_dbm', 'mittel_dbm') if typ == 'SCAN' else ('rssi',)):
                if type(daten.get(name)) is not int or not -200 <= daten[name] <= 30:
                    return None
            if typ == 'SCAN' and (type(daten.get('durchgang')) is not int or not 1 <= daten['durchgang'] <= 4):
                return None
            return typ, daten
        except (ValueError, TypeError):
            return None
    return None


class Funkdiagnose:
    def __init__(self, rahmen, senden):
        self.senden = senden
        self.kanaele = {}
        self.zaehler = {}
        self.pakete = []
        self.ereignisse = []
        self.quelle = 'USB'
        self.aktuell = tk.StringVar(value='Noch keine Rückmeldung der Diagnose-Firmware.')
        self.frequenz = tk.StringVar(value='868,95')
        leiste = ttk.Frame(rahmen)
        leiste.pack(fill='x', pady=6)
        ttk.Button(leiste, text='T/C auf 868,95 MHz beobachten', command=lambda: senden('TC')).pack(side='left')
        ttk.Button(leiste, text='Aktivitätsscan starten', command=self.scan_starten).pack(side='left', padx=5)
        ttk.Button(leiste, text='Scan stoppen / T/C', command=lambda: senden('STOP')).pack(side='left')
        ttk.Button(leiste, text='Diagnosebericht speichern', command=self.speichern).pack(side='right')
        ttk.Label(rahmen, textvariable=self.aktuell, wraplength=940).pack(fill='x', pady=5)
        ttk.Label(rahmen, text='Scan: 863–870 MHz, etwa 30–45 Sekunden. Nur Signalpegel, kein Protokollnachweis. Währenddessen kein Paketempfang.', wraplength=940).pack(fill='x')
        pruefleiste = ttk.Frame(rahmen)
        pruefleiste.pack(fill='x', pady=6)
        ttk.Label(pruefleiste, text='Empfang auf MHz:').pack(side='left')
        ttk.Entry(pruefleiste, textvariable=self.frequenz, width=12).pack(side='left', padx=5)
        ttk.Button(pruefleiste, text='Mit T/C-Decoder testen', command=self.frequenz_testen).pack(side='left')
        ttk.Label(pruefleiste, text='  Andere Frequenz allein aktiviert keinen S1-/LoRa-/Diehl-Decoder.').pack(side='left')
        register = ttk.Notebook(rahmen)
        register.pack(fill='both', expand=True)
        zaehlerrahmen, scanrahmen = ttk.Frame(register), ttk.Frame(register)
        register.add(zaehlerrahmen, text='Gesehene Zähler')
        register.add(scanrahmen, text='Signalpegel je Empfangskanal')
        self.zaehlertabelle = self.tabelle(zaehlerrahmen,
            ['Quelle', 'Kennung', 'Hersteller', 'Version', 'Medium', 'Protokoll', 'MHz eingestellt', 'Pakete', 'Zuletzt', 'RSSI'])
        self.scantabelle = self.tabelle(scanrahmen, ['MHz eingestellt', 'Maximum dBm', 'Mittel dBm', 'Messfenster', 'Letzter Durchgang'])
        self.scantabelle.heading('1', command=self.pegel_sortieren)
        self.scantabelle.bind('<Double-1>', self.kanal_auswaehlen)
        self.hinweis = tk.StringVar(value='Ohne AES-Schlüssel sind Kopf und Funkmodus oft bereits lesbar. Zählerkennung mit dem Aufdruck abgleichen.')
        ttk.Label(rahmen, textvariable=self.hinweis, wraplength=930).pack(fill='x', pady=6)

    @staticmethod
    def tabelle(rahmen, namen):
        spalten = tuple(str(index) for index in range(len(namen)))
        tabelle = ttk.Treeview(rahmen, columns=spalten, show='headings')
        for spalte, name in zip(spalten, namen):
            tabelle.heading(spalte, text=name)
            tabelle.column(spalte, width=105, minwidth=50)
        rollen = ttk.Scrollbar(rahmen, command=tabelle.yview)
        tabelle.configure(yscrollcommand=rollen.set)
        rollen.pack(side='right', fill='y')
        tabelle.pack(fill='both', expand=True)
        return tabelle

    def scan_starten(self):
        if self.senden('SCAN'):
            self.kanaele.clear()
            for zeile in self.scantabelle.get_children():
                self.scantabelle.delete(zeile)
            self.aktuell.set('Scan angefordert · warte auf bestätigte Messpunkte des ESP32.')

    def frequenz_testen(self):
        try:
            self.senden(frequenz_befehl(self.frequenz.get()))
        except ValueError as fehler:
            messagebox.showinfo('Frequenz', str(fehler))

    def kanal_auswaehlen(self, _ereignis=None):
        auswahl = self.scantabelle.selection()
        if auswahl:
            self.frequenz.set(f'{int(auswahl[0]) / 1000000:.3f}')

    def pegel_sortieren(self):
        """Klick auf Maximum sortiert nur die Übersicht, er wählt kein Protokoll."""
        for position, hz in enumerate(sorted(self.kanaele, key=lambda hz: self.kanaele[hz]['maximum_dbm'], reverse=True)):
            self.scantabelle.move(str(hz), '', position)

    def status(self, zeile):
        if zeile.startswith(('STATUS ', 'FEHLER ', 'ANTWORT ', 'FUNKSTATUS ', 'FUNKFEHLER ', 'HINWEIS ', 'PC: ')):
            self.ereignisse.append(dict(pc_zeit=datetime.now().astimezone().isoformat(), meldung=zeile[:1000]))
            self.ereignisse = self.ereignisse[-500:]
        if zeile.startswith(('FEHLER ', 'FUNKFEHLER ')):
            self.aktuell.set('Empfänger meldet: ' + zeile[:500])
            return
        if zeile.startswith('ANTWORT Befehl ungueltig'):
            self.aktuell.set('ESP32 hat den Auftrag abgelehnt. Kurz warten und erneut versuchen.')
            return
        gelesen = status_lesen(zeile)
        if not gelesen:
            return
        typ, daten = gelesen
        hz = daten['frequenz_hz']
        if typ == 'FUNKSTATUS':
            chip = 'SX1262 · Aufnahmegrenze 255 Funkbytes · ' if daten.get('funkchip') == 'SX1262' else 'ESP32 · '
            self.aktuell.set(f'{chip}T/C-Empfang bestätigt auf {hz / 1000000:.3f} MHz · Pegel {daten["rssi"]} dBm · AES für Paketerkennung nicht nötig.')
            return
        bisher = self.kanaele.setdefault(hz, dict(maximum_dbm=-200, summe=0, messfenster=0))
        bisher['maximum_dbm'] = max(bisher['maximum_dbm'], daten['maximum_dbm'])
        bisher['summe'] += daten['mittel_dbm']
        bisher['messfenster'] += 1
        bisher['durchgang'] = daten['durchgang']
        werte = (f'{hz / 1000000:.3f}', bisher['maximum_dbm'], round(bisher['summe'] / bisher['messfenster'], 1), bisher['messfenster'], daten['durchgang'])
        schluessel = str(hz)
        if self.scantabelle.exists(schluessel):
            self.scantabelle.item(schluessel, values=werte)
        else:
            self.scantabelle.insert('', 'end', iid=schluessel, values=werte)
        self.aktuell.set(f'Aktivitätsscan · Durchgang {daten["durchgang"]}/4 · {hz / 1000000:.3f} MHz · kein Zählernachweis. Danach automatisch 868,95 MHz.')

    def paket(self, paket, quelle, zeit):
        self.pakete.append(dict(quelle=quelle, pc_zeit=zeit, paket=paket))
        self.pakete = self.pakete[-1000:]
        kopf = kopf_lesen(paket)
        if not kopf:
            return
        schluessel = ':'.join([quelle, kopf['hersteller'], kopf['kennung'], kopf['version'], kopf['medium']])
        # Beschränkung gegen unbegrenzte fremde Kennungen im Langzeitbetrieb.
        if schluessel not in self.zaehler and len(self.zaehler) >= 500:
            return
        eintrag = self.zaehler.setdefault(schluessel, dict(kopf=kopf, pakete=0, zuerst=zeit))
        eintrag.update(zuletzt=zeit, rssi=paket.get('rssi'), frequenz_hz=paket.get('frequenz_hz'), quelle=quelle)
        eintrag['kopf'] = kopf
        eintrag['pakete'] += 1
        hz = paket.get('frequenz_hz')
        werte = (quelle, kopf['kennung'], kopf['hersteller'], kopf['version'], kopf['medium'], kopf['protokoll'],
                 f'{hz / 1000000:.3f}' if hz else 'unbekannt', eintrag['pakete'], zeit, paket.get('rssi'))
        if self.zaehlertabelle.exists(schluessel):
            self.zaehlertabelle.item(schluessel, values=werte)
        else:
            self.zaehlertabelle.insert('', 'end', iid=schluessel, values=werte)

    def details(self, paket):
        kopf = kopf_lesen(paket)
        if kopf:
            modus = kopf['sicherheitsmodus']
            sicherheit = 'Diehl-Auswertung noch nicht implementiert' if kopf['adressformat'] == 'Diehl Real Data' else f'Sicherheitsmodus {modus if modus >= 0 else "noch nicht erkannt"}'
            self.hinweis.set(f'{kopf["hersteller"]} · {kopf["modell"]} · {kopf["adressformat"]} · Rahmen {kopf["rahmenformat"] or "unbekannt"} · Transportkennung {kopf["transportkennung"] or "unbekannt"} · {sicherheit}. Empfangsfrequenz ≠ präzise Trägerfrequenzmessung.')

    def leeren(self):
        self.kanaele.clear()
        self.zaehler.clear()
        self.pakete.clear()
        self.ereignisse.clear()
        for tabelle in (self.zaehlertabelle, self.scantabelle):
            for zeile in tabelle.get_children():
                tabelle.delete(zeile)
        self.aktuell.set('Warte auf neue Rückmeldung der Diagnose-Firmware.')
        self.hinweis.set('Noch keine Zählerdaten in dieser Sitzung.')

    def speichern(self):
        pfad = filedialog.asksaveasfilename(defaultextension='.json', initialfile='funkdiagnose.json', filetypes=[('Diagnosebericht', '*.json')])
        if not pfad:
            return
        bericht = dict(format='Hydrus-Funkdiagnose-1', erstellt=datetime.now().astimezone().isoformat(),
                       hinweis='Signalpegel und eingestellte Empfangsfrequenzen sind kein Nachweis des Zählers oder seiner genauen Trägerfrequenz. Enthält die letzten 1000 Pakete, eventuell Klartext-Messwerte; keine AES-Schlüssel.',
                       zaehler=list(self.zaehler.values()), scan=[dict(frequenz_hz=hz, **werte, mittel_dbm=round(werte['summe'] / werte['messfenster'], 1)) for hz, werte in sorted(self.kanaele.items())], pakete=self.pakete, ereignisse=self.ereignisse)
        try:
            with open(pfad, 'w', encoding='utf-8') as datei:
                json.dump(bericht, datei, ensure_ascii=False, indent=2)
        except OSError as fehler:
            messagebox.showerror('Speichern fehlgeschlagen', str(fehler))
