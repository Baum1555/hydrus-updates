// Löschen betrifft die gespeicherte Einrichtung. Archivierte Messwerte bleiben erhalten.
const loeschKnopf=document.createElement('button');loeschKnopf.id='geraetLoeschen';loeschKnopf.type='button';loeschKnopf.textContent='Zähler löschen';loeschKnopf.style.color='#a53727';$('geraeteForm').append(loeschKnopf);
const loeschDialog=document.createElement('dialog');loeschDialog.id='loeschDialog';loeschDialog.style.cssText='border:1px solid var(--line);border-radius:18px;padding:24px;max-width:440px;width:calc(100% - 32px);background:var(--card);color:var(--ink)';loeschDialog.innerHTML='<h2>Zähler löschen?</h2><p id="loeschName"></p><p>Name, Schlüssel und Warneinstellungen werden entfernt. Gespeicherte Messwerte und Ereignisse bleiben im Verlauf erhalten.</p><div class="row"><button id="loeschAbbrechen" autofocus>Abbrechen</button><button id="loeschBestaetigen">Zähler löschen</button></div><p id="loeschStatus" role="status"></p>';document.body.append(loeschDialog);loeschDialog.setAttribute('aria-labelledby','loeschName');
let loeschId='',loeschLaeuft=false;
loeschKnopf.onclick=()=>{if(geraetSpeichert)return;const g=geraeteListe.find(g=>g.id===$('geraetAuswahl').value);if(!g)return;loeschId=g.id;$('loeschName').textContent=(g.name!==g.id?g.name+' · ':'')+g.id;$('loeschStatus').textContent='';loeschDialog.showModal();};
$('loeschAbbrechen').onclick=()=>loeschDialog.close();loeschDialog.addEventListener('cancel',e=>{if(loeschLaeuft)e.preventDefault();});
$('loeschBestaetigen').onclick=async()=>{
 if(loeschLaeuft||!loeschId)return;loeschLaeuft=true;geraetSpeichert=true;$('loeschBestaetigen').disabled=true;$('loeschAbbrechen').disabled=true;$('loeschStatus').textContent='Wird gelöscht …';
 const id=loeschId;
 try{if(!token)await sitzungLaden();const r=await fetch('/api/zaehler/loeschen',{method:'POST',headers:{'X-Hydrus-Token':token},body:new URLSearchParams({id}),signal:AbortSignal.timeout(15000)});const text=await r.text();if(!r.ok)throw Error(text);
 geraeteKonfigGeladen=true;geraeteListe=geraeteListe.filter(g=>g.id!==id);geraeteStatus.delete(id);zaehler.delete(id);
 if(wahl===id){wahl=geraeteListe[0]?.id||'';localStorage.setItem('hydrus-kennung',wahl);}
 geraetNeu=!geraeteListe.length;geraeteAuswahl();$('geraetAuswahl').value=geraeteListe[0]?.id||'';geraetAnzeigen();warnAuswahl();auswahl();aktualisieren();loeschDialog.close();$('geraetMeldung').textContent='Zähler gelöscht.';
 }catch(e){$('loeschStatus').textContent=e.message;}finally{loeschLaeuft=false;geraetSpeichert=false;$('loeschBestaetigen').disabled=false;$('loeschAbbrechen').disabled=false;$('geraetHinzufuegen').disabled=geraeteListe.length>=8;}
};
// Statusabfragen können Löschungen von einem anderen Handy enthalten.
const statusVorLoeschen=komfortStatus;komfortStatus=function(j){if(j.zaehler){const ids=new Set(j.zaehler.map(g=>g.id));for(const id of geraeteStatus.keys())if(!ids.has(id))geraeteStatus.delete(id);}statusVorLoeschen(j);};
loeschKnopf.classList.toggle('hidden',!geraeteListe.some(g=>g.id===$('geraetAuswahl').value));
