"""Werkzeug für den Herausgeber: Schlüssel einmal anlegen, neue Versionen signieren."""
import argparse
import base64
import hashlib
import json
import struct
from pathlib import Path
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import rsa, padding
from updatepaket import MAGIE


def main():
    a = argparse.ArgumentParser(description=__doc__)
    a.add_argument('aktion', choices=['schluessel', 'paket'])
    a.add_argument('--privat', required=True, type=Path)
    a.add_argument('--oeffentlich', type=Path)
    a.add_argument('--datei', type=Path)
    a.add_argument('--ausgabe', type=Path)
    a.add_argument('--produkt', choices=['heltec-v3', 'pc'])
    a.add_argument('--version')
    a.add_argument('--build', type=int)
    a.add_argument('--url', default='')
    o = a.parse_args()
    if o.aktion == 'schluessel':
        if o.privat.exists() or not o.oeffentlich:
            a.error('Neuen privaten Pfad und öffentlichen Ausgabepfad angeben')
        key = rsa.generate_private_key(public_exponent=65537, key_size=2048)
        o.privat.parent.mkdir(parents=True, exist_ok=True)
        o.privat.write_bytes(key.private_bytes(serialization.Encoding.PEM, serialization.PrivateFormat.PKCS8, serialization.NoEncryption()))
        o.oeffentlich.write_bytes(key.public_key().public_bytes(serialization.Encoding.PEM, serialization.PublicFormat.SubjectPublicKeyInfo))
        print('Schlüsselpaar angelegt. Private Datei getrennt sichern; niemals veröffentlichen.')
        return
    if not all([o.datei,o.ausgabe,o.produkt,o.version,o.build]):
        a.error('Datei, Ausgabe, Produkt, Version und Build erforderlich')
    key = serialization.load_pem_private_key(o.privat.read_bytes(),password=None)
    daten = o.datei.read_bytes()
    roh = json.dumps(dict(produkt=o.produkt,version=o.version,build=o.build,groesse=len(daten),
                         sha256=hashlib.sha256(daten).hexdigest(),url=o.url),sort_keys=True,separators=(',',':')).encode()
    sig = key.sign(roh,padding.PKCS1v15(),hashes.SHA256())
    o.ausgabe.write_bytes(MAGIE+struct.pack('>I',len(roh))+roh+sig+daten)
    o.ausgabe.with_suffix('.json').write_text(json.dumps(dict(metadaten=base64.b64encode(roh).decode(),signatur=base64.b64encode(sig).decode())),encoding='utf-8')
    print('Signiertes Paket und Versionsdatei erstellt.')


if __name__ == '__main__':
    main()
