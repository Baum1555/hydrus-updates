// Die Zusammenfassung beschreibt die eingestellten Regeln, keine Verbrauchsprognose.
const warnStil=document.createElement('style');warnStil.textContent=`.warnEinstellung{min-width:0;border:1px solid var(--line);border-radius:14px;padding:18px;margin:6px 0}.warnEinstellung legend{font-weight:650;padding:0 8px}.warnFelder{display:grid;grid-template-columns:1fr 1fr;gap:16px;margin-top:18px}.warnSchalter{display:flex;align-items:center;gap:10px;color:var(--ink)}.warnZusammenfassung{padding:12px;border-radius:10px;background:var(--bg);margin-bottom:0}.warnEinstellung input[type=number]{width:100%}@media(max-width:500px){.warnFelder{grid-template-columns:1fr}}`;
document.head.append(warnStil);
function warnregelText(){
 const aktiv=$('leckAktiv').checked,fluss=$('leckLiter').valueAsNumber,dauer=$('leckDauer').valueAsNumber,empfang=$('empfangDauer').valueAsNumber;
 const n=x=>x.toLocaleString('de-DE',{maximumFractionDigits:3});
 $('leckLiter').disabled=!aktiv;$('leckDauer').disabled=!aktiv;
 $('leckErklaerung').textContent=!aktiv?'Warnung bei längerem Wasserfluss ausgeschaltet.':!Number.isFinite(fluss)||!Number.isFinite(dauer)||fluss<=0||dauer<=0?'Wassermenge und Dauer eingeben.':'Warnung, wenn mindestens '+n(fluss)+' Liter pro Minute für '+n(dauer)+' Minuten durchgehend gemeldet werden. Die Grenze ist kein Aufschlag auf den aktuellen Durchfluss.';
 $('empfangErklaerung').textContent=Number.isFinite(empfang)&&empfang>0?'Warnung, wenn der Heltec '+n(empfang)+' Minuten lang keine neuen Daten dieses Zählers erhält.':'Wartezeit in Minuten eingeben.';
}
for(const id of ['leckAktiv','leckLiter','leckDauer','empfangDauer'])$(id).addEventListener('input',warnregelText);
const geraetOhneWarntext=geraetAnzeigen;
geraetAnzeigen=function(){geraetOhneWarntext();warnregelText();};
$('geraetAuswahl').addEventListener('change',warnregelText);
warnregelText();
