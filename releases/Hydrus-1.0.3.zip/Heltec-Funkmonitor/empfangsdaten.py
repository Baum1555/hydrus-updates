"""Zeigt Wireless-M-Bus-Telegramme eines ESP32 am Windows-PC an.

Start: python funkmonitor.py
USB-Unterstützung installieren: python -m pip install pyserial

Die Firmware prüft den Funkrahmen. Dieses Programm verarbeitet dessen
USB-Ausgabe. Entschlüsselte Nutzdaten werden lokal als Messfelder angezeigt. Eigene Bezeichner
und Kommentare sind deutsch; feste Bibliotheksaufrufe bleiben unverändert.
"""
import csv
import json
import re

from datetime import datetime

from messwerte import paket_auswerten
from funkdiagnose import kennung_korrigieren
from wlanverbindung import WlanVerbindung

# Die WLAN-Verbindung funktioniert auch ohne pyserial.
try:
    import serial
    from serial.tools import list_ports
except ImportError:
    serial = None
VERBINDUNGSFEHLER = (OSError, ValueError) + ((serial.SerialException,) if serial else ())

MAXIMALE_PAKETE = 5000
PAKETKENNUNG = "WMBUS "
# Manche seriellen Ausgaben enthalten unsichtbare Terminal-Farbcodes.
ANSI_FARBCODES = re.compile(r"\x1b\[[0-?]*[ -/]*[@-~]")


def paket_lesen(zeile):
    """Nur ausdrücklich markierte Empfängerdaten zählen als Pakete, keine Startmeldungen."""
    zeile = ANSI_FARBCODES.sub("", zeile)
    position = zeile.find(PAKETKENNUNG)
    if position < 0:
        return None
    try:
        # Vor der Paketkennung dürfen Zeitstempel und sonstige Logtexte stehen.
        daten = json.loads(zeile[position + len(PAKETKENNUNG):])
        if not isinstance(daten, dict):
            return None
        rohdaten = daten.get("hex", "")
        if not isinstance(rohdaten, str):
            return None
        rohdaten = re.sub(r"\s+", "", rohdaten).upper()
        # Zwei Hexzeichen beschreiben genau ein Byte. Ungültige Daten ignorieren.
        if not rohdaten or len(rohdaten) % 2 or not re.fullmatch(r"[0-9A-F]+", rohdaten):
            return None
        if len(rohdaten) > 8192:
            return None
        rssi = daten.get("rssi")
        if isinstance(rssi, bool) or (rssi is not None and
                (not isinstance(rssi, (int, float)) or not -200 <= rssi <= 30)):
            return None
        nutzdaten = daten.get("nutzdaten_hex", "")
        if not isinstance(nutzdaten, str) or len(nutzdaten) > 512 or len(nutzdaten) % 2 or (nutzdaten and not re.fullmatch(r"[0-9a-fA-F]+", nutzdaten)):
            return None
        for feldname, minimum, maximum in [("sicherheitsmodus", -1, 31), ("zaehlerstatus", -1, 255)]:
            wert = daten.get(feldname, -1)
            if type(wert) is not int or not minimum <= wert <= maximum:
                return None
        if type(daten.get("authentifiziert", False)) is not bool:
            return None
        frequenz = daten.get('frequenz_hz')
        if frequenz is not None and (type(frequenz) is not int or not 863000000 <= frequenz <= 870000000):
            return None
        if type(daten.get('crc_geprueft', False)) is not bool:
            return None
        return kennung_korrigieren({"geraetestatus": daten.get("geraetestatus") if isinstance(daten.get("geraetestatus"),dict) else None, "hex": rohdaten, "rssi": rssi,
                "format": str(daten.get('format', ''))[:8],
                "frequenz_hz": frequenz, "crc_geprueft": daten.get('crc_geprueft', False),
                "auswertung": str(daten.get("auswertung", "ROHDATEN"))[:100],
                "nutzdaten_hex": nutzdaten.upper(),
                "sicherheitsmodus": daten.get("sicherheitsmodus", -1),
                "zaehlerstatus": daten.get("zaehlerstatus", -1),
                "authentifiziert": daten.get("authentifiziert", False),
                "transportkennung": str(daten.get("transportkennung", ""))[:80],
                "funkkennung": str(daten.get("funkkennung", ""))[:80],
                # Alte englische Feldnamen bleiben für frühere Firmware lesbar.
                "zaehlerkennung": str(daten.get("zaehlerkennung", daten.get("meter_id", "")))[:80],
                "modus": str(daten.get("modus", daten.get("mode", "")))[:16]})
    except (ValueError, TypeError):
        return None

